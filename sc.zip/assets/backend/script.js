(() => {
  'use strict';
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const sidebar=$('.sidebar'), overlay=$('.overlay');
  const closeMenu=()=>{sidebar?.classList.remove('open');overlay?.classList.remove('show');document.body.classList.remove('menu-open')};
  $('.mobile-toggle')?.addEventListener('click',()=>{
    if(window.matchMedia('(min-width: 761px)').matches){
      document.body.classList.toggle('sidebar-collapsed');
      return;
    }
    const isOpen=sidebar?.classList.toggle('open');
    overlay?.classList.toggle('show',!!isOpen);
    document.body.classList.toggle('menu-open',!!isOpen);
  });
  overlay?.addEventListener('click',closeMenu);
  // Account dropdown: toggle on click and dismiss on outside click / Escape.
  const userMenu=$('.user-menu'), userMenuToggle=$('.user-menu-toggle'), userDropdown=$('.user-dropdown');
  const closeUserMenu=()=>{if(userDropdown){userDropdown.hidden=true;userMenuToggle?.setAttribute('aria-expanded','false');}};
  userMenuToggle?.addEventListener('click',event=>{
    event.stopPropagation();
    const opening=!!userDropdown?.hidden;
    if(userDropdown) userDropdown.hidden=!opening;
    userMenuToggle.setAttribute('aria-expanded',String(opening));
  });
  document.addEventListener('click',event=>{if(userMenu && !userMenu.contains(event.target)) closeUserMenu();});
  document.addEventListener('keydown',event=>{if(event.key==='Escape') closeUserMenu();});

  // Expandable sidebar groups (App, Blog, Settings).
  $$('.nav-parent').forEach(button=>{
    button.addEventListener('click',()=>{
      const submenu=document.getElementById(button.getAttribute('aria-controls'));
      if(!submenu) return;
      const opening=button.getAttribute('aria-expanded')!=='true';
      button.setAttribute('aria-expanded',String(opening));
      submenu.hidden=!opening;
      button.closest('.nav-item')?.classList.toggle('is-open',opening);
    });
  });
  $$('.sidebar a.nav-link').forEach(link=>link.addEventListener('click',closeMenu));
  $$('[data-placeholder-link]').forEach(link=>link.addEventListener('click',event=>event.preventDefault()));
  $$('.password-toggle').forEach(b=>b.addEventListener('click',()=>{const input=b.parentElement.querySelector('input');if(input){input.type=input.type==='password'?'text':'password';b.innerHTML=input.type==='password'?'<i class="fa-regular fa-eye"></i>':'<i class="fa-regular fa-eye-slash"></i>'}}));
  // Profile tabs: use delegated click handling so all three tabs work reliably.
  const profileTabList=$('[role="tablist"][aria-label="Profile settings"]');
  const activateProfileTab=(name, moveFocus=false)=>{
    const tabs=$$('[data-profile-tab]', profileTabList || document);
    const panels=$$('[data-profile-panel]');
    const target=tabs.find(tab=>tab.dataset.profileTab===name);
    if(!target) return;
    tabs.forEach(tab=>{
      const active=tab===target;
      tab.classList.toggle('active',active);
      tab.setAttribute('aria-selected',String(active));
      tab.setAttribute('tabindex',active?'0':'-1');
    });
    panels.forEach(panel=>{
      const active=panel.dataset.profilePanel===name;
      panel.hidden=!active;
      panel.classList.toggle('active',active);
      panel.setAttribute('aria-hidden',String(!active));
    });
    if(moveFocus) target.focus();
  };
  if(profileTabList){
    profileTabList.addEventListener('click',event=>{
      const tab=event.target.closest('[data-profile-tab]');
      if(tab && profileTabList.contains(tab)) activateProfileTab(tab.dataset.profileTab);
    });
    profileTabList.addEventListener('keydown',event=>{
      const tabs=$$('[data-profile-tab]',profileTabList);
      const current=tabs.indexOf(event.target.closest('[data-profile-tab]'));
      if(current<0 || !['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) return;
      event.preventDefault();
      const next=event.key==='Home'?0:event.key==='End'?tabs.length-1:
        (current+(event.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;
      activateProfileTab(tabs[next].dataset.profileTab,true);
    });
    const initiallySelected=$('[data-profile-tab][aria-selected="true"]',profileTabList) || $('[data-profile-tab]',profileTabList);
    if(initiallySelected) activateProfileTab(initiallySelected.dataset.profileTab);
  }
  // Posts table filters work together instead of overriding each other.
  const searchInput = $('[data-table-search]');
  const statusSelect = $('[data-status-filter]');
  const postRows = $$('tbody tr');

  const applyPostFilters = () => {
    const query = searchInput?.value.trim().toLowerCase() || '';
    const selectedStatus = statusSelect?.value || '';

    postRows.forEach(row => {
      const matchesSearch = !query || row.textContent.toLowerCase().includes(query);
      const matchesStatus = !selectedStatus || row.dataset.status === selectedStatus;

      row.hidden = !(matchesSearch && matchesStatus);
    });
  };

  searchInput?.addEventListener('input', applyPostFilters);
  statusSelect?.addEventListener('change', applyPostFilters);

  // Custom status dropdown. The native select remains the source of truth
  // so existing filtering and any other scripts can keep listening to change.
  const customSelect = $('[data-custom-select]');

  if (customSelect && statusSelect) {
    const trigger = $('.select-trigger', customSelect);
    const label = $('[data-select-label]', customSelect);
    const optionList = $('.select-options', customSelect);
    const options = $$('.select-option', customSelect);

    const updateCustomSelect = () => {
      const selectedOption = statusSelect.options[statusSelect.selectedIndex];

      if (label && selectedOption) {
        label.textContent = selectedOption.textContent;
      }

      options.forEach(option => {
        const isSelected = option.dataset.selectValue === statusSelect.value;

        option.classList.toggle('is-selected', isSelected);
        option.setAttribute('aria-selected', String(isSelected));
      });
    };

    const closeCustomSelect = (restoreFocus = false) => {
      if (!trigger || !optionList) return;

      optionList.hidden = true;
      trigger.setAttribute('aria-expanded', 'false');
      customSelect.classList.remove('is-open');

      if (restoreFocus) trigger.focus();
    };

    const openCustomSelect = (focusIndex = null) => {
      if (!trigger || !optionList) return;

      optionList.hidden = false;
      trigger.setAttribute('aria-expanded', 'true');
      customSelect.classList.add('is-open');

      if (focusIndex !== null) {
        options[focusIndex]?.focus();
      }
    };

    const chooseOption = option => {
      if (!option) return;

      statusSelect.value = option.dataset.selectValue ?? '';
      statusSelect.dispatchEvent(new Event('change', { bubbles: true }));
      closeCustomSelect(true);
    };

    customSelect.classList.add('is-enhanced');
    statusSelect.tabIndex = -1;
    statusSelect.setAttribute('aria-hidden', 'true');
    updateCustomSelect();

    trigger?.addEventListener('click', () => {
      const isOpen = trigger.getAttribute('aria-expanded') === 'true';

      if (isOpen) {
        closeCustomSelect();
      } else {
        openCustomSelect();
      }
    });

    trigger?.addEventListener('keydown', event => {
      const selectedIndex = Math.max(statusSelect.selectedIndex, 0);

      if (event.key === 'ArrowDown') {
        event.preventDefault();
        openCustomSelect(selectedIndex);
      } else if (event.key === 'ArrowUp') {
        event.preventDefault();
        openCustomSelect(selectedIndex);
      } else if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        openCustomSelect(selectedIndex);
      } else if (event.key === 'Escape') {
        closeCustomSelect();
      }
    });

    optionList?.addEventListener('click', event => {
      const option = event.target.closest('[data-select-value]');

      if (option && optionList.contains(option)) {
        chooseOption(option);
      }
    });

    optionList?.addEventListener('keydown', event => {
      const currentIndex = options.indexOf(event.target.closest('[data-select-value]'));
      if (currentIndex < 0) return;

      let nextIndex = currentIndex;

      if (event.key === 'ArrowDown') {
        nextIndex = (currentIndex + 1) % options.length;
      } else if (event.key === 'ArrowUp') {
        nextIndex = (currentIndex - 1 + options.length) % options.length;
      } else if (event.key === 'Home') {
        nextIndex = 0;
      } else if (event.key === 'End') {
        nextIndex = options.length - 1;
      } else if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        chooseOption(options[currentIndex]);
        return;
      } else if (event.key === 'Escape') {
        event.preventDefault();
        closeCustomSelect(true);
        return;
      } else if (event.key === 'Tab') {
        closeCustomSelect();
        return;
      } else {
        return;
      }

      event.preventDefault();
      options[nextIndex]?.focus();
    });

    statusSelect.addEventListener('change', updateCustomSelect);

    document.addEventListener('click', event => {
      if (!customSelect.contains(event.target)) {
        closeCustomSelect();
      }
    });

    document.addEventListener('keydown', event => {
      if (event.key === 'Escape') {
        closeCustomSelect();
      }
    });
  }

  // Profile image previews update immediately; the form uploads both files together on save.
  const profileImageInput = $('#profileImageInput');
  const bannerImageInput = $('#bannerImageInput');
  const profileImageTargets = [$('#profileImagePreview'), $('#profileAvatarPreview')].filter(Boolean);
  const bannerImageTargets = [$('#bannerImagePreview'), $('#profileCover')].filter(Boolean);
  const previewFile = (input, targets, isBackground=false) => {
        input?.addEventListener('change', () => {
          const file = input.files?.[0];
          if (!file) return;
          const allowedImageTypes = [
      'image/png',
      'image/jpeg',
      'image/webp'
    ];
    
    if (!allowedImageTypes.includes(file.type)) {
      input.value = '';
      window.alert('Please select a PNG, JPG/JPEG, or WEBP image.');
      return;
    }
      const previewUrl = URL.createObjectURL(file);
      targets.forEach(target => {
        if (isBackground) target.style.backgroundImage = `url("${previewUrl}")`;
        else target.src = previewUrl;
      });
    });
  };
  previewFile(profileImageInput, profileImageTargets);
  previewFile(bannerImageInput, bannerImageTargets, true);

  $$('form[data-demo-form]').forEach(form=>form.addEventListener('submit',e=>{e.preventDefault();}));

  // Small dependency-free dashboard chart.
  const canvas=$('#revenueChart');
  if(canvas){
    const ctx=canvas.getContext('2d'), dpr=Math.max(1,window.devicePixelRatio||1);
    const draw=()=>{const w=canvas.clientWidth,h=canvas.clientHeight;canvas.width=w*dpr;canvas.height=h*dpr;ctx.scale(dpr,dpr);ctx.clearRect(0,0,w,h);
      const pad={l:8,r:8,t:15,b:25}, values=[28,36,31,48,42,55,47,63,58,72,65,86], previous=[20,28,25,35,32,40,36,46,42,51,47,59];
      const x=i=>pad.l+i*(w-pad.l-pad.r)/(values.length-1), y=v=>h-pad.b-v/100*(h-pad.t-pad.b);
      ctx.font='10px Montserrat';ctx.fillStyle='#777184';ctx.strokeStyle='rgba(255,255,255,.07)';ctx.lineWidth=1;
      [0,25,50,75,100].forEach(v=>{ctx.beginPath();ctx.moveTo(pad.l,y(v));ctx.lineTo(w-pad.r,y(v));ctx.stroke();ctx.fillText(v===0?'0':v+'k',pad.l,y(v)-5)});
      const line=(arr,color,fill)=>{ctx.beginPath();arr.forEach((v,i)=>i?ctx.lineTo(x(i),y(v)):ctx.moveTo(x(i),y(v)));ctx.strokeStyle=color;ctx.lineWidth=2.4;ctx.lineJoin='round';ctx.lineCap='round';ctx.stroke();if(fill){ctx.lineTo(x(arr.length-1),h-pad.b);ctx.lineTo(x(0),h-pad.b);ctx.closePath();const g=ctx.createLinearGradient(0,pad.t,0,h-pad.b);g.addColorStop(0,'rgba(148,108,255,.22)');g.addColorStop(1,'rgba(148,108,255,0)');ctx.fillStyle=g;ctx.fill()}};
      line(previous,'#55466e',false);line(values,'#a78bfa',true);
      ['May 01','May 05','May 10','May 15','May 20','May 25'].forEach((v,i)=>{ctx.fillStyle='#777184';ctx.fillText(v,pad.l+i*(w-pad.l-pad.r)/5-10,h-5)});
    };draw();window.addEventListener('resize',draw,{passive:true});
  }

  // Website appearance image previews.
  $$('[data-image-preview]').forEach(input=>{
    input.addEventListener('change',()=>{
      const file=input.files?.[0], preview=document.getElementById(input.dataset.imagePreview);
      const placeholder=document.getElementById(input.dataset.placeholder);
      if(!file || !preview) return;
      if(!file.type.startsWith('image/')) { input.value=''; return; }
      const reader=new FileReader();
      reader.onload=()=>{preview.src=reader.result;preview.hidden=false;if(placeholder)placeholder.hidden=true;};
      reader.readAsDataURL(file);
    });
  });
  $$('[data-background-preview]').forEach(input=>{
    input.addEventListener('change',()=>{
      const file=input.files?.[0], preview=document.getElementById(input.dataset.backgroundPreview);
      if(!file || !preview || !file.type.startsWith('image/')) return;
      const reader=new FileReader();
      reader.onload=()=>{preview.style.backgroundImage=`url("${reader.result}")`;};
      reader.readAsDataURL(file);
    });
  });
  const themeHex=$('#browser_theme_color'), themePicker=$('#browserThemePicker'), themeValue=$('#browserThemeValue');
  const syncThemeColor=(value)=>{
    if(!/^#[0-9a-fA-F]{6}$/.test(value)) return;
    if(themePicker) themePicker.value=value;
    if(themeValue) themeValue.textContent=value.toLowerCase();
  };
  themeHex?.addEventListener('input',()=>syncThemeColor(themeHex.value.trim()));
  themePicker?.addEventListener('input',()=>{
    if(themeHex) themeHex.value=themePicker.value;
    if(themeValue) themeValue.textContent=themePicker.value;
  });
  if(themeHex) syncThemeColor(themeHex.value);
})();

/* Asset App: dialogs, three-step app creation, asset search and edit form */
(function () {
    'use strict';

    var backdrops = document.querySelectorAll('.asset-modal-backdrop');
    function openModal(id) {
        var modal = document.getElementById(id);
        if (!modal) return;
        modal.classList.add('is-open');
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('modal-open');
        if (id === 'createAppModal') setCreateStep(1);
        if (id === 'assetModal') {
            var form = modal.querySelector('form');
            if (form && !form.dataset.editing) resetAssetForm();
        }
    }
    function closeModal(modal) {
        modal.classList.remove('is-open');
        modal.setAttribute('aria-hidden', 'true');
        if (!document.querySelector('.asset-modal-backdrop.is-open')) {
            document.body.classList.remove('modal-open');
        }
    }
    document.querySelectorAll('[data-open-modal="editAppModal"]').forEach(function (button) {
        button.addEventListener('click', function () {
            document.getElementById('editAppName').value = button.dataset.appName || '';
            document.getElementById('editAppPublisher').value = button.dataset.appPublisher || '';
            document.getElementById('editAppDescription').value = button.dataset.appDescription || '';

            var logoUrl = button.dataset.appLogo || '';
            var bannerUrl = button.dataset.appBanner || '';
            var logoInput = document.getElementById('editAppLogo');
            var bannerInput = document.getElementById('editAppBanner');

            if (logoInput) {
                logoInput.value = '';
                logoInput.dataset.originalUrl = logoUrl;
            }
            if (bannerInput) {
                bannerInput.value = '';
                bannerInput.dataset.originalUrl = bannerUrl;
            }

            setAppMediaPreview('editAppLogoPreview', 'editAppLogoPlaceholder', logoUrl);
            setAppMediaPreview('editAppBannerPreview', 'editAppBannerPlaceholder', bannerUrl);
        });
    });

    function setAppMediaPreview(imageId, placeholderId, source) {
        var image = document.getElementById(imageId);
        var placeholder = document.getElementById(placeholderId);
        if (!image || !placeholder) return;

        if (source) {
            image.src = source;
            image.hidden = false;
            placeholder.hidden = true;
        } else {
            image.removeAttribute('src');
            image.hidden = true;
            placeholder.hidden = false;
        }
    }

    [
        ['editAppLogo', 'editAppLogoPreview', 'editAppLogoPlaceholder'],
        ['editAppBanner', 'editAppBannerPreview', 'editAppBannerPlaceholder']
    ].forEach(function (fields) {
        var input = document.getElementById(fields[0]);
        if (!input) return;

        input.addEventListener('change', function () {
            var file = input.files && input.files[0];
            if (!file) {
                setAppMediaPreview(fields[1], fields[2], input.dataset.originalUrl || '');
                return;
            }

            if (input._previewObjectUrl) {
                URL.revokeObjectURL(input._previewObjectUrl);
            }
            input._previewObjectUrl = URL.createObjectURL(file);
            setAppMediaPreview(fields[1], fields[2], input._previewObjectUrl);
        });
    });
    document.querySelectorAll('[data-open-modal]').forEach(function (button) {
        button.addEventListener('click', function () {
            if (button.hasAttribute('data-asset-create')) resetAssetForm();
            if (button.hasAttribute('data-asset-edit')) populateAssetForm(button);
            openModal(button.getAttribute('data-open-modal'));
        });
    });
    document.querySelectorAll('[data-close-modal]').forEach(function (button) {
        button.addEventListener('click', function () {
            var modal = button.closest('.asset-modal-backdrop');
            if (modal) closeModal(modal);
        });
    });
    backdrops.forEach(function (modal) {
        modal.addEventListener('click', function (event) {
            if (event.target === modal) closeModal(modal);
        });
    });
    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            document.querySelectorAll('.asset-modal-backdrop.is-open').forEach(closeModal);
        }
    });

    var createForm = document.getElementById('createAppForm');
    function setCreateStep(step) {
        if (!createForm) return;
        createForm.querySelectorAll('[data-step-panel]').forEach(function (panel) {
            var active = Number(panel.getAttribute('data-step-panel')) === step;
            panel.classList.toggle('active', active);
            panel.hidden = !active;
        });
        document.querySelectorAll('[data-step-dot]').forEach(function (dot) {
            var number = Number(dot.getAttribute('data-step-dot'));
            dot.classList.toggle('active', number === step);
            dot.classList.toggle('done', number < step);
        });
    }
    document.querySelectorAll('[data-next-step]').forEach(function (button) {
        button.addEventListener('click', function () {
            var next = Number(button.getAttribute('data-next-step'));
            if (next === 2) {
                var name = document.getElementById('newAppName');
                var publisher = document.getElementById('newAppPublisher');
                if (!name.value.trim() || name.value.trim().length < 2) {
                    name.setCustomValidity('Nama App minimal 2 karakter.'); name.reportValidity(); name.setCustomValidity(''); return;
                }
                if (!publisher.value.trim()) { publisher.reportValidity(); return; }
            }
            if (next === 3) {
                var mode = createForm.querySelector('input[name="repository_mode"]:checked');
                if (!mode) return;
                if (mode.value === 'existing') {
                    var repo = document.getElementById('existingRepository');
                    if (!repo.value) { repo.setCustomValidity('Pilih repository terlebih dahulu.'); repo.reportValidity(); repo.setCustomValidity(''); return; }
                }
            }
            setCreateStep(next);
        });
    });
    document.querySelectorAll('[data-prev-step]').forEach(function (button) {
        button.addEventListener('click', function () {
            setCreateStep(Number(button.getAttribute('data-prev-step')));
        });
    });
    function updateRepoMode() {
        var selected = createForm && createForm.querySelector('input[name="repository_mode"]:checked');
        var field = document.getElementById('existingRepoField');
        if (!field) return;
        field.hidden = !selected || selected.value !== 'existing';
        var select = document.getElementById('existingRepository');
        if (select) select.required = !field.hidden;
    }
    if (createForm) {
        createForm.querySelectorAll('input[name="repository_mode"]').forEach(function (radio) {
            radio.addEventListener('change', updateRepoMode);
        });
        createForm.addEventListener('submit', function (event) {
            var selected = createForm.querySelector('input[name="repository_mode"]:checked');
            if (selected && selected.value === 'existing' && !document.getElementById('existingRepository').value) {
                event.preventDefault(); setCreateStep(2); updateRepoMode();
            }
        });
        updateRepoMode();
    }

    var assetForm = document.querySelector('#assetModal form');
    function resetAssetForm() {
        if (!assetForm) return;
        assetForm.reset();
        assetForm.dataset.editing = '';
        document.getElementById('editAssetId').value = '0';
        document.getElementById('assetModalTitle').textContent = 'Add Asset';
    }
    function populateAssetForm(button) {
        if (!assetForm) return;
        assetForm.dataset.editing = '1';
        document.getElementById('editAssetId').value = button.dataset.id || '0';
        document.getElementById('assetName').value = button.dataset.name || '';
        document.getElementById('assetCategory').value = button.dataset.category || '';
        document.getElementById('assetRarity').value = button.dataset.rarity || '';
        document.getElementById('assetDescription').value = button.dataset.description || '';
        document.getElementById('assetDetail').value = button.dataset.detail || '';
        document.getElementById('assetModalTitle').textContent = 'Edit Asset';
        var file = document.getElementById('assetIcon');
        if (file) file.value = '';
    }

    var appSelect = document.getElementById('assetAppSelect');
    if (appSelect) {
        appSelect.addEventListener('change', function () {
            if (appSelect.value) window.location.href = appSelect.value;
        });
    }

    var searchableSelect = document.querySelector('[data-searchable-select]');
    if (searchableSelect) {
        var selectTrigger = searchableSelect.querySelector('[data-select-trigger]');
        var selectMenu = searchableSelect.querySelector('[data-select-menu]');
        var selectSearch = searchableSelect.querySelector('[data-select-search]');
        var selectValue = searchableSelect.querySelector('[data-select-value]');
        var selectLabel = searchableSelect.querySelector('[data-select-label]');
        var selectOptions = Array.prototype.slice.call(searchableSelect.querySelectorAll('[data-select-option]'));
        var selectNoResults = searchableSelect.querySelector('[data-select-no-results]');
        var selectForm = searchableSelect.closest('form');

        function closeSearchableSelect() {
            if (!selectMenu || !selectTrigger) return;
            selectMenu.hidden = true;
            selectTrigger.setAttribute('aria-expanded', 'false');
            searchableSelect.classList.remove('is-open');
        }

        if (selectTrigger && selectMenu) {
            selectTrigger.addEventListener('click', function () {
                var opening = selectMenu.hidden;
                selectMenu.hidden = !opening;
                selectTrigger.setAttribute('aria-expanded', String(opening));
                searchableSelect.classList.toggle('is-open', opening);
                if (opening && selectSearch) {
                    selectSearch.value = '';
                    selectOptions.forEach(function (option) { option.hidden = false; });
                    if (selectNoResults) selectNoResults.hidden = true;
                    selectSearch.focus();
                }
            });
        }

        if (selectSearch) {
            selectSearch.addEventListener('keydown', function (event) {
                if (event.key === 'Enter') event.preventDefault();
            });
            selectSearch.addEventListener('input', function () {
                var query = selectSearch.value.trim().toLocaleLowerCase();
                var visible = 0;
                selectOptions.forEach(function (option) {
                    var matches = option.textContent.trim().toLocaleLowerCase().indexOf(query) !== -1;
                    option.hidden = !matches;
                    if (matches) visible++;
                });
                if (selectNoResults) selectNoResults.hidden = visible !== 0;
            });
        }

        selectOptions.forEach(function (option) {
            option.addEventListener('click', function () {
                if (selectValue) selectValue.value = option.dataset.value || '';
                if (selectLabel) selectLabel.textContent = option.textContent.trim();
                selectOptions.forEach(function (item) {
                    item.setAttribute('aria-selected', String(item === option));
                });
                closeSearchableSelect();
                if (selectForm) selectForm.dispatchEvent(new Event('assetfilterchange', { bubbles: true }));
            });
        });

        document.addEventListener('click', function (event) {
            if (!searchableSelect.contains(event.target)) closeSearchableSelect();
        });
        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') closeSearchableSelect();
        });
    }

    function initBackendLazyImages() {
        var images = Array.prototype.slice.call(document.querySelectorAll('img.lazy[data-src]'));
        if (!images.length) return;

        function loadImage(image) {
            var source = image.getAttribute('data-src');
            if (!source) return;
            image.setAttribute('src', source);
            image.removeAttribute('data-src');
            image.classList.remove('lazy');
        }

        if ('IntersectionObserver' in window) {
            var observer = new IntersectionObserver(function (entries, currentObserver) {
                entries.forEach(function (entry) {
                    if (!entry.isIntersecting) return;
                    loadImage(entry.target);
                    currentObserver.unobserve(entry.target);
                });
            }, { rootMargin: '180px 0px' });
            images.forEach(function (image) { observer.observe(image); });
            return;
        }

        function loadVisibleImages() {
            images.forEach(function (image) {
                if (!image.getAttribute('data-src')) return;
                var bounds = image.getBoundingClientRect();
                if (bounds.top <= window.innerHeight + 180 && bounds.bottom >= -180) loadImage(image);
            });
        }
        window.addEventListener('scroll', loadVisibleImages, { passive: true });
        window.addEventListener('resize', loadVisibleImages);
        loadVisibleImages();
    }
    initBackendLazyImages();

    document.body.addEventListener('change', function (event) {
        if (event.target.matches('.file-control')) {
            var file = event.target.files && event.target.files[0];
            if (!file) return;
            var allowed = /\.(png|jpe?g|webp|svg)$/i.test(file.name);
            if (!allowed) {
                alert('Format file harus PNG, JPG, JPEG, WEBP, atau SVG.');
                event.target.value = '';
            }
        }
    });
})();


/* Asset App AJAX listing and SweetAlert2 dark-mode feedback */
(function () {
    'use strict';

    var page = document.querySelector('.asset-app-page');

    function swal(options) {
        if (window.Swal) return window.Swal.fire(Object.assign({
            background: '#111018',
            color: '#f5f3ff',
            confirmButtonColor: '#9560f5',
            cancelButtonColor: '#393344',
            customClass: { popup: 'ntmn-swal-dark' }
        }, options));
        return Promise.resolve({ isConfirmed: window.confirm(options.text || options.title || 'Continue?') });
    }

    var nativeAlert = window.alert.bind(window);
    window.alert = function (message) {
        if (window.Swal) swal({ icon: 'info', title: 'Information', text: String(message || '') });
        else nativeAlert(message);
    };

    // Convert legacy backend flash banners into consistent SweetAlert2 toasts.
    document.querySelectorAll('.backend-alert:not([data-swal-toast])').forEach(function (node) {
        var message = (node.textContent || '').trim();
        if (!message) return;
        var isError = node.classList.contains('error') || node.getAttribute('role') === 'alert';
        swal({
            toast: true,
            position: 'top-end',
            icon: isError ? 'error' : 'success',
            title: message,
            showConfirmButton: false,
            timer: 3600,
            timerProgressBar: true
        });
        node.remove();
    });

    // Support destructive buttons (for example, disconnecting GitHub) across backend pages.
    document.addEventListener('click', function (event) {
        var button = event.target.closest('button[data-swal-confirm]');
        if (!button || button.dataset.swalApproved === '1') return;
        event.preventDefault();
        swal({
            icon: 'warning',
            title: button.dataset.swalTitle || 'Are you sure?',
            text: button.dataset.swalText || 'This action cannot be undone.',
            showCancelButton: true,
            confirmButtonText: button.dataset.swalConfirmText || 'Yes, continue',
            cancelButtonText: 'Cancel',
            reverseButtons: true
        }).then(function (result) {
            if (!result.isConfirmed) return;
            button.dataset.swalApproved = '1';
            var form = button.form;
            if (form) {
                form.dataset.swalApproved = '1';
                if (form.requestSubmit) form.requestSubmit(button);
            }
        });
    });

    // Global SweetAlert2 handlers must run on every backend page, not only Asset App.
    // Remove each toast node after displaying it so a second initialization cannot repeat it.
    document.addEventListener('submit', function (event) {
        var form = event.target.closest('form[data-swal-confirm]');
        if (!form || form.dataset.swalApproved === '1') return;
        event.preventDefault();
        swal({
            icon: 'warning',
            title: form.dataset.swalTitle || 'Are you sure?',
            text: form.dataset.swalText || 'This action cannot be undone.',
            showCancelButton: true,
            confirmButtonText: form.dataset.swalConfirmText || 'Yes, continue',
            cancelButtonText: 'Cancel',
            reverseButtons: true
        }).then(function (result) {
            if (result.isConfirmed) {
                form.dataset.swalApproved = '1';
                form.submit();
            }
        });
    }, true);

    document.querySelectorAll('[data-swal-toast]').forEach(function (node) {
        if (node.dataset.swalHandled === '1') return;
        node.dataset.swalHandled = '1';
        swal({
            toast: true,
            position: 'top-end',
            icon: node.dataset.swalToast,
            title: node.dataset.swalMessage || '',
            showConfirmButton: false,
            timer: 3200,
            timerProgressBar: true
        });
        node.remove();
    });

    if (!page) return;

    var filterForm = document.getElementById('assetFilterForm');
    var searchInput = document.getElementById('assetSearch');
    var raritySelect = filterForm ? filterForm.querySelector('[name="rarity"]') : null;
    var resultMeta = document.getElementById('assetResultMeta');
    var tableContainer = document.getElementById('assetTableContainer');
    var pagination = document.getElementById('assetPagination');
    var debounceTimer = null;
    var activeRequest = null;


    function currentUrl(pageNumber) {
        var url = new URL(filterForm.action, window.location.origin);
        var data = new FormData(filterForm);
        ['search', 'category', 'rarity'].forEach(function (key) {
            var value = (data.get(key) || '').toString().trim();
            if (value) url.searchParams.set(key, value);
            else url.searchParams.delete(key);
        });
        url.pathname = url.pathname.replace(/\/1\/?$/, '/' + Math.max(1, pageNumber) + '/');
        return url;
    }

    function setLoading(loading) {
        if (tableContainer) tableContainer.classList.toggle('is-ajax-loading', loading);
        if (pagination) pagination.classList.toggle('is-ajax-loading', loading);
    }

    function loadListing(pageNumber, pushState) {
        if (!filterForm) return;
        var url = currentUrl(pageNumber || 1);
        url.searchParams.set('ajax', '1');

        if (activeRequest) activeRequest.abort();
        activeRequest = new AbortController();
        setLoading(true);

        fetch(url.toString(), {
            method: 'GET',
            headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' },
            credentials: 'same-origin',
            signal: activeRequest.signal
        })
        .then(function (response) {
            if (!response.ok) throw new Error('Server merespons dengan status ' + response.status);
            return response.json();
        })
        .then(function (payload) {
            if (!payload.ok) throw new Error(payload.message || 'Gagal memuat daftar assets.');
            var parser = new DOMParser();
            var fragment = parser.parseFromString(payload.html, 'text/html');
            var newMeta = fragment.querySelector('#assetResultMeta');
            var newTable = fragment.querySelector('#assetTableContainer');
            var newPagination = fragment.querySelector('#assetPagination');

            if (newMeta && resultMeta) {
                resultMeta.replaceWith(newMeta);
                resultMeta = newMeta;
            }
            if (newTable && tableContainer) {
                tableContainer.replaceWith(newTable);
                tableContainer = newTable;
            }
            if (pagination) {
                if (newPagination) {
                    pagination.replaceWith(newPagination);
                    pagination = newPagination;
                } else {
                    pagination.remove();
                    pagination = null;
                }
            } else if (newPagination && resultMeta) {
                resultMeta.insertAdjacentElement('afterend', newPagination);
                pagination = newPagination;
            }

            var cleanUrl = new URL(url.toString());
            cleanUrl.searchParams.delete('ajax');
            if (pushState) history.pushState({ assetPage: payload.page }, '', cleanUrl.pathname + cleanUrl.search);
            initLazyImages(tableContainer);
        })
        .catch(function (error) {
            if (error.name !== 'AbortError') {
                swal({ icon: 'error', title: 'Gagal memuat assets', text: error.message });
            }
        })
        .finally(function () {
            setLoading(false);
            activeRequest = null;
        });
    }

    function initLazyImages(scope) {
        if (!scope) return;
        var images = scope.querySelectorAll('img.lazy[data-src]');
        if (!images.length) return;
        if ('IntersectionObserver' in window) {
            var observer = new IntersectionObserver(function (entries, currentObserver) {
                entries.forEach(function (entry) {
                    if (!entry.isIntersecting) return;
                    entry.target.src = entry.target.dataset.src;
                    entry.target.removeAttribute('data-src');
                    entry.target.classList.remove('lazy');
                    currentObserver.unobserve(entry.target);
                });
            }, { rootMargin: '180px 0px' });
            images.forEach(function (img) { observer.observe(img); });
        } else {
            images.forEach(function (img) {
                img.src = img.dataset.src;
                img.removeAttribute('data-src');
                img.classList.remove('lazy');
            });
        }
    }

    if (filterForm) {
        filterForm.addEventListener('submit', function (event) {
            event.preventDefault();
            loadListing(1, true);
        });
        filterForm.addEventListener('assetfilterchange', function () {
            loadListing(1, true);
        });
        if (searchInput) {
            searchInput.addEventListener('input', function () {
                clearTimeout(debounceTimer);
                debounceTimer = setTimeout(function () { loadListing(1, true); }, 350);
            });
        }
        if (raritySelect) {
            raritySelect.addEventListener('change', function () { loadListing(1, true); });
        }
    }

    document.addEventListener('click', function (event) {
        var link = event.target.closest('a.asset-page-link, a[data-clear-asset-filters]');
        if (!link || !page.contains(link)) return;
        event.preventDefault();
        if (link.hasAttribute('data-clear-asset-filters')) {
            if (searchInput) searchInput.value = '';
            var categoryInput = filterForm.querySelector('[name="category"]');
            if (categoryInput) categoryInput.value = '';
            var categoryLabel = filterForm.querySelector('[data-select-label]');
            if (categoryLabel) categoryLabel.textContent = 'All Categories';
            if (raritySelect) raritySelect.value = '';
            loadListing(1, true);
            return;
        }
        var match = link.href.match(/\/([1-9][0-9]*)\/(?:\?|$)/);
        loadListing(match ? Number(match[1]) : 1, true);
    });

    window.addEventListener('popstate', function () {
        if (!filterForm) return;
        var url = new URL(window.location.href);
        ['search', 'category', 'rarity'].forEach(function (key) {
            var field = filterForm.querySelector('[name="' + key + '"]');
            if (field) field.value = url.searchParams.get(key) || '';
        });
        var categoryLabel = filterForm.querySelector('[data-select-label]');
        if (categoryLabel) categoryLabel.textContent = url.searchParams.get('category') || 'All Categories';
        loadListing(Number(url.pathname.match(/\/([1-9][0-9]*)\/?$/)?.[1] || 1), false);
    });

    // Rebind edit behavior for table rows replaced by AJAX.
    document.addEventListener('click', function (event) {
        var button = event.target.closest('[data-asset-edit]');
        if (!button || !page.contains(button)) return;
        var fields = {
            editAssetId: button.dataset.id || '0',
            assetName: button.dataset.name || '',
            assetCategory: button.dataset.category || '',
            assetRarity: button.dataset.rarity || '',
            assetDescription: button.dataset.description || '',
            assetDetail: button.dataset.detail || ''
        };
        Object.keys(fields).forEach(function (id) {
            var field = document.getElementById(id);
            if (field) field.value = fields[id];
        });
        var form = document.querySelector('#assetModal form');
        if (form) form.dataset.editing = '1';
        var title = document.getElementById('assetModalTitle');
        if (title) title.textContent = 'Edit Asset';
        var file = document.getElementById('assetIcon');
        if (file) file.value = '';
        var modal = document.getElementById('assetModal');
        if (modal) {
            modal.classList.add('is-open');
            modal.setAttribute('aria-hidden', 'false');
            document.body.classList.add('modal-open');
        }
    });


})();
