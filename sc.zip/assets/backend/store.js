(() => {
    'use strict';

    const form = document.querySelector('[data-store-product-form]');
    if (!form) return;

    const titleInput = form.querySelector('[data-product-title]');
    const slugInput = form.querySelector('[data-product-slug]');
    const appSelect = form.querySelector('[data-app-select]');
    const typeSelect = form.querySelector('[data-product-type]');
    const specSection = form.querySelector('[data-account-spec-section]');
    const specGroups = form.querySelector('[data-spec-groups]');
    const specInput = form.querySelector('[data-specifications-json]');
    const mediaInput = form.querySelector('[data-media-input]');
    const dropzone = form.querySelector('[data-upload-dropzone]');
    const preview = form.querySelector('[data-new-media-preview]');
    const mediaCount = form.querySelector('[data-media-count]');
    const assetOptionsUrl = form.dataset.assetsUrl || '';
    const existingCount = form.querySelectorAll('.store-media-item.is-existing').length;
    let selectedFiles = [];
    let assetGroups = {};
    let specItems = [];

    try {
        const initial = JSON.parse(form.dataset.initialSpecs || '[]');
        if (Array.isArray(initial)) specItems = initial;
    } catch (error) {
        specItems = [];
    }

    const slugify = value => value.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9\s-]/g, '').trim().replace(/[\s-]+/g, '-').replace(/^-|-$/g, '');

    let slugTouched = Boolean(slugInput && slugInput.value.trim());
    if (slugInput) {
        slugInput.addEventListener('input', () => { slugTouched = true; });
    }
    if (titleInput && slugInput) {
        titleInput.addEventListener('input', () => {
            if (!slugTouched) slugInput.value = slugify(titleInput.value);
        });
    }

    const updateSpecInput = () => {
        specInput.value = JSON.stringify(specItems.map(item => ({
            asset_id: Number(item.asset_id),
            value: String(item.value || '')
        })));
    };

    const createElement = (tag, className, text) => {
        const element = document.createElement(tag);
        if (className) element.className = className;
        if (text !== undefined) element.textContent = text;
        return element;
    };

    const renderSpecItems = () => {
        specGroups.querySelectorAll('[data-spec-added]').forEach(node => node.replaceChildren());
        Object.keys(assetGroups).forEach(category => {
            const holder = specGroups.querySelector(`[data-spec-added="${CSS.escape(category)}"]`);
            if (!holder) return;
            specItems.filter(item => item.category === category).forEach(item => {
                const chip = createElement('span', 'store-spec-chip');
                if (item.icon) {
                    const image = document.createElement('img');
                    image.src = item.icon;
                    image.alt = '';
                    chip.appendChild(image);
                }
                const label = createElement('span', '', item.name + (item.value ? ' · ' + item.value : ''));
                chip.appendChild(label);
                const remove = createElement('button', '', '×');
                remove.type = 'button';
                remove.setAttribute('aria-label', 'Remove ' + item.name);
                remove.addEventListener('click', () => {
                    specItems = specItems.filter(candidate => !(Number(candidate.asset_id) === Number(item.asset_id) && String(candidate.value || '') === String(item.value || '')));
                    updateSpecInput();
                    renderSpecItems();
                });
                chip.appendChild(remove);
                holder.appendChild(chip);
            });
        });
        updateSpecInput();
    };

    const buildSpecGroups = categories => {
        assetGroups = categories || {};
        specGroups.replaceChildren();
        const names = Object.keys(assetGroups);
        if (!names.length) {
            specGroups.appendChild(createElement('div', 'store-spec-loading', 'This App has no categorized assets yet.'));
            specItems = [];
            updateSpecInput();
            return;
        }

        names.forEach(category => {
            const section = createElement('section', 'store-spec-group');
            section.appendChild(createElement('h3', '', category));
            const controls = createElement('div', 'store-spec-controls');
            const select = createElement('select', 'control');
            select.appendChild(new Option('Select ' + category, ''));
            (assetGroups[category] || []).forEach(asset => {
                const label = asset.name + (asset.rarity ? ' · ' + asset.rarity : '');
                select.appendChild(new Option(label, String(asset.id)));
            });
            const value = createElement('input', 'control');
            value.type = 'text';
            value.maxLength = 80;
            value.placeholder = 'Value / Qty';
            const button = createElement('button', 'btn btn-ghost', '+ Add');
            button.type = 'button';
            button.addEventListener('click', () => {
                const selectedId = Number(select.value);
                const asset = (assetGroups[category] || []).find(item => Number(item.id) === selectedId);
                if (!asset) {
                    select.focus();
                    return;
                }
                const itemValue = value.value.trim();
                const duplicate = specItems.some(item => Number(item.asset_id) === selectedId && String(item.value || '') === itemValue);
                if (!duplicate) {
                    specItems.push({
                        asset_id: selectedId,
                        name: asset.name,
                        category,
                        rarity: asset.rarity || '',
                        icon: asset.icon || '',
                        value: itemValue
                    });
                    renderSpecItems();
                }
                select.value = '';
                value.value = '';
            });
            controls.append(select, value, button);
            section.appendChild(controls);
            section.appendChild(createElement('div', 'store-spec-added'));
            section.lastElementChild.setAttribute('data-spec-added', category);
            specGroups.appendChild(section);
        });
        renderSpecItems();
    };

    const loadAssets = async (clearSpecs) => {
        const appId = appSelect ? appSelect.value : '';
        if (!appId) {
            assetGroups = {};
            specGroups.replaceChildren(createElement('div', 'store-spec-loading', 'Choose an App to load its Asset Database categories.'));
            if (clearSpecs) specItems = [];
            updateSpecInput();
            return;
        }
        specGroups.replaceChildren(createElement('div', 'store-spec-loading', 'Loading App Asset Database…'));
        try {
            const response = await fetch(assetOptionsUrl + encodeURIComponent(appId) + '/', {
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                credentials: 'same-origin'
            });
            const result = await response.json();
            if (!response.ok || !result.ok) throw new Error(result.message || 'Unable to load assets.');
            if (clearSpecs) specItems = [];
            buildSpecGroups(result.categories || {});
        } catch (error) {
            specGroups.replaceChildren(createElement('div', 'store-spec-loading', error.message || 'Failed to load Asset Database.'));
        }
    };

    const updateTypeVisibility = () => {
        const isAccount = typeSelect && typeSelect.value === 'Akun';
        specSection.hidden = !isAccount;
        if (isAccount && appSelect && appSelect.value && !Object.keys(assetGroups).length) loadAssets(false);
    };

    if (appSelect) appSelect.addEventListener('change', () => loadAssets(true));
    if (typeSelect) typeSelect.addEventListener('change', updateTypeVisibility);
    updateTypeVisibility();
    if (appSelect && appSelect.value) loadAssets(false);

    const syncFiles = () => {
        if (!mediaInput) return;
        const transfer = new DataTransfer();
        selectedFiles.forEach(file => transfer.items.add(file));
        mediaInput.files = transfer.files;
    };

    const updateMediaCount = () => {
        const removed = form.querySelectorAll('.store-media-item.is-existing input:checked').length;
        const current = existingCount - removed + selectedFiles.length;
        if (mediaCount) mediaCount.textContent = current + '/20 files';
    };

    form.querySelectorAll('.store-media-item.is-existing input').forEach(input => input.addEventListener('change', updateMediaCount));

    let previewUrls = [];
    let draggedFileIndex = null;

    const renderMediaPreview = () => {
        previewUrls.forEach(url => URL.revokeObjectURL(url));
        previewUrls = [];
        preview.replaceChildren();

        selectedFiles.forEach((file, index) => {
            const card = createElement('div', 'store-media-item is-new');
            card.draggable = true;
            card.dataset.fileIndex = String(index);

            let media;
            const url = URL.createObjectURL(file);
            previewUrls.push(url);
            if (file.type === 'video/mp4' || file.name.toLowerCase().endsWith('.mp4')) {
                media = document.createElement('video');
                media.muted = true;
                media.preload = 'metadata';
            } else {
                media = document.createElement('img');
                media.alt = file.name;
            }
            media.src = url;
            card.appendChild(media);

            const dragHandle = createElement('span', 'store-media-drag-handle');
            dragHandle.innerHTML = '<i class="fa-solid fa-grip-vertical" aria-hidden="true"></i>';
            dragHandle.setAttribute('aria-label', 'Drag to reorder media');
            card.appendChild(dragHandle);

            const remove = createElement('button', 'store-media-remove', '×');
            remove.type = 'button';
            remove.setAttribute('aria-label', 'Remove ' + file.name);
            remove.addEventListener('click', () => {
                selectedFiles.splice(index, 1);
                syncFiles();
                renderMediaPreview();
                updateMediaCount();
            });
            card.appendChild(remove);
            card.appendChild(createElement('small', '', file.name));

            card.addEventListener('dragstart', event => {
                draggedFileIndex = index;
                card.classList.add('is-dragging');
                event.dataTransfer.effectAllowed = 'move';
                event.dataTransfer.setData('text/plain', String(index));
            });
            card.addEventListener('dragover', event => {
                if (draggedFileIndex === null) return;
                event.preventDefault();
                event.dataTransfer.dropEffect = 'move';
                card.classList.add('is-drop-target');
            });
            card.addEventListener('dragleave', () => card.classList.remove('is-drop-target'));
            card.addEventListener('drop', event => {
                event.preventDefault();
                card.classList.remove('is-drop-target');
                if (draggedFileIndex === null || draggedFileIndex === index) return;
                const moved = selectedFiles.splice(draggedFileIndex, 1)[0];
                selectedFiles.splice(index, 0, moved);
                draggedFileIndex = null;
                syncFiles();
                renderMediaPreview();
            });
            card.addEventListener('dragend', () => {
                draggedFileIndex = null;
                card.classList.remove('is-dragging');
                preview.querySelectorAll('.is-drop-target').forEach(node => node.classList.remove('is-drop-target'));
            });

            preview.appendChild(card);
        });

        const addTile = createElement('button', 'store-media-add');
        addTile.type = 'button';
        addTile.innerHTML = '<i class="fa-solid fa-plus" aria-hidden="true"></i><span>Add media</span>';
        addTile.addEventListener('click', () => {
            if (!mediaInput) return;
            mediaInput.value = '';
            mediaInput.click();
        });
        preview.appendChild(addTile);
        updateMediaCount();
    };

    const addFiles = files => {
        const chosen = Array.from(files || []);
        const removed = form.querySelectorAll('.store-media-item.is-existing input:checked').length;
        const available = Math.max(0, 20 - (existingCount - removed) - selectedFiles.length);
        const accepted = [];
        const tooLarge = [];
        chosen.forEach(file => {
            if (file.size > 10 * 1024 * 1024) {
                tooLarge.push(file.name);
                return;
            }
            if (accepted.length < available) accepted.push(file);
        });
        accepted.forEach(file => selectedFiles.push(file));
        syncFiles();
        renderMediaPreview();
        if ((chosen.length > accepted.length || tooLarge.length) && window.Swal) {
            const messages = [];
            if (tooLarge.length) messages.push('Maksimal 10 MB per file: ' + tooLarge.join(', '));
            if (chosen.length - tooLarge.length > accepted.length) messages.push('Maksimal 20 file media untuk satu produk.');
            Swal.fire({ icon: 'warning', title: 'Sebagian file tidak ditambahkan', text: messages.join(' '), background: '#17131f', color: '#f5f1fb', confirmButtonColor: '#9857f5' });
        }
    };

    if (mediaInput) {
        mediaInput.addEventListener('click', () => { mediaInput.value = ''; });
        mediaInput.addEventListener('change', () => addFiles(mediaInput.files));
    }
    if (dropzone) {
        ['dragenter', 'dragover'].forEach(eventName => dropzone.addEventListener(eventName, event => {
            event.preventDefault();
            dropzone.classList.add('is-dragover');
        }));
        ['dragleave', 'drop'].forEach(eventName => dropzone.addEventListener(eventName, event => {
            event.preventDefault();
            dropzone.classList.remove('is-dragover');
        }));
        dropzone.addEventListener('drop', event => addFiles(event.dataTransfer.files));
    }

    form.addEventListener('submit', event => {
        if (existingCount - form.querySelectorAll('.store-media-item.is-existing input:checked').length + selectedFiles.length > 20) {
            event.preventDefault();
            if (window.Swal) Swal.fire({ icon: 'error', title: 'Terlalu banyak media', text: 'Maksimal 20 file media untuk satu produk.', background: '#17131f', color: '#f5f1fb', confirmButtonColor: '#9857f5' });
            return;
        }
        if (typeSelect && typeSelect.value === 'Akun' && specItems.length === 0) {
            event.preventDefault();
            if (window.Swal) Swal.fire({ icon: 'warning', title: 'Spesifikasi akun belum diisi', text: 'Tambahkan setidaknya satu Asset Database ke spesifikasi akun.', background: '#17131f', color: '#f5f1fb', confirmButtonColor: '#9857f5' });
            return;
        }
        updateSpecInput();
    });
})();
