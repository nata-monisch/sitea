(() => {
    'use strict';

    const gallery = document.querySelector('[data-store-gallery]');
    if (gallery) {
        const slides = Array.from(gallery.querySelectorAll('[data-gallery-slide]'));
        const thumbs = Array.from(gallery.querySelectorAll('[data-gallery-thumb]'));
        const counter = gallery.querySelector('[data-gallery-counter]');
        let activeIndex = 0;
        let autoSlideTimer = null;
        let autoSlideStoppedByUser = false;
        const AUTO_SLIDE_DELAY = 4000;

        const stopAutoSlide = () => {
            autoSlideStoppedByUser = true;
            if (autoSlideTimer !== null) {
                window.clearInterval(autoSlideTimer);
                autoSlideTimer = null;
            }
        };

        const showSlide = index => {
            if (!slides.length) return;
            const previousIndex = activeIndex;
            activeIndex = (index + slides.length) % slides.length;
            const slideChanged = previousIndex !== activeIndex;

            slides.forEach((slide, slideIndex) => {
                const active = slideIndex === activeIndex;
                slide.classList.remove('is-entering');
                slide.hidden = !active;
                slide.classList.toggle('is-active', active);
                const video = slide.querySelector('video');
                if (video && !active) {
                    video.pause();
                }
            });

            // Replay the entrance animation whenever the active image changes.
            if (slideChanged) {
                const activeSlide = slides[activeIndex];
                void activeSlide.offsetWidth;
                activeSlide.classList.add('is-entering');
            }

            thumbs.forEach((thumb, thumbIndex) => {
                const active = thumbIndex === activeIndex;
                thumb.classList.toggle('is-active', active);
                thumb.setAttribute('aria-pressed', active ? 'true' : 'false');
            });

            if (counter) counter.textContent = `${activeIndex + 1} / ${slides.length}`;
        };

        gallery.querySelector('[data-gallery-prev]')?.addEventListener('click', () => {
            stopAutoSlide();
            showSlide(activeIndex - 1);
        });
        gallery.querySelector('[data-gallery-next]')?.addEventListener('click', () => {
            stopAutoSlide();
            showSlide(activeIndex + 1);
        });
        thumbs.forEach(thumb => thumb.addEventListener('click', () => {
            stopAutoSlide();
            showSlide(Number(thumb.dataset.galleryThumb || 0));
        }));
        showSlide(0);

        // Rotate the gallery every four seconds until the visitor changes it manually.
        if (slides.length > 1) {
            autoSlideTimer = window.setInterval(() => {
                if (!document.hidden && !autoSlideStoppedByUser) {
                    showSlide(activeIndex + 1);
                }
            }, AUTO_SLIDE_DELAY);
        }
    }

    const tabs = document.querySelector('[data-store-tabs]');
    if (tabs) {
        const buttons = Array.from(tabs.querySelectorAll('[data-store-tab]'));
        const panels = Array.from(tabs.querySelectorAll('[data-store-panel]'));

        const activateTab = id => {
            buttons.forEach(button => {
                const active = button.dataset.storeTab === id;
                button.classList.toggle('is-active', active);
                button.setAttribute('aria-selected', active ? 'true' : 'false');
                button.tabIndex = active ? 0 : -1;
            });
            panels.forEach(panel => {
                panel.hidden = panel.dataset.storePanel !== id;
            });
        };

        buttons.forEach((button, index) => {
            button.addEventListener('click', () => activateTab(button.dataset.storeTab));
            button.addEventListener('keydown', event => {
                if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
                event.preventDefault();
                let nextIndex = index;
                if (event.key === 'ArrowRight') nextIndex = (index + 1) % buttons.length;
                if (event.key === 'ArrowLeft') nextIndex = (index - 1 + buttons.length) % buttons.length;
                if (event.key === 'Home') nextIndex = 0;
                if (event.key === 'End') nextIndex = buttons.length - 1;
                buttons[nextIndex].focus();
                activateTab(buttons[nextIndex].dataset.storeTab);
            });
        });

        if (buttons.length) activateTab(buttons[0].dataset.storeTab);
    }
})();
