<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Web_Storage extends MY_Controller
{
    public function index()
    {
        $this->require_login();
        $this->prepare_backend('Website Settings - Storage', 'Website Settings - GitHub Storage', 'web-storage');
        $this->data['title'] = 'GitHub Storage - ' . $this->data['website']['name'];
        $this->data['description'] = $this->data['website']['description'];
        $this->data['thumbnail'] = $this->data['website']['banner'];

        if ($this->input->method(TRUE) === 'POST') {
            $action = (string) $this->input->post('github_action', TRUE);
            $this->handle_github_settings($action);
            if (!$this->data['flash_error'] && !$this->data['form_errors']) {
                redirect('backend/web-storage/');
                return;
            }
        }

        $this->data['website'] = $this->website_model->get_settings();
        $this->load_github_repository_options();
        $this->render_backend('backend/website/storage');
    }

    private function handle_github_settings($action)
    {
        if ($action === 'disconnect') {
            $ok = $this->website_model->update_settings(array(
                'github_token' => '',
                'github_account' => '',
                'github_owner' => '',
                'github_repository' => '',
                'github_branch' => ''
            ));
            if ($ok) {
                $this->session->set_flashdata('success', 'Koneksi GitHub berhasil diputus. File asset yang sudah tersimpan di repository tidak dihapus.');
            } else {
                $this->data['flash_error'] = 'Koneksi GitHub gagal diputus dari database.';
            }
            return;
        }

        if ($action !== 'connect') {
            $this->data['flash_error'] = 'Aksi GitHub tidak dikenal.';
            return;
        }
        if (empty($this->config->item('encryption_key'))) {
            $this->data['flash_error'] = 'Sebelum menyimpan PAT, isi encryption_key yang kuat di application/config/config.php. Lihat README instalasi.';
            return;
        }

        $this->load->library('encryption');
        $this->load->library('github_storage');
        $new_token = trim((string) $this->input->post('github_pat', FALSE));
        $encrypted_token = !empty($this->data['website']['github_token']) ? $this->data['website']['github_token'] : '';
        $token = $new_token;
        if ($token === '' && $encrypted_token !== '') {
            $token = $this->encryption->decrypt($encrypted_token);
        }
        if (!is_string($token) || $token === '') {
            $this->data['flash_error'] = 'Masukkan Personal Access Token GitHub terlebih dahulu.';
            return;
        }

        $user_result = $this->github_storage->authenticated_user($token);
        if (!$user_result['ok'] || empty($user_result['data']['login'])) {
            $this->data['flash_error'] = 'GitHub connection gagal: ' . $user_result['error'];
            return;
        }
        $repo_result = $this->github_storage->public_repositories($token);
        if (!$repo_result['ok']) {
            $this->data['flash_error'] = 'Tidak dapat mengambil daftar repository: ' . $repo_result['error'];
            return;
        }

        $selected_repo = trim((string) $this->input->post('github_repository', TRUE));
        if ($selected_repo === '' && !empty($this->data['website']['github_owner']) && !empty($this->data['website']['github_repository'])) {
            $selected_repo = $this->data['website']['github_owner'] . '/' . $this->data['website']['github_repository'];
        }

        $selected = null;
        if ($selected_repo !== '') {
            foreach ($repo_result['data'] as $repo) {
                if ($repo['full_name'] === $selected_repo) {
                    $selected = $repo;
                    break;
                }
            }
            if (!$selected) {
                $this->data['flash_error'] = 'Repository tidak ditemukan dalam daftar repository publik yang dapat diakses PAT ini. Pastikan token memiliki akses ke repository tersebut.';
                return;
            }
        }

        $branch = trim((string) $this->input->post('github_branch', TRUE));
        if ($branch === '' && $selected) {
            $branch = $selected['default_branch'];
        }
        if (!preg_match('/^[A-Za-z0-9._-]{1,100}$/', $branch)) {
            $this->data['flash_error'] = 'Nama branch hanya boleh berisi huruf, angka, titik, garis bawah, dan tanda minus.';
            return;
        }

        $update = array(
            'github_account' => $user_result['data']['login'],
            'github_branch' => $branch
        );
        if ($new_token !== '') {
            $update['github_token'] = $this->encryption->encrypt($token);
        }
        if ($selected) {
            $parts = explode('/', $selected['full_name'], 2);
            $update['github_owner'] = $parts[0];
            $update['github_repository'] = $parts[1];
        } elseif ($new_token !== '') {
            // A new token may not have access to the previously selected repository.
            $update['github_owner'] = '';
            $update['github_repository'] = '';
        }

        if ($this->website_model->update_settings($update)) {
            $message = 'GitHub berhasil terhubung sebagai @' . $user_result['data']['login'] . '.';
            if ($selected) {
                $message .= ' Repository ' . $selected['full_name'] . ' siap digunakan.';
            } else {
                $message .= ' Pilih repository publik untuk mengaktifkan upload asset.';
            }
            $this->session->set_flashdata('success', $message);
        } else {
            $this->data['flash_error'] = 'Pengaturan GitHub gagal disimpan ke database.';
        }
    }

    private function load_github_repository_options()
    {
        $this->data['github_repositories'] = array();
        $this->data['github_connection_error'] = '';
        $website = $this->data['website'];
        if (empty($website['github_token'])) {
            return;
        }
        if (empty($this->config->item('encryption_key'))) {
            $this->data['github_connection_error'] = 'Encryption key belum diatur. Token tersimpan tidak dapat dibuka.';
            return;
        }

        $this->load->library('encryption');
        $token = $this->encryption->decrypt($website['github_token']);
        if (!is_string($token) || $token === '') {
            $this->data['github_connection_error'] = 'Token tidak dapat dibuka. Periksa encryption_key.';
            return;
        }
        $this->load->library('github_storage');
        $result = $this->github_storage->public_repositories($token);
        if (!$result['ok']) {
            $this->data['github_connection_error'] = $result['error'];
            return;
        }
        $this->data['github_repositories'] = $result['data'];
    }
}
