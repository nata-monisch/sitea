<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends MY_Controller
{
    public function index()
    {
        if ($this->session->userdata('user_id')) {
            redirect('backend/');
            return;
        }

        $this->load->model('backend/Website_Models', 'website_model');
        $this->data['website'] = $this->website_model->get_settings();
        if (!$this->data['website']) {
            show_error('Data konfigurasi website tidak ditemukan di tabel website. Isi data website terlebih dahulu.', 500);
            return;
        }

        $this->data['title'] = 'Sign in - ' . $this->data['website']['name'];
        $this->data['description'] = 'Enter your credentials to access your account.';
        $this->data['thumbnail'] = $this->data['website']['banner'];
        $this->data['error'] = $this->session->flashdata('error');
        $this->data['form_errors'] = '';
        $this->data['page_url'] = rtrim(current_url(), '/') . '/';

        if ($this->input->method(TRUE) === 'POST') {
            $this->form_validation->set_rules('identity', 'Username', 'trim|required|max_length[60]');
            $this->form_validation->set_rules('password', 'Password', 'required|max_length[255]');

            if ($this->form_validation->run()) {
                $this->load->model('backend/Auth_Models', 'auth_model');
                $identity = trim((string) $this->input->post('identity', TRUE));
                $password = (string) $this->input->post('password', FALSE);
                $account = $this->auth_model->find_by_username($identity);

                if ($account && password_verify($password, $account['password'])) {
                    $this->session->sess_regenerate(TRUE);
                    $this->session->set_userdata(array(
                        'user_id' => (int) $account['user_id'],
                        'username' => $account['username'],
                        'display_name' => $account['display_name']
                    ));
                    redirect('backend/');
                    return;
                }

                // Use one generic message to avoid disclosing whether a username exists.
                $this->data['error'] = 'Username atau password salah.';
            } else {
                $this->data['form_errors'] = validation_errors();
            }
        }

        $this->load->view('backend/auth', $this->data);
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect('auth/');
    }
}
