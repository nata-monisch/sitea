<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Web_Social extends MY_Controller
{
    public function index()
    {
        $this->require_login();
        $this->prepare_backend('Website Settings - Social Links', 'Website Settings - Social Links', 'web-social');
        $this->data['title'] = 'Website Social Links - ' . $this->data['website']['name'];
        $this->data['description'] = 'Add links where visitors can find and connect with you.';
        $this->data['thumbnail'] = $this->data['website']['banner'];

        if ($this->input->method(TRUE) === 'POST') {
            $this->form_validation->set_rules('facebook', 'Facebook', 'trim|max_length[255]');
            $this->form_validation->set_rules('instagram', 'Instagram', 'trim|max_length[255]');
            $this->form_validation->set_rules('discord', 'Discord', 'trim|max_length[255]');
            $this->form_validation->set_rules('tiktok', 'TikTok', 'trim|max_length[255]');
            $this->form_validation->set_rules('youtube', 'YouTube', 'trim|max_length[255]');

            if ($this->form_validation->run()) {
                $update = array();
                $invalid = '';
                foreach (array('facebook', 'instagram', 'discord', 'tiktok', 'youtube') as $field) {
                    $value = $this->safe_social_url($this->input->post($field, TRUE));
                    if ($value === false) {
                        $invalid = ucfirst($field) . ' harus berupa URL http:// atau https:// yang valid.';
                        break;
                    }
                    $update[$field] = $value;
                }
                if ($invalid !== '') {
                    $this->data['flash_error'] = $invalid;
                } elseif ($this->website_model->update_settings($update)) {
                    $this->session->set_flashdata('success', 'Social links website berhasil disimpan.');
                    redirect('backend/web-social/');
                    return;
                } else {
                    $this->data['flash_error'] = 'Social links gagal disimpan ke database.';
                }
            } else {
                $this->data['form_errors'] = validation_errors();
            }
        }

        $this->data['website'] = $this->website_model->get_settings();
        $this->render_backend('backend/website/social');
    }
}
