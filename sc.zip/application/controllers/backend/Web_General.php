<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Web_General extends MY_Controller
{
    public function index()
    {
        $this->require_login();
        $this->prepare_backend('Website Settings - General', 'Website Settings - General', 'web-general');
        $this->data['title'] = 'Website General Settings - ' . $this->data['website']['name'];
        $this->data['description'] = 'Basic information displayed across your website.';
        $this->data['thumbnail'] = $this->data['website']['banner'];

        if ($this->input->method(TRUE) === 'POST') {
            $this->handle_general_settings();
            if (!$this->data['flash_error'] && !$this->data['form_errors']) {
                redirect('backend/web-general/');
                return;
            }
        }

        $this->data['website'] = $this->website_model->get_settings();
        $this->render_backend('backend/website/general');
    }

    private function handle_general_settings()
    {
        $this->form_validation->set_rules('name', 'Website name', 'trim|required|max_length[180]');
        $this->form_validation->set_rules('cdn_url', 'Custom CDN URL', 'trim|max_length[255]');
        $this->form_validation->set_rules('google_verif', 'Google verification', 'trim|max_length[255]');
        $this->form_validation->set_rules('bing_verif', 'Bing verification', 'trim|max_length[255]');
        $this->form_validation->set_rules('description', 'Description', 'trim');
        $this->form_validation->set_rules('announcement', 'Announcement', 'trim');

        if (!$this->form_validation->run()) {
            $this->data['form_errors'] = validation_errors();
            return;
        }

        $cdn_url = trim((string) $this->input->post('cdn_url', TRUE));

        $saved = $this->website_model->update_settings(array(
            'name' => trim((string) $this->input->post('name', TRUE)),
            'cdn_url' => $cdn_url,
            'description' => trim((string) $this->input->post('description', TRUE)),
            'google_verif' => trim((string) $this->input->post('google_verif', TRUE)),
            'bing_verif' => trim((string) $this->input->post('bing_verif', TRUE)),
            'announcement' => trim((string) $this->input->post('announcement', TRUE))
        ));

        if ($saved) {
            $this->session->set_flashdata('success', 'General Website Settings berhasil disimpan.');
        } else {
            $this->data['flash_error'] = 'Pengaturan gagal disimpan ke database.';
        }
    }

}
