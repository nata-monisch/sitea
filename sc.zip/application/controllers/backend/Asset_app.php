<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Asset_app extends MY_Controller
{
    private $allowed_extensions = array('png', 'jpg', 'jpeg', 'webp', 'svg');

    public function index($app_slug = '', $page = 1)
    {
        $this->require_login();
        $this->prepare_backend('Asset App', 'Asset Management / Asset App', 'asset-app');
        $this->load->model('backend/Asset_App_Models', 'asset_model');

        $this->data['title'] = 'Asset App - ' . $this->data['website']['name'];
        $this->data['description'] = 'Manage game apps and their assets.';
        $this->data['apps'] = $this->asset_model->get_apps();
        foreach ($this->data['apps'] as &$app_row) {
            $app_row['slug'] = $this->safe_slug($app_row['name']);
        }
        unset($app_row);
        $this->data['github_repositories'] = array();
        $this->data['github_error'] = '';
        $this->data['flash_error'] = !empty($this->data['flash_error']) ? $this->data['flash_error'] : '';
        $this->load_github_repositories();

        $is_post = $this->input->method(TRUE) === 'POST';
        $action = $is_post ? (string) $this->input->post('action', TRUE) : '';
        $selected_app = NULL;
        $app_slug = strtolower(trim((string) $app_slug));

        if ($app_slug !== '') {
            $slug_matches = array();
            foreach ($this->data['apps'] as $app_row) {
                if ($this->safe_slug($app_row['name']) === $app_slug) {
                    $slug_matches[] = $app_row;
                }
            }
            if (count($slug_matches) !== 1) {
                show_404();
                return;
            }
            $selected_app = $slug_matches[0];
        } else {
            // Keep old ?app=ID links working, but redirect them to the new slug URL.
            $requested_id = (int) $this->input->get('app', TRUE);
            if ($is_post && $action !== 'create_app') {
                $requested_id = (int) $this->input->post('app_id');
            }
            if ($requested_id > 0) {
                $selected_app = $this->asset_model->get_app($requested_id);
            }
            if (!$selected_app && !empty($this->data['apps'])) {
                $selected_app = $this->data['apps'][0];
            }

            if ($selected_app) {
                $app_slug = $this->safe_slug($selected_app['name']);
            }
            if (!$is_post && $selected_app) {
                redirect('backend/asset-app/' . $app_slug . '/1/', 'location', 301);
                return;
            }
        }

        // Canonical listing URLs always include the page number, including page 1.
        if (!$is_post && $app_slug !== '' && func_num_args() < 2) {
            $canonical_url = 'backend/asset-app/' . $app_slug . '/1/';
            $query_params = array();
            foreach (array('search', 'category', 'rarity') as $filter_key) {
                $filter_value = trim((string) $this->input->get($filter_key, TRUE));
                if ($filter_value !== '') {
                    $query_params[$filter_key] = $filter_value;
                }
            }
            if (!empty($query_params)) {
                $canonical_url .= '?' . http_build_query($query_params);
            }
            redirect($canonical_url, 'location', 301);
            return;
        }

        if ($is_post) {
            if ($action === 'create_app') {
                $this->create_app();
            } elseif (!$selected_app) {
                $this->data['flash_error'] = 'Pilih App terlebih dahulu.';
            } elseif ((int) $this->input->post('app_id') !== (int) $selected_app['id']) {
                $this->data['flash_error'] = 'App yang dipilih tidak sesuai dengan halaman ini.';
            } elseif ($action === 'delete_app') {
                $this->delete_app();
            } elseif ($action === 'edit_app') {
                $this->edit_app();
            } elseif ($action === 'save_asset') {
                $this->save_asset();
            } elseif ($action === 'delete_asset') {
                $this->delete_asset();
            } else {
                $this->data['flash_error'] = 'Aksi tidak dikenal.';
            }

            if (empty($this->data['flash_error'])) {
                if ($action === 'delete_app') {
                    redirect('backend/asset-app/');
                    return;
                }

                $redirect_app = $this->asset_model->get_app((int) $selected_app['id']);
                if ($action === 'edit_app' && $redirect_app) {
                    $app_slug = $this->safe_slug($redirect_app['name']);
                    $page = 1;
                }
                if ($action === 'save_asset' && (int) $this->input->post('asset_id') === 0) {
                    // A newly created asset is at the top of the newest-first list.
                    $page = 1;
                }

                $query_params = array();
                foreach (array('search', 'category', 'rarity') as $filter_key) {
                    $filter_value = trim((string) $this->input->get($filter_key, TRUE));
                    if ($filter_value !== '') {
                        $query_params[$filter_key] = $filter_value;
                    }
                }
                $redirect_url = 'backend/asset-app/' . $app_slug . '/' . max(1, (int) $page) . '/';
                if (!empty($query_params)) {
                    $redirect_url .= '?' . http_build_query($query_params);
                }
                redirect($redirect_url);
                return;
            }
        }

        if ($selected_app) {
            $selected_app['slug'] = $this->safe_slug($selected_app['name']);
            $filters = array(
                'search' => trim((string) $this->input->get('search', TRUE)),
                'category' => trim((string) $this->input->get('category', TRUE)),
                'rarity' => trim((string) $this->input->get('rarity', TRUE))
            );

            $page = max(1, (int) $page);
            $per_page = 50;
            $total_assets = $this->asset_model->count_assets($selected_app['id'], $filters);
            $total_pages = max(1, (int) ceil($total_assets / $per_page));

            if ($page > $total_pages) {
                $correct_url = 'backend/asset-app/' . $selected_app['slug'] . '/' . $total_pages . '/';
                $query_params = array_filter($filters, function ($value) { return $value !== ''; });
                if (!empty($query_params)) {
                    $correct_url .= '?' . http_build_query($query_params);
                }
                redirect($correct_url, 'location', 301);
                return;
            }

            $offset = ($page - 1) * $per_page;
            $this->data['selected_app'] = $selected_app;
            $this->data['assets'] = $this->asset_model->get_assets($selected_app['id'], $per_page, $offset, $filters);
            $this->data['asset_filter_options'] = $this->asset_model->get_asset_filter_options($selected_app['id']);
            $this->data['asset_filters'] = $filters;
            $this->data['asset_total'] = $total_assets;
            $this->data['asset_all_total'] = $this->asset_model->count_assets($selected_app['id']);
            $this->data['asset_page'] = $page;
            $this->data['asset_per_page'] = $per_page;
            $this->data['asset_total_pages'] = $total_pages;
            $this->data['asset_offset'] = $offset;
            $this->data['asset_from'] = $total_assets > 0 ? $offset + 1 : 0;
            $this->data['asset_to'] = min($offset + count($this->data['assets']), $total_assets);

            $query_params = array_filter($filters, function ($value) { return $value !== ''; });
            $this->data['asset_filter_query'] = !empty($query_params) ? http_build_query($query_params) : '';
            $this->data['asset_filter_action'] = site_url('backend/asset-app/' . $selected_app['slug'] . '/1/');
            $listing_path = 'backend/asset-app/' . $selected_app['slug'] . '/' . $page . '/';
            $this->data['asset_post_action'] = site_url($listing_path) . ($this->data['asset_filter_query'] !== '' ? '?' . $this->data['asset_filter_query'] : '');
        } else {
            $this->data['selected_app'] = NULL;
            $this->data['assets'] = array();
            $this->data['asset_filter_options'] = array('categories' => array(), 'rarities' => array());
            $this->data['asset_filters'] = array('search' => '', 'category' => '', 'rarity' => '');
            $this->data['asset_total'] = 0;
            $this->data['asset_all_total'] = 0;
            $this->data['asset_page'] = 1;
            $this->data['asset_total_pages'] = 1;
            $this->data['asset_offset'] = 0;
            $this->data['asset_from'] = 0;
            $this->data['asset_to'] = 0;
            $this->data['asset_filter_query'] = '';
            $this->data['asset_filter_action'] = site_url('backend/asset-app/');
            $this->data['asset_post_action'] = site_url('backend/asset-app/');
        }


        // AJAX listing response: return only the asset-list fragments, not the full backend layout.
        if ($selected_app && $this->input->is_ajax_request() && $this->input->get('ajax', TRUE) === '1') {
            $html = $this->load->view('backend/asset-app-list', $this->data, TRUE);
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'ok' => true,
                    'html' => $html,
                    'page' => (int) $this->data['asset_page'],
                    'total_pages' => (int) $this->data['asset_total_pages']
                )));
            return;
        }

        $this->render_backend('backend/asset-app');
    }

    private function github_credentials()
    {
        $website = $this->data['website'];
        if (empty($website['github_token']) || empty($this->config->item('encryption_key'))) {
            return array('ok' => false, 'error' => 'Hubungkan GitHub terlebih dahulu di Website Settings → GitHub Storage.');
        }
        $this->load->library('encryption');
        $token = $this->encryption->decrypt($website['github_token']);
        if (!is_string($token) || $token === '') return array('ok' => false, 'error' => 'Token GitHub tidak dapat dibuka. Periksa encryption_key.');
        $this->load->library('github_storage');
        return array('ok' => true, 'token' => $token, 'owner' => $website['github_account']);
    }

    private function load_github_repositories()
    {
        $credentials = $this->github_credentials();
        if (!$credentials['ok']) { $this->data['github_error'] = $credentials['error']; return; }
        $result = $this->github_storage->repositories($credentials['token']);
        if (!$result['ok']) { $this->data['github_error'] = 'GitHub: ' . $result['error']; return; }
        $this->load->model('backend/Asset_App_Models', 'asset_model');
        $used = $this->asset_model->get_used_repositories();
        $used_map = array();
        foreach ($used as $repo) $used_map[strtolower($repo['github_owner'] . '/' . $repo['github_repository'])] = true;
        foreach ($result['data'] as $repo) {
            if (!isset($used_map[strtolower($repo['full_name'])])) $this->data['github_repositories'][] = $repo;
        }
    }

    private function safe_slug($value)
    {
        $value = strtolower(trim($value));
        $value = preg_replace('/[^a-z0-9]+/', '-', $value);
        return trim($value, '-') ?: 'app';
    }

    private function upload_to_repository($file_field, $owner, $repository, $branch, $base_path, $max_size = 10240)
    {
        if (empty($_FILES[$file_field]['name'])) return array('ok' => true, 'path' => '', 'url' => '');
        $file = $_FILES[$file_field];
        if ($file['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) return array('ok' => false, 'error' => 'File upload tidak valid.');
        if (empty($file['size']) || $file['size'] > $max_size * 1024) return array('ok' => false, 'error' => 'Ukuran file maksimal ' . round($max_size / 1024, 1) . ' MB.');
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $this->allowed_extensions, true)) return array('ok' => false, 'error' => 'Format file harus PNG, JPG, JPEG, WEBP, atau SVG.');
        $contents = @file_get_contents($file['tmp_name']);
        if ($contents === false || $contents === '') return array('ok' => false, 'error' => 'File tidak dapat dibaca.');
        if ($ext === 'svg') {
            if (stripos($contents, '<svg') === false || preg_match('/<script\b|onload\s*=|javascript:/i', $contents)) return array('ok' => false, 'error' => 'File SVG tidak valid atau mengandung script.');
        } else {
            $info = @getimagesize($file['tmp_name']);
            $mime = array('png'=>'image/png','jpg'=>'image/jpeg','jpeg'=>'image/jpeg','webp'=>'image/webp');
            if (!$info || $info['mime'] !== $mime[$ext]) return array('ok' => false, 'error' => 'Isi file tidak sesuai dengan ekstensi gambar.');
        }
        $path = trim($base_path, '/') . '-' . date('YmdHis') . '-' . mt_rand(100,999) . '.' . $ext;
        $result = $this->github_storage->put_file($owner, $repository, $path, $branch, $this->github_credentials()['token'], $contents, 'Upload app asset: ' . basename($path));
        if (!$result['ok']) return array('ok' => false, 'error' => 'GitHub: ' . $result['error']);
        $url = 'https://cdn.jsdelivr.net/gh/' . rawurlencode($owner) . '/' . rawurlencode($repository) . '@' . rawurlencode($branch) . '/' . $path;
        return array('ok' => true, 'path' => $path, 'url' => $url);
    }

    private function delete_repo_file($owner, $repo, $branch, $path)
    {
        if (!$path) return true;
        $credentials = $this->github_credentials();
        if (!$credentials['ok']) return false;
        $result = $this->github_storage->delete_file($owner, $repo, $path, $branch, $credentials['token'], 'Delete app asset');
        return !empty($result['ok']);
    }

    /**
     * Copy an existing icon to its new category/rarity/name path.
     * The old GitHub file is retained until the database update succeeds.
     */
    private function relocate_asset_icon($app, $existing, $name, $category, $rarity)
    {
        $old_path = isset($existing['icon_path']) ? trim($existing['icon_path'], '/') : '';
        if ($old_path === '') {
            return array('ok' => true, 'path' => '', 'url' => isset($existing['icon']) ? $existing['icon'] : '', 'old_path' => '');
        }

        $category_folder = $category !== '' ? $this->safe_slug($category) : 'uncategorized';
        $rarity_folder = $rarity !== '' ? $this->safe_slug($rarity) : 'unrated';
        $old_filename = basename($old_path);
        $extension = strtolower(pathinfo($old_filename, PATHINFO_EXTENSION));
        $old_stem = pathinfo($old_filename, PATHINFO_FILENAME);
        $suffix = '';
        if (preg_match('/-([0-9]{14}-[0-9]{3})$/', $old_stem, $matches)) {
            $suffix = '-' . $matches[1];
        } else {
            $suffix = '-' . date('YmdHis') . '-' . mt_rand(100, 999);
        }

        $new_path = $category_folder . '/' . $rarity_folder . '/' . $this->safe_slug($name) . $suffix;
        if ($extension !== '') $new_path .= '.' . $extension;
        if ($new_path === $old_path) {
            return array('ok' => true, 'path' => $old_path, 'url' => $existing['icon'], 'old_path' => '');
        }

        $credentials = $this->github_credentials();
        if (!$credentials['ok']) return array('ok' => false, 'error' => $credentials['error']);

        $file = $this->github_storage->get_file(
            $app['github_owner'], $app['github_repository'], $old_path,
            $app['github_branch'], $credentials['token']
        );
        if (!$file['ok']) {
            return array('ok' => false, 'error' => 'Tidak dapat membaca file lama dari GitHub: ' . $file['error']);
        }

        $file_data = $file['data'];
        // Contents API may omit content for files larger than 1 MiB.
        if (empty($file_data['content']) && !empty($file_data['sha'])) {
            $blob = $this->github_storage->get_blob(
                $app['github_owner'], $app['github_repository'],
                $file_data['sha'], $credentials['token']
            );
            if ($blob['ok']) $file_data = $blob['data'];
        }
        if (empty($file_data['content']) || empty($file_data['encoding']) || $file_data['encoding'] !== 'base64') {
            return array('ok' => false, 'error' => 'Konten icon lama tidak tersedia dalam format base64 dari GitHub.');
        }

        $contents = base64_decode(preg_replace('/\\s+/', '', $file_data['content']), true);
        if ($contents === false || $contents === '') {
            return array('ok' => false, 'error' => 'Konten icon lama tidak dapat dibaca.');
        }

        $uploaded = $this->github_storage->put_file(
            $app['github_owner'], $app['github_repository'], $new_path,
            $app['github_branch'], $credentials['token'], $contents,
            'Move app asset: ' . basename($new_path)
        );
        if (!$uploaded['ok']) {
            return array('ok' => false, 'error' => 'Gagal memindahkan icon ke folder baru: ' . $uploaded['error']);
        }

        $url = 'https://cdn.jsdelivr.net/gh/' . rawurlencode($app['github_owner']) . '/'
            . rawurlencode($app['github_repository']) . '@' . rawurlencode($app['github_branch']) . '/' . $new_path;
        return array('ok' => true, 'path' => $new_path, 'url' => $url, 'old_path' => $old_path);
    }

    private function create_app()
    {
        $this->load->model('backend/Asset_App_Models', 'asset_model');
        $name = trim((string) $this->input->post('name', TRUE));
        $description = trim((string) $this->input->post('description', TRUE));
        $publisher = trim((string) $this->input->post('publisher', TRUE));
        $mode = (string) $this->input->post('repository_mode', TRUE);
        $this->form_validation->set_rules('name', 'Nama App', 'trim|required|min_length[2]|max_length[120]');
        $this->form_validation->set_rules('publisher', 'Publisher', 'trim|required|max_length[120]');
        if (!$this->form_validation->run()) { $this->data['flash_error'] = strip_tags(validation_errors(' ', ' ')); return; }
        if ($this->asset_model->name_exists($name)) { $this->data['flash_error'] = 'Nama App sudah digunakan.'; return; }
        $credentials = $this->github_credentials();
        if (!$credentials['ok']) { $this->data['flash_error'] = $credentials['error']; return; }

        $owner = '';
        $repo = '';
        $branch = 'main';
        if ($mode === 'existing') {
            $full_name = trim((string) $this->input->post('existing_repository', TRUE));
            $this->load_github_repositories();
            $found = null;
            foreach ($this->data['github_repositories'] as $item) if ($item['full_name'] === $full_name) $found = $item;
            if (!$found) { $this->data['flash_error'] = 'Repository tidak tersedia atau sudah digunakan App lain.'; return; }
            $owner = $found['owner']; $repo = $found['name']; $branch = $found['default_branch'];
        } elseif ($mode === 'new') {
            $repo_name = $this->safe_slug($name);
            $this->load->model('backend/Asset_App_Models', 'asset_model');
            if ($this->asset_model->repository_exists($credentials['owner'], $repo_name)) { $this->data['flash_error'] = 'Repository dengan nama tersebut sudah terdaftar di Asset App.'; return; }
            $created = $this->github_storage->create_repository($credentials['token'], $repo_name, $description);
            if (!$created['ok']) { $this->data['flash_error'] = 'Gagal membuat repository GitHub: ' . $created['error']; return; }
            $owner = $created['data']['owner']['login'];
            $repo = $created['data']['name'];
            $branch = !empty($created['data']['default_branch']) ? $created['data']['default_branch'] : 'main';
        } else { $this->data['flash_error'] = 'Pilih repository terlebih dahulu.'; return; }

        $slug = $this->safe_slug($name);
        $logo = $this->upload_to_repository('logo', $owner, $repo, $branch, 'logo');
        if (!$logo['ok']) { $this->data['flash_error'] = 'Logo: ' . $logo['error']; return; }
        $banner = $this->upload_to_repository('banner', $owner, $repo, $branch, 'Banner');
        if (!$banner['ok']) {
            if ($logo['path']) $this->delete_repo_file($owner, $repo, $branch, $logo['path']);
            $this->data['flash_error'] = 'Banner: ' . $banner['error']; return;
        }
        $new_id = $this->asset_model->insert_app(array(
            'name' => $name, 'description' => $description, 'logo' => $logo['url'],
            'banner' => $banner['url'], 'publisher' => $publisher,
            'github_owner' => $owner, 'github_repository' => $repo, 'github_branch' => $branch,
            'logo_path' => $logo['path'], 'banner_path' => $banner['path']
        ));
        if (!$new_id) {
            if ($logo['path']) $this->delete_repo_file($owner, $repo, $branch, $logo['path']);
            if ($banner['path']) $this->delete_repo_file($owner, $repo, $branch, $banner['path']);
            $this->data['flash_error'] = 'App gagal disimpan ke database.';
            return;
        }
        $this->session->set_flashdata('success', 'App ' . $name . ' berhasil dibuat dan repository GitHub sudah terhubung.');
        redirect('backend/asset-app/' . $this->safe_slug($name) . '/1/');
        exit;
    }

    private function edit_app()
    {
        $this->load->model('backend/Asset_App_Models', 'asset_model');
        $id = (int) $this->input->post('app_id');
        $app = $this->asset_model->get_app($id);
        if (!$app) {
            $this->data['flash_error'] = 'App tidak ditemukan.';
            return;
        }

        $name = trim((string) $this->input->post('edit_name', TRUE));
        $publisher = trim((string) $this->input->post('edit_publisher', TRUE));
        $description = trim((string) $this->input->post('edit_description', FALSE));

        if (strlen($name) < 2 || strlen($name) > 120 || $publisher === '' || strlen($publisher) > 120) {
            $this->data['flash_error'] = 'Nama App (2–120 karakter) dan Publisher wajib diisi.';
            return;
        }

        foreach ($this->asset_model->get_apps() as $other) {
            if ((int) $other['id'] !== $id && strcasecmp($other['name'], $name) === 0) {
                $this->data['flash_error'] = 'Nama App sudah digunakan.';
                return;
            }
        }

        $new_files = array();
        $payload = array(
            'name' => $name,
            'description' => $description,
            'publisher' => $publisher
        );

        // Replace the app icon only when a new file was selected.
        if (!empty($_FILES['edit_logo']['name'])) {
            $logo = $this->upload_to_repository(
                'edit_logo',
                $app['github_owner'],
                $app['github_repository'],
                $app['github_branch'],
                'logo',
                10240
            );

            if (!$logo['ok']) {
                $this->data['flash_error'] = 'App Icon: ' . $logo['error'];
                return;
            }

            $payload['logo'] = $logo['url'];
            $payload['logo_path'] = $logo['path'];
            if ($logo['path'] !== '') {
                $new_files[] = $logo['path'];
            }
        }

        // Replace the app banner only when a new file was selected.
        if (!empty($_FILES['edit_banner']['name'])) {
            $banner = $this->upload_to_repository(
                'edit_banner',
                $app['github_owner'],
                $app['github_repository'],
                $app['github_branch'],
                'Banner',
                10240
            );

            if (!$banner['ok']) {
                foreach ($new_files as $path) {
                    $this->delete_repo_file($app['github_owner'], $app['github_repository'], $app['github_branch'], $path);
                }
                $this->data['flash_error'] = 'App Banner: ' . $banner['error'];
                return;
            }

            $payload['banner'] = $banner['url'];
            $payload['banner_path'] = $banner['path'];
            if ($banner['path'] !== '') {
                $new_files[] = $banner['path'];
            }
        }

        $ok = $this->asset_model->update_app($id, $payload);
        if (!$ok) {
            // Remove newly uploaded files if the database update fails.
            foreach ($new_files as $path) {
                $this->delete_repo_file($app['github_owner'], $app['github_repository'], $app['github_branch'], $path);
            }
            $this->data['flash_error'] = 'App gagal diperbarui.';
            return;
        }

        // Remove replaced files only after the database update succeeds.
        if (isset($payload['logo_path']) && !empty($app['logo_path']) && $app['logo_path'] !== $payload['logo_path']) {
            $this->delete_repo_file($app['github_owner'], $app['github_repository'], $app['github_branch'], $app['logo_path']);
        }
        if (isset($payload['banner_path']) && !empty($app['banner_path']) && $app['banner_path'] !== $payload['banner_path']) {
            $this->delete_repo_file($app['github_owner'], $app['github_repository'], $app['github_branch'], $app['banner_path']);
        }

        $this->session->set_flashdata('success', 'App ' . $name . ' berhasil diperbarui.');
    }

    private function delete_app()
    {
        $this->load->model('backend/Asset_App_Models', 'asset_model');
        $id = (int) $this->input->post('app_id');
        $app = $this->asset_model->get_app($id);
        if (!$app) { $this->data['flash_error'] = 'App tidak ditemukan.'; return; }
        // Remove database records only. GitHub files/repository are retained as a safety measure.
        $this->asset_model->delete_app($id);
        $this->session->set_flashdata('success', 'App ' . $app['name'] . ' dan data assets berhasil dihapus. Repository GitHub tidak dihapus.');
    }

    private function save_asset()
    {
        $this->load->model('backend/Asset_App_Models', 'asset_model');
        $id = (int) $this->input->post('app_id');
        $app = $this->asset_model->get_app($id);
        if (!$app) { $this->data['flash_error'] = 'App tidak ditemukan.'; return; }
        $asset_id = (int) $this->input->post('asset_id');
        $existing = $asset_id ? $this->asset_model->get_asset($asset_id, $id) : null;
        if ($asset_id && !$existing) { $this->data['flash_error'] = 'Asset tidak ditemukan.'; return; }
        $name = trim((string) $this->input->post('asset_name', TRUE));
        $category = trim((string) $this->input->post('category', TRUE));
        $rarity = trim((string) $this->input->post('rarity', TRUE));
        if ($name === '' || strlen($name) > 120) { $this->data['flash_error'] = 'Nama asset wajib diisi (maksimal 120 karakter).'; return; }
        if ($this->asset_model->asset_name_exists($id, $name, $asset_id)) { $this->data['flash_error'] = 'Nama asset sudah digunakan di App ini.'; return; }
        $image = array(
            'ok' => true,
            'path' => $existing ? $existing['icon_path'] : '',
            'url' => $existing ? $existing['icon'] : '',
            'old_path' => ''
        );

        if (!empty($_FILES['asset_icon']['name'])) {
            $category_folder = $category !== '' ? $this->safe_slug($category) : 'uncategorized';
            $rarity_folder = $rarity !== '' ? $this->safe_slug($rarity) : 'unrated';
            $asset_base_path = $category_folder . '/' . $rarity_folder . '/' . $this->safe_slug($name);
            $uploaded_image = $this->upload_to_repository(
                'asset_icon', $app['github_owner'], $app['github_repository'],
                $app['github_branch'], $asset_base_path, 10240
            );
            if (!$uploaded_image['ok']) {
                $this->data['flash_error'] = 'Icon asset: ' . $uploaded_image['error'];
                return;
            }
            $image = array(
                'ok' => true,
                'path' => $uploaded_image['path'],
                'url' => $uploaded_image['url'],
                'old_path' => $existing ? $existing['icon_path'] : ''
            );
        } elseif ($existing && !empty($existing['icon_path'])) {
            // Relocate the existing file when Name, Category or Rarity changes.
            $target_category = $category !== '' ? $this->safe_slug($category) : 'uncategorized';
            $target_rarity = $rarity !== '' ? $this->safe_slug($rarity) : 'unrated';
            $target_prefix = $target_category . '/' . $target_rarity . '/' . $this->safe_slug($name) . '-';
            $current_path = trim($existing['icon_path'], '/');
            if (strpos($current_path, $target_prefix) !== 0) {
                $image = $this->relocate_asset_icon($app, $existing, $name, $category, $rarity);
                if (!$image['ok']) {
                    $this->data['flash_error'] = $image['error'];
                    return;
                }
            }
        }

        $payload = array(
            'app_id'=>$id, 'name'=>$name, 'category'=>$category, 'rarity'=>$rarity,
            'description'=>(string)$this->input->post('asset_description', FALSE),
            'detail'=>(string)$this->input->post('detail', FALSE),
            'icon'=>$image['url'], 'icon_path'=>$image['path']
        );
        $ok = $asset_id ? $this->asset_model->update_asset($asset_id, $id, $payload) : $this->asset_model->insert_asset($payload);
        if (!$ok) {
            if (!empty($image['path']) && (!$existing || $image['path'] !== $existing['icon_path'])) {
                $this->delete_repo_file($app['github_owner'], $app['github_repository'], $app['github_branch'], $image['path']);
            }
            $this->data['flash_error'] = 'Asset gagal disimpan.';
            return;
        }

        // Delete the previous file only after the database update succeeds.
        if (!empty($image['old_path']) && $image['old_path'] !== $image['path']) {
            $this->delete_repo_file($app['github_owner'], $app['github_repository'], $app['github_branch'], $image['old_path']);
        } elseif ($existing && !empty($existing['icon_path']) && $existing['icon_path'] !== $image['path']) {
            $this->delete_repo_file($app['github_owner'], $app['github_repository'], $app['github_branch'], $existing['icon_path']);
        }

        $this->session->set_flashdata('success', ($asset_id ? 'Assets ' : 'Assets ') . $name . ($asset_id ? ' berhasil diperbarui.' : ' berhasil disimpan.'));

    }

    private function delete_asset()
    {
        $this->load->model('backend/Asset_App_Models', 'asset_model');
        $app_id = (int) $this->input->post('app_id');
        $asset_id = (int) $this->input->post('asset_id');
        $app = $this->asset_model->get_app($app_id);
        $asset = $this->asset_model->get_asset($asset_id, $app_id);
        if (!$app || !$asset) { $this->data['flash_error'] = 'Asset tidak ditemukan.'; return; }
        $this->asset_model->delete_asset($asset_id, $app_id);
        if (!empty($asset['icon_path'])) $this->delete_repo_file($app['github_owner'],$app['github_repository'],$app['github_branch'],$asset['icon_path']);
        $this->session->set_flashdata('success', 'Assets ' . $asset['name'] . ' berhasil dihapus.');
    }
}
