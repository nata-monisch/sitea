<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Store extends MY_Controller
{
    private $allowed_extensions = array('png', 'jpg', 'jpeg', 'webp', 'svg', 'gif', 'mp4');
    private $max_file_size = 10485760; // 10 MB per file
    private $max_files = 20;

    public function index()
    {
        $this->require_login();
        $this->prepare_backend('Store', 'Content / Store', 'store');
        $this->load->model('backend/Store_Models', 'store_model');

        $filters = array(
            'search' => trim((string) $this->input->get('search', TRUE)),
            'app_id' => (int) $this->input->get('app_id', TRUE),
            'type' => trim((string) $this->input->get('type', TRUE)),
            'status' => trim((string) $this->input->get('status', TRUE)),
            'user_id' => (int) $this->session->userdata('user_id')
        );
        if (!in_array($filters['type'], array('Akun', 'Item', 'Joki'), true)) $filters['type'] = '';
        if (!in_array($filters['status'], array('Ready', 'Sold'), true)) $filters['status'] = '';

        $page = max(1, (int) $this->input->get('page', TRUE));
        $per_page = 25;
        $total = $this->store_model->count_products($filters);
        $total_pages = max(1, (int) ceil($total / $per_page));
        if ($page > $total_pages) $page = $total_pages;

        $this->data['products'] = $this->store_model->get_products($filters, $per_page, ($page - 1) * $per_page);
        foreach ($this->data['products'] as &$product) {
            $product['images_array'] = $this->decode_json_array($product['images']);
            $product['detail_url'] = site_url('store/' . $this->store_model->slugify($product['app_name']) . '/' . $product['slug'] . '/');
        }
        unset($product);

        $this->data['apps'] = $this->store_model->get_apps();
        $this->data['filters'] = $filters;
        $this->data['page'] = $page;
        $this->data['per_page'] = $per_page;
        $this->data['total'] = $total;
        $this->data['total_pages'] = $total_pages;
        $this->data['from'] = $total > 0 ? (($page - 1) * $per_page) + 1 : 0;
        $this->data['to'] = min($page * $per_page, $total);
        $this->data['create_url'] = site_url('backend/store/create/');
        $this->render_backend('backend/store/index');
    }

    public function create()
    {
        $this->form(0);
    }

    public function edit($id = 0)
    {
        $this->form((int) $id);
    }

    private function form($id)
    {
        $this->require_login();
        $this->prepare_backend($id ? 'Edit Product' : 'Create Product', 'Content / Store', 'store');
        $this->load->model('backend/Store_Models', 'store_model');

        $product = null;
        if ($id) {
            $product = $this->store_model->get_product($id, (int) $this->session->userdata('user_id'));
            if (!$product || (int) $product['user_id'] !== (int) $this->session->userdata('user_id')) {
                show_404();
                return;
            }
            $product['images_array'] = $this->decode_json_array($product['images']);
            $product['specifications_array'] = $this->decode_json_array($product['specifications']);
        }

        $this->data['product'] = $product;
        $this->data['posted'] = array();
        $this->data['apps'] = $this->store_model->get_apps();
        $storage = $this->github_storage_context();
        $this->data['storage_ready'] = !empty($storage['ok']);
        $this->data['storage_error'] = empty($storage['ok']) ? $storage['error'] : '';
        $this->data['form_action'] = site_url('backend/store/save/' . (int) $id . '/');
        $this->data['asset_options_url'] = site_url('backend/store/asset-options/');
        $this->render_backend('backend/store/form');
    }

    public function asset_options($app_id = 0)
    {
        $this->require_login();
        $this->load->model('backend/Store_Models', 'store_model');
        $app = $this->store_model->get_app((int) $app_id);
        if (!$app) {
            return $this->json_response(array('ok' => false, 'message' => 'App tidak ditemukan.'), 404);
        }
        return $this->json_response(array(
            'ok' => true,
            'categories' => $this->store_model->get_asset_options($app_id)
        ));
    }

    public function save($id = 0)
    {
        $this->require_login();
        if ($this->input->method(TRUE) !== 'POST') show_error('Method not allowed.', 405);
        $this->prepare_backend($id ? 'Edit Product' : 'Create Product', 'Content / Store', 'store');
        $this->load->model('backend/Store_Models', 'store_model');
        $id = (int) $id;
        $existing = null;

        if ($id) {
            $existing = $this->store_model->get_product($id, (int) $this->session->userdata('user_id'));
            if (!$existing || (int) $existing['user_id'] !== (int) $this->session->userdata('user_id')) {
                show_404();
                return;
            }
        }

        $title = trim((string) $this->input->post('title', TRUE));
        $app_id = (int) $this->input->post('app_id', TRUE);
        $type = trim((string) $this->input->post('type', TRUE));
        $status = trim((string) $this->input->post('status', TRUE));
        $description = trim((string) $this->input->post('description', FALSE));
        $keyword = trim((string) $this->input->post('keyword', TRUE));
        $price_raw = trim((string) $this->input->post('price', TRUE));
        $discount_raw = trim((string) $this->input->post('price_discount', TRUE));
        $slug_input = trim((string) $this->input->post('slug', TRUE));

        $app = $this->store_model->get_app($app_id);
        $errors = array();
        $title_length = function_exists('mb_strlen') ? mb_strlen($title, 'UTF-8') : strlen($title);
        if ($title_length < 3 || $title_length > 255) $errors[] = 'Title wajib diisi (3–255 karakter).';
        if (!$app) $errors[] = 'Pilih kategori App yang valid.';
        if (!in_array($type, array('Akun', 'Item', 'Joki'), true)) $errors[] = 'Type produk tidak valid.';
        if (!in_array($status, array('Ready', 'Sold'), true)) $errors[] = 'Status produk tidak valid.';
        $max_price = 9999999999999.99; // DECIMAL(15,2) database limit.
        if ($price_raw === '' || !is_numeric($price_raw) || (float) $price_raw < 0 || (float) $price_raw > $max_price) {
            $errors[] = 'Harga wajib berupa angka 0 sampai 9.999.999.999.999,99.';
        }
        if ($discount_raw !== '' && (!is_numeric($discount_raw) || (float) $discount_raw <= 0 || (float) $discount_raw >= (float) $price_raw || (float) $discount_raw > $max_price)) {
            $errors[] = 'Harga diskon harus lebih dari 0 dan lebih kecil dari harga normal.';
        }
        if (strlen($keyword) > 500) $errors[] = 'Keyword maksimal 500 karakter.';

        $slug = $slug_input !== '' ? $this->store_model->slugify($slug_input) : $this->store_model->slugify($title);
        if ($slug === '') $slug = 'produk-' . date('YmdHis');
        if (strlen($slug) > 255) $errors[] = 'Slug maksimal 255 karakter.';
        if (!preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $slug)) $errors[] = 'Slug hanya boleh berisi huruf kecil, angka, dan tanda minus.';
        if ($app && $this->store_model->product_slug_exists($app_id, $slug, $id)) $errors[] = 'Slug sudah digunakan pada kategori App ini. Silakan ubah slug.';

        $specifications = array();
        if ($type === 'Akun' && $app) {
            $specifications = $this->validate_specifications($app_id, (string) $this->input->post('specifications_json', FALSE), $errors);
            if (empty($specifications)) $errors[] = 'Tambahkan minimal satu asset pada spesifikasi akun.';
        }

        $remove_paths = $this->input->post('remove_images');
        if (!is_array($remove_paths)) $remove_paths = array();
        $remove_map = array();
        foreach ($remove_paths as $remove_path) {
            if (is_string($remove_path) && $remove_path !== '') $remove_map[$remove_path] = true;
        }
        $existing_images = $existing ? $this->decode_json_array($existing['images']) : array();
        $kept_images = array();
        foreach ($existing_images as $image) {
            $path = isset($image['path']) ? (string) $image['path'] : '';
            if ($path !== '' && isset($remove_map[$path])) continue;
            $kept_images[] = $image;
        }

        $files = $this->normalize_uploads('images');
        $files = array_values(array_filter($files, function ($file) { return isset($file['name']) && $file['name'] !== ''; }));
        if (count($kept_images) + count($files) > $this->max_files) $errors[] = 'Maksimal ' . $this->max_files . ' file media per produk.';
        if (!$id && empty($files)) $errors[] = 'Upload minimal satu gambar atau video produk.';

        // Do not remove remote files from product metadata when GitHub is unavailable.
        $removing_existing_media = count($kept_images) < count($existing_images);
        $storage_context = array('ok' => false, 'error' => 'GitHub Storage tidak tersedia.');
        if (!empty($files) || $removing_existing_media) {
            $storage_context = $this->github_storage_context();
            if (empty($storage_context['ok'])) {
                $errors[] = 'GitHub Storage diperlukan untuk upload atau menghapus media: ' . $storage_context['error'];
            }
        }
        foreach ($files as $file) {
            $file_error = $this->validate_media_file($file);
            if ($file_error !== '') $errors[] = $file['name'] . ': ' . $file_error;
        }

        if (!empty($errors)) {
            $this->data['product'] = $existing;
            if ($existing) {
                $existing['images_array'] = $existing_images;
                $existing['specifications_array'] = $this->decode_json_array($existing['specifications']);
            }
            $this->data['product'] = $existing;
            $this->data['posted'] = $this->input->post(NULL, FALSE);
            $this->data['apps'] = $this->store_model->get_apps();
            $storage = $this->github_storage_context();
            $this->data['storage_ready'] = !empty($storage['ok']);
            $this->data['storage_error'] = empty($storage['ok']) ? $storage['error'] : '';
            $this->data['form_errors'] = implode(' | ', $errors);
            $this->data['form_action'] = site_url('backend/store/save/' . $id . '/');
            $this->data['asset_options_url'] = site_url('backend/store/asset-options/');
            $this->render_backend('backend/store/form');
            return;
        }

        $payload = array(
            'user_id' => (int) $this->session->userdata('user_id'),
            'app_id' => $app_id,
            'name' => $title,
            'title' => $title,
            'slug' => $slug,
            'description' => $description,
            'keyword' => $keyword,
            'specifications' => json_encode($specifications, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'status' => $status,
            'price' => number_format((float) $price_raw, 2, '.', ''),
            'price_discount' => $discount_raw !== '' ? number_format((float) $discount_raw, 2, '.', '') : null,
            'type' => $type
        );

        if (!$id) {
            $payload['images'] = '[]';
            $id = $this->store_model->insert_product($payload);
            if (!$id) {
                $this->session->set_flashdata('error', 'Produk gagal dibuat. Periksa database.');
                redirect('backend/store/create/');
                return;
            }
        }

        $context = $storage_context;
        if (!empty($files) && empty($context['ok'])) {
            if (!$existing) $this->store_model->delete_product($id, (int) $this->session->userdata('user_id'));
            $this->session->set_flashdata('error', 'Upload media gagal: ' . (isset($context['error']) ? $context['error'] : 'GitHub Storage tidak tersedia.'));
            redirect($existing ? 'backend/store/edit/' . $id . '/' : 'backend/store/create/');
            return;
        }

        $new_media = array();
        $sequence = $this->next_media_sequence($existing_images);
        foreach ($files as $file) {
            $uploaded = $this->upload_product_media($id, $sequence++, $file, $context);
            if (!$uploaded['ok']) {
                foreach ($new_media as $media) $this->delete_media_file($media, $context['token']);
                if (!$existing) $this->store_model->delete_product($id, (int) $this->session->userdata('user_id'));
                $this->session->set_flashdata('error', 'Media gagal diunggah: ' . $uploaded['error']);
                redirect($existing ? 'backend/store/edit/' . $id . '/' : 'backend/store/create/');
                return;
            }
            $new_media[] = $uploaded['media'];
        }

        $final_images = array_merge($kept_images, $new_media);
        $payload['images'] = json_encode($final_images, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!$this->store_model->update_product($id, $payload, (int) $this->session->userdata('user_id'))) {
            foreach ($new_media as $media) $this->delete_media_file($media, !empty($context['token']) ? $context['token'] : '');
            if (!$existing) $this->store_model->delete_product($id, (int) $this->session->userdata('user_id'));
            $this->session->set_flashdata('error', 'Produk gagal disimpan ke database. Media baru sudah dibersihkan jika memungkinkan.');
            redirect($existing ? 'backend/store/edit/' . $id . '/' : 'backend/store/create/');
            return;
        }

        if ($context && !empty($context['token'])) {
            foreach ($existing_images as $old_image) {
                $path = isset($old_image['path']) ? (string) $old_image['path'] : '';
                if ($path !== '' && isset($remove_map[$path])) $this->delete_media_file($old_image, $context['token']);
            }
        }

        $this->session->set_flashdata('success', 'Produk ' . $title . ($existing ? ' berhasil diperbarui.' : ' berhasil dibuat.'));
        redirect('backend/store/');
    }

    public function delete($id = 0)
    {
        $this->require_login();
        $this->prepare_backend('Store', 'Content / Store', 'store');
        $this->load->model('backend/Store_Models', 'store_model');
        if ($this->input->method(TRUE) !== 'POST') show_error('Method not allowed.', 405);
        $product = $this->store_model->get_product((int) $id, (int) $this->session->userdata('user_id'));
        if (!$product || (int) $product['user_id'] !== (int) $this->session->userdata('user_id')) { show_404(); return; }

        $images = $this->decode_json_array($product['images']);
        $context = $this->github_storage_context();
        if (!empty($images) && empty($context['ok'])) {
            $this->session->set_flashdata('error', 'Produk tidak dihapus karena GitHub Storage belum tersedia. Hubungkan kembali storage agar media produk juga dapat dibersihkan.');
            redirect('backend/store/');
            return;
        }
        if (!$this->store_model->delete_product($id, (int) $this->session->userdata('user_id'))) {
            $this->session->set_flashdata('error', 'Produk ' . $product['title'] . ' gagal dihapus.');
        } else {
            if (!empty($context['token'])) foreach ($images as $media) $this->delete_media_file($media, $context['token']);
            $this->session->set_flashdata('success', 'Produk ' . $product['title'] . ' berhasil dihapus.');
        }
        redirect('backend/store/');
    }

    private function validate_specifications($app_id, $json, &$errors)
    {
        $input = json_decode($json, true);
        if (!is_array($input)) {
            $errors[] = 'Spesifikasi akun tidak valid.';
            return array();
        }
        if (count($input) > 100) {
            $errors[] = 'Maksimal 100 entri spesifikasi akun.';
            return array();
        }
        $clean = array();
        $seen = array();
        foreach ($input as $item) {
            if (!is_array($item) || !isset($item['asset_id']) || !is_scalar($item['asset_id']) || !ctype_digit((string) $item['asset_id'])) continue;
            $asset = $this->store_model->get_asset((int) $item['asset_id'], $app_id);
            if (!$asset) {
                $errors[] = 'Salah satu asset spesifikasi tidak ditemukan pada App yang dipilih.';
                continue;
            }
            $value_raw = isset($item['value']) && is_scalar($item['value']) ? (string) $item['value'] : '';
            $value = trim(strip_tags($value_raw));
            $value_length = function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
            if ($value_length > 80) $value = function_exists('mb_substr') ? mb_substr($value, 0, 80, 'UTF-8') : substr($value, 0, 80);
            $key = (int) $asset['id'] . ':' . $value;
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $category = trim((string) $asset['category']);
            $clean[] = array(
                'asset_id' => (int) $asset['id'],
                'name' => $asset['name'],
                'category' => $category !== '' ? $category : 'Uncategorized',
                'rarity' => $asset['rarity'],
                'icon' => $asset['icon'],
                'value' => $value
            );
        }
        return $clean;
    }

    private function normalize_uploads($field)
    {
        if (empty($_FILES[$field]) || !isset($_FILES[$field]['name'])) return array();
        $input = $_FILES[$field];
        if (!is_array($input['name'])) return array($input);
        $files = array();
        foreach ($input['name'] as $index => $name) {
            $files[] = array(
                'name' => $name,
                'type' => isset($input['type'][$index]) ? $input['type'][$index] : '',
                'tmp_name' => isset($input['tmp_name'][$index]) ? $input['tmp_name'][$index] : '',
                'error' => isset($input['error'][$index]) ? $input['error'][$index] : UPLOAD_ERR_NO_FILE,
                'size' => isset($input['size'][$index]) ? (int) $input['size'][$index] : 0
            );
        }
        return $files;
    }

    private function validate_media_file($file)
    {
        if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
            if (isset($file['error']) && $file['error'] === UPLOAD_ERR_INI_SIZE) return 'File melebihi batas upload PHP di hosting.';
            if (isset($file['error']) && $file['error'] === UPLOAD_ERR_FORM_SIZE) return 'File melebihi batas ukuran form.';
            if (isset($file['error']) && $file['error'] === UPLOAD_ERR_PARTIAL) return 'File hanya ter-upload sebagian. Coba upload ulang.';
            return 'File upload tidak valid.';
        }
        if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) return 'File upload tidak valid.';
        if (empty($file['size']) || $file['size'] > $this->max_file_size) return 'Ukuran maksimal 10 MB per file.';
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $this->allowed_extensions, true)) return 'Format harus PNG, JPG, JPEG, WEBP, SVG, GIF, atau MP4.';
        $contents = @file_get_contents($file['tmp_name']);
        if ($contents === false || $contents === '') return 'File tidak dapat dibaca.';
        if ($ext === 'svg') {
            if (stripos($contents, '<svg') === false || preg_match('/<!DOCTYPE|<!ENTITY|<script\b|on[a-z]+\s*=|javascript:|<foreignObject\b|@import|url\s*\(|(?:href|xlink:href)\s*=\s*["\']\s*(?:https?:|\/\/|data:)/i', $contents)) return 'SVG tidak valid atau mengandung elemen aktif/eksternal.';
        } elseif ($ext === 'mp4') {
            if (strlen($contents) < 12 || substr($contents, 4, 4) !== 'ftyp') return 'File bukan video MP4 yang valid.';
        } else {
            $info = @getimagesize($file['tmp_name']);
            $expected = array('png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'webp' => 'image/webp', 'gif' => 'image/gif');
            if (!$info || empty($info['mime']) || $info['mime'] !== $expected[$ext]) return 'Isi file tidak sesuai dengan ekstensi gambar.';
        }
        return '';
    }

    private function upload_product_media($product_id, $sequence, $file, $context)
    {
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $filename = 'Image-' . (int) $sequence . '-' . date('YmdHis') . '-' . mt_rand(100, 999) . '.' . $ext;
        $path = 'assets/img/product/' . (int) $product_id . '/' . $filename;
        $contents = @file_get_contents($file['tmp_name']);
        if ($contents === false || $contents === '') return array('ok' => false, 'error' => 'File tidak dapat dibaca.');

        $this->load->library('github_storage');
        $result = $this->github_storage->put_file(
            $context['owner'], $context['repository'], $path, $context['branch'],
            $context['token'], $contents, 'Upload store product media: ' . $filename
        );
        if (!$result['ok']) return array('ok' => false, 'error' => $result['error']);

        $url = 'https://cdn.jsdelivr.net/gh/' . rawurlencode($context['owner']) . '/'
            . rawurlencode($context['repository']) . '@' . rawurlencode($context['branch']) . '/' . $path;
        $mime = $ext === 'mp4' ? 'video/mp4' : ($ext === 'svg' ? 'image/svg+xml' : (function_exists('mime_content_type') ? mime_content_type($file['tmp_name']) : 'application/octet-stream'));
        return array('ok' => true, 'media' => array(
            'path' => $path, 'url' => $url, 'name' => basename($file['name']),
            'filename' => $filename, 'extension' => $ext, 'mime' => $mime,
            'owner' => $context['owner'], 'repository' => $context['repository'], 'branch' => $context['branch']
        ));
    }

    private function delete_media_file($media, $token)
    {
        if (empty($media['path']) || empty($media['owner']) || empty($media['repository']) || empty($media['branch']) || $token === '') return false;
        $this->load->library('github_storage');
        $result = $this->github_storage->delete_file(
            $media['owner'], $media['repository'], $media['path'], $media['branch'], $token,
            'Delete store product media: ' . basename($media['path'])
        );
        if (!$result['ok']) log_message('error', 'Store media cleanup failed: ' . $result['error']);
        return !empty($result['ok']);
    }

    private function next_media_sequence($images)
    {
        $max = 0;
        foreach ($images as $image) {
            if (!empty($image['filename']) && preg_match('/^Image-(\d+)-/', $image['filename'], $matches)) $max = max($max, (int) $matches[1]);
        }
        return $max + 1;
    }

    private function decode_json_array($value)
    {
        $decoded = json_decode((string) $value, true);
        return is_array($decoded) ? $decoded : array();
    }

    private function json_response($payload, $status = 200)
    {
        $this->output->set_status_header($status)->set_content_type('application/json')
            ->set_output(json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }
}
