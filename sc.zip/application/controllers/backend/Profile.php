<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends MY_Controller
{
    public function index()
    {
        $this->require_login();
        $this->prepare_backend('Edit Profile', 'Edit Profile', 'profile');
        $this->data['title'] = 'Edit Profile - ' . $this->data['website']['name'];
        $this->data['description'] = 'Manage your public profile and personal information.';
        $this->data['thumbnail'] = $this->data['website']['banner'];
        $user = $this->data['user'];
        $user_password_hash = $this->current_user_password_hash;
        $user_id = (int) $user['user_id'];

        if ($this->input->method(TRUE) === 'POST') {
            $this->form_validation->set_rules('display_name', 'Display Name', 'trim|required|max_length[120]');
            $this->form_validation->set_rules('username', 'Username', 'trim|required|alpha_dash|min_length[3]|max_length[60]|callback_username_available');
            $this->form_validation->set_rules('whatsapp', 'WhatsApp', 'trim|max_length[32]');
            $this->form_validation->set_rules('bio', 'Bio', 'trim');
            $this->form_validation->set_rules('facebook', 'Facebook', 'trim|max_length[255]');
            $this->form_validation->set_rules('instagram', 'Instagram', 'trim|max_length[255]');
            $this->form_validation->set_rules('discord', 'Discord', 'trim|max_length[255]');
            $this->form_validation->set_rules('tiktok', 'TikTok', 'trim|max_length[255]');
            $this->form_validation->set_rules('youtube', 'YouTube', 'trim|max_length[255]');

            $new_password = (string) $this->input->post('new_password', FALSE);
            $current_password = (string) $this->input->post('current_password', FALSE);
            $confirm_password = (string) $this->input->post('confirm_password', FALSE);
            $password_error = '';
            if ($new_password !== '' || $current_password !== '' || $confirm_password !== '') {
                if ($current_password === '' || !password_verify($current_password, $user_password_hash)) {
                    $password_error = 'Current password tidak sesuai.';
                } elseif (strlen($new_password) < 8) {
                    $password_error = 'Password baru minimal 8 karakter.';
                } elseif ($new_password !== $confirm_password) {
                    $password_error = 'Konfirmasi password baru tidak sama.';
                }
            }

            $valid_form = $this->form_validation->run();
            if ($valid_form && $password_error === '') {
                $update = array(
                    'display_name' => trim((string) $this->input->post('display_name', TRUE)),
                    'username' => trim((string) $this->input->post('username', TRUE)),
                    'whatsapp' => trim((string) $this->input->post('whatsapp', TRUE)),
                    'bio' => trim((string) $this->input->post('bio', TRUE))
                );

                foreach (array('facebook', 'instagram', 'discord', 'tiktok', 'youtube') as $field) {
                    $link = $this->safe_social_url($this->input->post($field, TRUE));
                    if ($link === false) {
                        $password_error = 'Social link ' . ucfirst($field) . ' harus menggunakan URL http:// atau https:// yang valid.';
                        break;
                    }
                    $update[$field] = $link;
                }

                $new_github_uploads = array();
                if ($password_error === '') {
                    $profile_upload = $this->upload_github_image('profile_image', 'assets/img/user/' . $user_id . '-Profile', 5120, true);
                    if ($profile_upload['error']) $password_error = 'Profile photo: ' . $profile_upload['error'];
                    elseif ($profile_upload['path']) {
                        $new_github_uploads['profile'] = $profile_upload;
                        $update['profile'] = $profile_upload['url'];
                    }
                }
                if ($password_error === '') {
                    $banner_upload = $this->upload_github_image('banner_image', 'assets/img/user/' . $user_id . '-Banner', 5120, true);
                    if ($banner_upload['error']) $password_error = 'Profile banner: ' . $banner_upload['error'];
                    elseif ($banner_upload['path']) {
                        $new_github_uploads['banner'] = $banner_upload;
                        $update['banner'] = $banner_upload['url'];
                    }
                }

                if ($password_error === '') {
                    if ($new_password !== '') $update['password'] = password_hash($new_password, PASSWORD_DEFAULT);
                    $ok = $this->profile_model->update_user($user_id, $update);
                    if ($ok) {
                        foreach ($new_github_uploads as $field => $asset) {
                            $old_value = isset($user[$field]) ? $user[$field] : '';
                            $this->delete_replaced_github_asset($old_value, $asset['path']);
                        }
                        $this->session->set_userdata(array(
                            'username' => $update['username'],
                            'display_name' => $update['display_name']
                        ));
                        $this->session->set_flashdata('success', 'Profile berhasil diperbarui.');
                        redirect('backend/profile/');
                        return;
                    }
                    foreach ($new_github_uploads as $field => $asset) {
                        $this->rollback_github_asset(isset($user[$field]) ? $user[$field] : '', $asset['path']);
                    }
                    $password_error = 'Profile gagal disimpan.'; // Silakan periksa koneksi database.
                } else {
                    foreach ($new_github_uploads as $field => $asset) {
                        $this->rollback_github_asset(isset($user[$field]) ? $user[$field] : '', $asset['path']);
                    }
                }
            } elseif (!$valid_form) {
                $this->data['form_errors'] = validation_errors();
            }

            if ($password_error !== '') $this->data['flash_error'] = $password_error;
        }

        $this->data['user'] = $user;
        // Re-fetch after a failed update so the view always has the canonical row.
        $this->data['user'] = $this->profile_model->get_user($user_id);
        unset($this->data['user']['password']);
        $this->render_backend('backend/profile');
    }

    public function username_available($username)
    {
        if ($username === '') return TRUE;
        $this->load->model('backend/Profile_Models', 'profile_model');
        if ($this->profile_model->username_exists_except($username, (int) $this->session->userdata('user_id'))) {
            $this->form_validation->set_message('username_available', 'Username tersebut sudah digunakan.');
            return FALSE;
        }
        return TRUE;
    }
}
