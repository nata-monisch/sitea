<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Web_Appearance extends MY_Controller
{
    public function index()
    {
        $this->require_login();
        $this->prepare_backend('Website Settings - Appearance', 'Website Settings - Appearance', 'web-appearance');
        $this->data['title'] = 'Website Appearance Settings - ' . $this->data['website']['name'];
        $this->data['description'] = 'Adjust the visual identity of your website.';
        $this->data['thumbnail'] = $this->data['website']['banner'];

        if ($this->input->method(TRUE) === 'POST') {
            $this->form_validation->set_rules('browser_color', 'Browser color', 'trim|required|regex_match[/^#[0-9a-fA-F]{6}$/]');
            if ($this->form_validation->run()) {
                $old = $this->data['website'];
                $update = array('browser_color' => strtoupper(trim((string) $this->input->post('browser_color', TRUE))));
                $uploaded_assets = array();
                $upload_error = '';

                $logo_upload = $this->upload_github_image('logo', 'assets/img/logo', 5120, true);
                if ($logo_upload['error']) {
                    $upload_error = 'Logo: ' . $logo_upload['error'];
                } elseif ($logo_upload['path']) {
                    $uploaded_assets['logo'] = $logo_upload;
                    $update['logo'] = $logo_upload['url'];
                }

                if ($upload_error === '') {
                    $banner_upload = $this->upload_github_image('banner', 'assets/img/banner', 8192, false);
                    if ($banner_upload['error']) {
                        $upload_error = 'Website banner: ' . $banner_upload['error'];
                    } elseif ($banner_upload['path']) {
                        $uploaded_assets['banner'] = $banner_upload;
                        $update['banner'] = $banner_upload['url'];
                    }
                }

                if ($upload_error === '') {
                    $favicon_upload = $this->upload_root_favicon('favicon', 2048);
                    if ($favicon_upload['error']) {
                        $upload_error = 'Favicon: ' . $favicon_upload['error'];
                    } elseif ($favicon_upload['path']) {
                        $update['favicon'] = $favicon_upload['path'];
                    }
                }

                if ($upload_error !== '') {
                    foreach ($uploaded_assets as $field => $asset) {
                        $this->rollback_github_asset(isset($old[$field]) ? $old[$field] : '', $asset['path']);
                    }
                    $this->data['flash_error'] = $upload_error;
                } elseif ($this->website_model->update_settings($update)) {
                    foreach ($uploaded_assets as $field => $asset) {
                        $old_value = isset($old[$field]) ? $old[$field] : '';
                        $this->delete_replaced_github_asset($old_value, $asset['path']);
                    }
                    $this->session->set_flashdata('success', 'Appearance settings berhasil disimpan.');
                    redirect('backend/web-appearance/');
                    return;
                } else {
                    foreach ($uploaded_assets as $field => $asset) {
                        $this->rollback_github_asset(isset($old[$field]) ? $old[$field] : '', $asset['path']);
                    }
                    $this->data['flash_error'] = 'Appearance settings gagal disimpan ke database.';
                }
            } else {
                $this->data['form_errors'] = validation_errors();
            }
        }

        $this->data['website'] = $this->website_model->get_settings();
        $this->render_backend('backend/website/appearance');
    }
}
