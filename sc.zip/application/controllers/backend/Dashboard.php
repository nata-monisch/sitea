<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller
{
    public function index()
    {
        $this->require_login();
        $this->prepare_backend('Dashboard', 'Dashboard', 'dashboard');
        // Metadata halaman ditentukan di Controller dan diteruskan ke header.php.
        $this->data['title'] = 'Dashboard - ' . $this->data['website']['name'];
        $this->data['description'] = $this->data['website']['description'];
        $this->data['thumbnail'] = $this->data['website']['banner'];

        $website = $this->data['website'];
        $user = $this->data['user'];
        $social_fields = array('facebook', 'instagram', 'discord', 'tiktok', 'youtube');
        $social_count = 0;
        foreach ($social_fields as $field) {
            if (!empty($website[$field])) $social_count++;
        }
        $asset_count = 0;
        foreach (array('favicon', 'logo', 'banner') as $field) {
            if (!empty($website[$field])) $asset_count++;
        }
        $profile_fields = array('display_name', 'username', 'bio', 'whatsapp', 'profile', 'banner');
        $profile_filled = 0;
        foreach ($profile_fields as $field) {
            if (!empty($user[$field])) $profile_filled++;
        }

        $this->data['metrics'] = array(
            array('label' => 'Website name', 'value' => $website['name'], 'note' => 'Nama website yang digunakan', 'icon' => 'fa-globe'),
            array('label' => 'Social links', 'value' => $social_count . ' / 5', 'note' => 'Tautan sosial yang sudah diisi', 'icon' => 'fa-share-nodes'),
            array('label' => 'Brand assets', 'value' => $asset_count . ' / 3', 'note' => 'Favicon, logo, dan banner', 'icon' => 'fa-images'),
            array('label' => 'Profile completion', 'value' => round(($profile_filled / count($profile_fields)) * 100) . '%', 'note' => 'Kelengkapan informasi profil', 'icon' => 'fa-user-check')
        );
        $this->data['social_count'] = $social_count;
        $this->render_backend('backend/dashboard');
    }
}
