<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Assets_DB extends MY_Controller
{
    public function index()
    {
        $this->prepare_frontend();

        $apps = $this->assets_db_model->get_apps_with_asset_counts();
        foreach ($apps as &$app) {
            $app['logo_url'] = $this->public_asset_url($app['logo']);
            $app['banner_url'] = $this->public_asset_url($app['banner']);
        }
        unset($app);

        $this->data['apps'] = $apps;
        $this->data['title'] = 'Assets Database - ' . $this->data['website']['name'];
        $this->data['description'] = 'Explore game assets, characters, items, and other collections in the ' . $this->data['website']['name'] . ' Assets Database.';
        $this->data['thumbnail'] = $this->data['website']['banner'];
        $this->data['keyword'] = 'Assets Database, Game Assets, ' . $this->data['website']['name'];
        $this->data['thumbnail_url'] = $this->public_asset_url($this->data['thumbnail']);
        $this->data['canonical'] = site_url('assets-db/');
        $this->data['og_type'] = 'website';

        $this->load->view('frontend/Assets-DB/index', $this->data);
    }

    public function app($app_slug = '')
    {
        $this->prepare_frontend();

        $app = $this->assets_db_model->get_app_by_slug($app_slug);
        if (!$app) {
            show_404();
            return;
        }

        $canonical_slug = $app['slug'];
        if ((string) $app_slug !== $canonical_slug) {
            redirect('assets-db/' . $canonical_slug . '/', 'location', 301);
            return;
        }

        $assets = $this->assets_db_model->get_assets_by_app($app['id']);
        $categories = array();

        foreach ($assets as &$asset) {
            $asset['icon_url'] = $this->public_asset_url($asset['icon']);
            $asset['detail_url'] = site_url('assets-db/' . $canonical_slug . '/' . $asset['slug'] . '/');

            $category = trim((string) $asset['category']);
            if ($category !== '') {
                $categories[strtolower($category)] = $category;
            }
        }
        unset($asset);

        natcasesort($categories);

        $app['logo_url'] = $this->public_asset_url($app['logo']);
        $app['banner_url'] = $this->public_asset_url($app['banner']);
        $app['asset_count'] = count($assets);

        $this->data['app'] = $app;
        $this->data['assets'] = $assets;
        $this->data['categories'] = array_values($categories);
        $this->data['title'] = $app['name'] . ' Assets - ' . $this->data['website']['name'];
        $this->data['description'] = trim((string) $app['description']) !== '' ? $app['description'] : ('Browse assets from ' . $app['name'] . '.');
        $this->data['thumbnail'] = $app['banner'] ? $app['banner'] : $app['logo'];
        $this->data['keyword'] = $app['name'] . ', ' . $app['publisher'] . ', Assets Database';
        $this->data['thumbnail_url'] = $this->public_asset_url($this->data['thumbnail']);
        $this->data['canonical'] = site_url('assets-db/' . $canonical_slug . '/');
        $this->data['og_type'] = 'website';

        $this->load->view('frontend/Assets-DB/app', $this->data);
    }

    public function details($app_slug = '', $asset_slug = '')
    {
        $this->prepare_frontend();

        $app = $this->assets_db_model->get_app_by_slug($app_slug);
        if (!$app) {
            show_404();
            return;
        }

        $canonical_app_slug = $app['slug'];
        if ((string) $app_slug !== $canonical_app_slug) {
            $asset = $this->assets_db_model->get_asset_by_slug($app['id'], $asset_slug);
            if (!$asset) {
                show_404();
                return;
            }
            redirect('assets-db/' . $canonical_app_slug . '/' . $asset['slug'] . '/', 'location', 301);
            return;
        }

        $asset = $this->assets_db_model->get_asset_by_slug($app['id'], $asset_slug);
        if (!$asset) {
            show_404();
            return;
        }

        if ((string) $asset_slug !== $asset['slug']) {
            redirect('assets-db/' . $canonical_app_slug . '/' . $asset['slug'] . '/', 'location', 301);
            return;
        }

        $app['logo_url'] = $this->public_asset_url($app['logo']);
        $app['banner_url'] = $this->public_asset_url($app['banner']);
        $asset['icon_url'] = $this->public_asset_url($asset['icon']);

        $related_assets = array();
        $all_assets = $this->assets_db_model->get_assets_by_app($app['id']);
        foreach ($all_assets as $related) {
            if ((int) $related['id'] === (int) $asset['id']) {
                continue;
            }
            $asset_category = trim((string) $asset['category']);
            if ($asset_category !== '' && strcasecmp((string) $related['category'], $asset_category) !== 0) {
                continue;
            }
            $related['icon_url'] = $this->public_asset_url($related['icon']);
            $related['detail_url'] = site_url('assets-db/' . $canonical_app_slug . '/' . $related['slug'] . '/');
            $related_assets[] = $related;
            if (count($related_assets) >= 4) {
                break;
            }
        }

        // The hyphenated key is kept to match the requested controller convention.
        $this->data['app'] = $app;
        $this->data['app-asset'] = $asset;
        $this->data['app_asset'] = $asset;
        $this->data['related_assets'] = $related_assets;
        $this->data['title'] = $this->data['app-asset']['name'] . ' ' . $this->data['app']['name'] . ' - ' . $this->data['website']['name'];
        $this->data['description'] = $this->data['app-asset']['description'];
        $this->data['thumbnail'] = $this->data['app-asset']['icon'];
        $this->data['keyword'] = $this->data['app']['name'] . ', ' . $this->data['app-asset']['name'] . ', ' . $this->data['app-asset']['category'] . ', Assets Database';
        $this->data['thumbnail_url'] = $this->public_asset_url($this->data['thumbnail']);
        $this->data['canonical'] = site_url('assets-db/' . $canonical_app_slug . '/' . $asset['slug'] . '/');
        $this->data['og_type'] = 'article';

        $this->load->view('frontend/Assets-DB/details', $this->data);
    }

    /** Load common frontend data used by the existing site header/footer. */
    private function prepare_frontend()
    {
        $this->load->model('frontend/Assets_DB_Models', 'assets_db_model');
        $this->load->model('backend/Website_Models', 'website_model');

        $website = $this->website_model->get_settings();
        if (!$website) {
            show_error('Data konfigurasi website tidak ditemukan di tabel website.', 500);
            return;
        }

        // The encrypted GitHub token is backend-only and is not needed by public views.
        if (isset($website['github_token'])) {
            unset($website['github_token']);
        }

        $this->data = array(
            'website' => $website,
            'title' => $website['name'],
            'description' => $website['description'],
            'thumbnail' => $website['banner'],
            'keyword' => $website['name'],
            'canonical' => current_url(),
            'website_logo_url' => $this->public_asset_url($website['logo']),
            'favicon_url' => $this->public_asset_url($website['favicon']),
            'website_initial' => $this->first_character($website['name']),
            'website_social_links' => $this->build_website_social_links($website)
        );
        $this->data['thumbnail_url'] = $this->public_asset_url($website['banner']);
    }

    /** Convert a saved image path/URL into a browser-safe URL. */
    private function public_asset_url($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }

        if (preg_match('#^https?://#i', $value)) {
            return filter_var($value, FILTER_VALIDATE_URL) ? $value : '';
        }

        // Do not allow protocol-relative or javascript/data URLs from the database.
        if (strpos($value, '//') === 0 || preg_match('/^(javascript|data|vbscript):/i', $value)) {
            return '';
        }

        return base_url(ltrim($value, '/'));
    }

    private function first_character($value)
    {
        $value = (string) $value;
        $first = function_exists('mb_substr') ? mb_substr($value, 0, 1, 'UTF-8') : substr($value, 0, 1);
        return strtoupper($first);
    }

    private function safe_external_url($value)
    {
        $value = trim((string) $value);
        if ($value === '' || !filter_var($value, FILTER_VALIDATE_URL)) {
            return '';
        }

        $scheme = strtolower((string) parse_url($value, PHP_URL_SCHEME));
        return in_array($scheme, array('http', 'https'), TRUE) ? $value : '';
    }

    private function build_website_social_links(array $website)
    {
        $definitions = array(
            'facebook' => array('Facebook', 'fa-brands fa-facebook-f'),
            'instagram' => array('Instagram', 'fa-brands fa-instagram'),
            'discord' => array('Discord', 'fa-brands fa-discord'),
            'tiktok' => array('TikTok', 'fa-brands fa-tiktok'),
            'youtube' => array('YouTube', 'fa-brands fa-youtube')
        );

        $links = array();
        foreach ($definitions as $field => $definition) {
            $url = $this->safe_external_url(isset($website[$field]) ? $website[$field] : '');
            if ($url !== '') {
                $links[] = array('label' => $definition[0], 'icon' => $definition[1], 'url' => $url);
            }
        }

        return $links;
    }
}
