<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends MY_Controller
{
    public function index($username = '')
    {
        $username = trim((string) $username);

        // Username pada URL publik hanya boleh berisi karakter yang sama
        // dengan validasi username pada halaman Edit Profile.
        if ($username === '' || !preg_match('/^[a-zA-Z0-9_-]{3,60}$/', $username)) {
            show_404();
            return;
        }

        $this->load->model('frontend/Profile_Models', 'profile_model');
        $this->load->model('backend/Website_Models', 'website_model');

        $user = $this->profile_model->get_public_profile_by_username($username);
        if (!$user) {
            show_404();
            return;
        }

        $website = $this->website_model->get_settings();
        if (!$website) {
            $website = array(
                'name' => 'Website',
                'description' => '',
                'logo' => '',
                'banner' => '',
                'favicon' => '',
                'browser_color' => '#0b0911'
            );
        }

        $this->data = array(
            'website' => $website,
            'user' => $user
        );

        // SEO metadata sengaja ditentukan di Controller agar mudah dikustom.
        $this->data['title'] = $this->data['user']['display_name'] . ' - ' . $this->data['website']['name'];
        $this->data['description'] = $this->data['user']['bio'];
        $this->data['thumbnail'] = $this->data['user']['banner'];
        $this->data['keyword'] = $this->data['website']['name'] .', '. $this->data['user']['username'] .', '. $this->data['user']['display_name'];

        $this->data['canonical'] = site_url('@' . $this->data['user']['username']);
        $this->data['profile_image_url'] = $this->public_asset_url($user['profile']);
        $this->data['banner_image_url'] = $this->public_asset_url($user['banner']);
        $this->data['thumbnail_url'] = $this->public_asset_url($this->data['thumbnail']);
        if ($this->data['thumbnail_url'] === '') {
            $this->data['thumbnail_url'] = $this->public_asset_url($website['banner']);
        }
        $this->data['website_logo_url'] = $this->public_asset_url($website['logo']);
        $this->data['favicon_url'] = $this->public_asset_url($website['favicon']);
        $this->data['profile_initial'] = $this->first_character($user['display_name']);
        $this->data['website_initial'] = $this->first_character($website['name']);

        $this->data['social_links'] = $this->build_social_links($user);
        $this->data['contact_url'] = $this->build_whatsapp_url($user['whatsapp']);
        $this->data['website_social_links'] = $this->build_website_social_links($website);

        $this->load->view('frontend/profile', $this->data);
    }

    /** Return the first UTF-8 character for avatar/logo fallbacks. */
    private function first_character($value)
    {
        $value = (string) $value;
        $first = function_exists('mb_substr') ? mb_substr($value, 0, 1, 'UTF-8') : substr($value, 0, 1);
        return strtoupper($first);
    }

    /** Convert a stored image path/URL into a safe URL for the browser. */
    private function public_asset_url($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }

        if (preg_match('#^https?://#i', $value)) {
            return filter_var($value, FILTER_VALIDATE_URL) ? $value : '';
        }

        // Assets stored as local paths are served from the application root.
        return base_url(ltrim($value, '/'));
    }

    /** Only allow absolute HTTP(S) URLs from social fields. */
    private function safe_external_url($value)
    {
        $value = trim((string) $value);
        if ($value === '' || !filter_var($value, FILTER_VALIDATE_URL)) {
            return '';
        }

        $scheme = strtolower((string) parse_url($value, PHP_URL_SCHEME));
        return in_array($scheme, array('http', 'https'), TRUE) ? $value : '';
    }

    private function build_social_links(array $user)
    {
        $definitions = array(
            'facebook' => array('Facebook', 'fa-brands fa-facebook'),
            'instagram' => array('Instagram', 'fa-brands fa-instagram'),
            'discord' => array('Discord', 'fa-brands fa-discord'),
            'tiktok' => array('TikTok', 'fa-brands fa-tiktok'),
            'youtube' => array('YouTube', 'fa-brands fa-youtube')
        );

        $links = array();
        foreach ($definitions as $field => $definition) {
            $url = $this->safe_external_url(isset($user[$field]) ? $user[$field] : '');
            if ($url === '') {
                continue;
            }

            $path = trim((string) parse_url($url, PHP_URL_PATH), '/');
            $display = $path !== '' ? $path : (string) parse_url($url, PHP_URL_HOST);
            if (strlen($display) > 32) {
                $display = substr($display, 0, 29) . '...';
            }

            $links[] = array(
                'label' => $definition[0],
                'icon' => $definition[1],
                'url' => $url,
                'display' => $display !== '' ? $display : 'Buka profil'
            );
        }

        return $links;
    }

    private function build_website_social_links(array $website)
    {
        $definitions = array(
            'facebook' => array('Facebook', 'fa-brands fa-facebook-f'),
            'instagram' => array('Instagram', 'fa-brands fa-instagram'),
            'discord' => array('Discord', 'fa-brands fa-discord'),
            'tiktok' => array('TikTok', 'fa-brands fa-tiktok'),
            'youtube' => array('YouTube', 'fa-brands fa-youtube')
        );

        $links = array();
        foreach ($definitions as $field => $definition) {
            $url = $this->safe_external_url(isset($website[$field]) ? $website[$field] : '');
            if ($url !== '') {
                $links[] = array('label' => $definition[0], 'icon' => $definition[1], 'url' => $url);
            }
        }

        return $links;
    }

    /** WhatsApp accepts either a full HTTP(S) link or a phone number. */
    private function build_whatsapp_url($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }

        if (preg_match('#^https?://#i', $value)) {
            return $this->safe_external_url($value);
        }

        $number = preg_replace('/\D+/', '', $value);
        if ($number === '' || strlen($number) < 8 || strlen($number) > 15) {
            return '';
        }

        return 'https://wa.me/' . $number;
    }
}
