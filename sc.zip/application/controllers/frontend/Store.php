<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Store extends MY_Controller
{
    public function index()
    {
        $this->listing(null);
    }

    public function category($category_slug = '')
    {
        $this->load->model('frontend/Store_Models', 'store_model');
        $app = $this->store_model->get_app_by_slug($category_slug);
        if (!$app) {
            show_404();
            return;
        }
        $this->listing($app);
    }

    public function sitemap()
    {
        $this->load->helper('xml');
        $this->load->model('frontend/Store_Models', 'store_model');
        $products = $this->store_model->get_sitemap_products();
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        $xml .= '<url><loc>' . xml_convert(site_url('store/')) . '</loc><changefreq>daily</changefreq><priority>0.8</priority></url>' . "\n";
        foreach ($this->store_model->get_apps() as $app) {
            $xml .= '<url><loc>' . xml_convert(site_url('store/' . $app['slug'] . '/')) . '</loc><changefreq>daily</changefreq><priority>0.7</priority></url>' . "\n";
        }
        foreach ($products as $product) {
            $slug = $this->store_model->slugify($product['app_name']);
            $url = site_url('store/' . $slug . '/' . $product['slug'] . '/');
            $lastmod = !empty($product['updated_at']) ? date('c', strtotime($product['updated_at'])) : date('c');
            $xml .= '<url><loc>' . xml_convert($url) . '</loc><lastmod>' . xml_convert($lastmod) . '</lastmod><changefreq>weekly</changefreq><priority>0.6</priority></url>' . "\n";
        }
        $xml .= '</urlset>';
        $this->output->set_content_type('application/xml', 'utf-8')->set_output($xml);
    }

    public function detail($category_slug = '', $product_slug = '')
    {
        $this->prepare_frontend();
        $app = $this->store_model->get_app_by_slug($category_slug);
        if (!$app) {
            show_404();
            return;
        }

        $product = $this->store_model->get_product_by_slug($app['id'], $product_slug);
        if (!$product) {
            show_404();
            return;
        }

        $product['seller_profile_url'] = $this->public_asset_url(isset($product['seller_profile']) ? $product['seller_profile'] : '');
        $product['images_array'] = $this->decode_json_array($product['images']);
        $app['logo_url'] = $this->public_asset_url($app['logo']);
        $app['banner_url'] = $this->public_asset_url($app['banner']);
        $product['specifications_array'] = $this->decode_json_array($product['specifications']);
        foreach ($product['specifications_array'] as &$specification) {
            $specification['icon'] = $this->safe_media_url(isset($specification['icon']) ? $specification['icon'] : '');
        }
        unset($specification);
        foreach ($product['images_array'] as &$media) {
            $media['url'] = $this->safe_media_url(isset($media['url']) ? $media['url'] : '');
        }
        unset($media);
        $product['images_array'] = array_values(array_filter($product['images_array'], function ($media) {
            return !empty($media['url']);
        }));

        $first_image = !empty($product['images_array'][0]['url']) ? $product['images_array'][0]['url'] : $this->public_asset_url($app['logo']);
        $plain_description = trim(preg_replace('/\s+/', ' ', strip_tags((string) $product['description'])));
        $meta_description = $plain_description !== '' ? $this->text_excerpt($plain_description, 160) : 'Lihat detail ' . $product['title'] . ' di ' . $this->data['website']['name'] . '.';

        $this->data['app'] = $app;
        $this->data['product'] = $product;
        $related_products = $this->store_model->get_related_products($app['id'], $product['id'], 4);
        foreach ($related_products as &$related_product) {
            $related_images = $this->decode_json_array($related_product['images']);
            $related_product['cover_url'] = !empty($related_images[0]['url']) ? $this->safe_media_url($related_images[0]['url']) : '';
            $related_product['detail_url'] = site_url('store/' . $this->store_model->slugify($related_product['app_name']) . '/' . $related_product['slug'] . '/');
            $related_product['current_price'] = $this->current_price($related_product);
        }
        unset($related_product);
        $this->data['related_products'] = $related_products;
        $this->data['latest_products'] = $this->store_model->get_latest_products($product['id'], 5);
        foreach ($this->data['latest_products'] as &$latest_product) {
            $latest_images = $this->decode_json_array($latest_product['images']);
            $latest_url = !empty($latest_images[0]['url']) ? $this->safe_media_url($latest_images[0]['url']) : '';
            $latest_product['cover_url'] = $latest_url;
            $latest_product['detail_url'] = site_url('store/' . $this->store_model->slugify($latest_product['app_name']) . '/' . $latest_product['slug'] . '/');
            $latest_product['current_price'] = $this->current_price($latest_product);
        }
        unset($latest_product);
        $this->data['title'] = $product['title'] . ' - ' . $this->data['website']['name'];
        $this->data['description'] = $meta_description;
        $this->data['thumbnail'] = $first_image;
        $this->data['thumbnail_url'] = $first_image;
        $this->data['keyword'] = trim($product['keyword'] . ', ' . $product['title'] . ', ' . $app['name'] . ', jual akun ' . $app['name'] . ', item game, joki game', ', ');
        $this->data['canonical'] = site_url('store/' . $app['slug'] . '/' . $product['slug'] . '/');
        $this->data['og_type'] = 'product';
        $this->data['whatsapp_url'] = $this->build_whatsapp_url($product['seller_whatsapp'], $product);
        $this->data['price_current'] = $this->current_price($product);
        $this->load->view('frontend/store/detail', $this->data);
    }

    private function listing($app)
    {
        $this->prepare_frontend();
        $app_id = $app ? (int) $app['id'] : 0;
        $search = trim((string) $this->input->get('search', TRUE));
        $type = trim((string) $this->input->get('type', TRUE));
        if (!in_array($type, array('Akun', 'Item', 'Joki'), true)) $type = '';
        $page = max(1, (int) $this->input->get('page', TRUE));
        $per_page = 24;
        $total = $this->store_model->count_products($app_id, $search, $type);
        $total_pages = max(1, (int) ceil($total / $per_page));
        if ($page > $total_pages) $page = $total_pages;

        $products = $this->store_model->get_products($app_id, $per_page, ($page - 1) * $per_page, $search, $type);
        foreach ($products as &$product) {
            $product['images_array'] = $this->decode_json_array($product['images']);
            $cover_candidate = !empty($product['images_array'][0]['url']) ? $product['images_array'][0]['url'] : '';
            $product['cover_url'] = $this->safe_media_url($cover_candidate);
            if ($product['cover_url'] === '') $product['cover_url'] = $this->public_asset_url('assets/img/Assets-DB.png');
            $product['detail_url'] = site_url('store/' . $this->store_model->slugify($product['app_name']) . '/' . $product['slug'] . '/');
        }
        unset($product);

        if ($app) {
            $app['logo_url'] = $this->public_asset_url($app['logo']);
            $app['banner_url'] = $this->public_asset_url($app['banner']);
        }
        $app_list = $this->store_model->get_apps();
        foreach ($app_list as &$app_item) {
            $app_item['logo_url'] = $this->public_asset_url($app_item['logo']);
            $app_item['banner_url'] = $this->public_asset_url($app_item['banner']);
        }
        unset($app_item);

        $this->data['app'] = $app;
        $this->data['apps'] = $app_list;
        $this->data['products'] = $products;
        $this->data['search'] = $search;
        $this->data['type_filter'] = $type;
        $this->data['page'] = $page;
        $this->data['total'] = $total;
        $this->data['total_pages'] = $total_pages;
        $this->data['per_page'] = $per_page;
        $this->data['base_listing_url'] = $app ? site_url('store/' . $app['slug'] . '/') : site_url('store/');

        if ($app) {
            $this->data['title'] = 'Jual Akun, Item & Joki ' . $app['name'] . ' - ' . $this->data['website']['name'];
            $app_description = trim(preg_replace('/\s+/', ' ', strip_tags((string) $app['description'])));
            $this->data['description'] = $app_description !== '' ? $this->text_excerpt($app_description . ' Temukan akun, item, dan jasa joki ' . $app['name'] . ' beserta harga dan detail penawaran.', 160) : 'Temukan jual akun ' . $app['name'] . ', item game, dan jasa joki. Lihat produk terbaru, harga, dan detail penawaran.';
            $this->data['thumbnail'] = $this->public_asset_url($app['banner']);
            $this->data['keyword'] = 'jual akun ' . $app['name'] . ', jual item ' . $app['name'] . ', joki ' . $app['name'] . ', ' . $app['publisher'];
            $this->data['canonical'] = site_url('store/' . $app['slug'] . '/');
        } else {
            $this->data['title'] = 'Jual Akun Game, Item & Joki - ' . $this->data['website']['name'];
            $this->data['description'] = 'Temukan berbagai akun game, item, dan jasa joki dari beragam game. Cek daftar produk terbaru beserta harga dan penawaran yang tersedia.';
            $this->data['thumbnail'] = $this->data['website']['banner'];
            $this->data['keyword'] = 'jual akun game, jual item game, jasa joki game, marketplace game';
            $this->data['canonical'] = site_url('store/');
        }
        $this->data['thumbnail_url'] = $this->public_asset_url($this->data['thumbnail']);
        $this->load->view('frontend/store/index', $this->data);
    }

    private function prepare_frontend()
    {
        $this->load->model('frontend/Store_Models', 'store_model');
        $this->load->model('backend/Website_Models', 'website_model');
        $website = $this->website_model->get_settings();
        if (!$website) {
            show_error('Data konfigurasi website tidak ditemukan.', 500);
            return;
        }
        unset($website['github_token']);
        $this->data = array(
            'website' => $website,
            'title' => $website['name'],
            'description' => $website['description'],
            'thumbnail' => $website['banner'],
            'keyword' => $website['name'],
            'canonical' => current_url(),
            'website_logo_url' => $this->public_asset_url($website['logo']),
            'favicon_url' => $this->public_asset_url($website['favicon']),
            'website_initial' => $this->first_character($website['name']),
            'website_social_links' => $this->build_website_social_links($website)
        );
    }

    private function decode_json_array($value)
    {
        $decoded = json_decode((string) $value, true);
        return is_array($decoded) ? $decoded : array();
    }

    private function current_price($product)
    {
        if ($product['price_discount'] !== null && $product['price_discount'] !== '' && (float) $product['price_discount'] > 0) return (float) $product['price_discount'];
        return (float) $product['price'];
    }

    private function text_excerpt($value, $length)
    {
        if (function_exists('mb_substr')) return mb_substr($value, 0, $length, 'UTF-8');
        return substr($value, 0, $length);
    }

    private function safe_media_url($value)
    {
        $value = trim((string) $value);
        if ($value === '' || !filter_var($value, FILTER_VALIDATE_URL)) return '';
        $scheme = strtolower((string) parse_url($value, PHP_URL_SCHEME));
        return in_array($scheme, array('http', 'https'), true) ? $value : '';
    }

    private function public_asset_url($value)
    {
        $value = trim((string) $value);
        if ($value === '') return '';
        if (preg_match('#^https?://#i', $value)) return filter_var($value, FILTER_VALIDATE_URL) ? $value : '';
        if (strpos($value, '//') === 0 || preg_match('/^(javascript|data|vbscript):/i', $value)) return '';
        return base_url(ltrim($value, '/'));
    }

    private function first_character($value)
    {
        $first = function_exists('mb_substr') ? mb_substr((string) $value, 0, 1, 'UTF-8') : substr((string) $value, 0, 1);
        return strtoupper($first);
    }

    private function safe_external_url($value)
    {
        $value = trim((string) $value);
        if ($value === '' || !filter_var($value, FILTER_VALIDATE_URL)) return '';
        $scheme = strtolower((string) parse_url($value, PHP_URL_SCHEME));
        return in_array($scheme, array('http', 'https'), true) ? $value : '';
    }

    private function build_website_social_links(array $website)
    {
        $defs = array(
            'facebook' => array('Facebook', 'fa-brands fa-facebook-f'),
            'instagram' => array('Instagram', 'fa-brands fa-instagram'),
            'discord' => array('Discord', 'fa-brands fa-discord'),
            'tiktok' => array('TikTok', 'fa-brands fa-tiktok'),
            'youtube' => array('YouTube', 'fa-brands fa-youtube')
        );
        $links = array();
        foreach ($defs as $key => $def) {
            $url = $this->safe_external_url(isset($website[$key]) ? $website[$key] : '');
            if ($url !== '') $links[] = array('label' => $def[0], 'icon' => $def[1], 'url' => $url);
        }
        return $links;
    }

    private function build_whatsapp_url($value, $product)
    {
        $value = trim((string) $value);
        if ($value === '') return '';
        if (preg_match('#^https?://#i', $value)) {
            $base = $this->safe_external_url($value);
            if ($base === '') return '';
            $separator = strpos($base, '?') === false ? '?' : '&';
            return $base . $separator . 'text=' . rawurlencode('Halo, saya tertarik dengan produk ' . $product['title'] . ' (' . site_url('store/' . $this->store_model->slugify($product['app_name']) . '/' . $product['slug'] . '/') . '). Apakah masih tersedia?');
        }
        $number = preg_replace('/\D+/', '', $value);
        // Normalize common Indonesian local numbers to WhatsApp international format.
        if (strpos($number, '0') === 0) $number = '62' . substr($number, 1);
        elseif (strpos($number, '8') === 0) $number = '62' . $number;
        if (strlen($number) < 8 || strlen($number) > 15) return '';
        $message = 'Halo, saya tertarik dengan produk ' . $product['title'] . ' (' . site_url('store/' . $this->store_model->slugify($product['app_name']) . '/' . $product['slug'] . '/') . '). Apakah masih tersedia?';
        return 'https://wa.me/' . $number . '?text=' . rawurlencode($message);
    }
}
