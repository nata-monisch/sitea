<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Small GitHub REST API client used only by the backend asset uploader.
 * The token is supplied per call and is never returned to a view.
 */
class Github_storage
{
    private $api_base = 'https://api.github.com';

    private function request($method, $endpoint, $token, $payload = null)
    {
        if (!function_exists('curl_init')) {
            return array('ok' => false, 'status' => 0, 'data' => null, 'error' => 'PHP cURL extension belum aktif.');
        }

        $curl = curl_init($this->api_base . $endpoint);
        $headers = array(
            'Accept: application/vnd.github+json',
            'Authorization: Bearer ' . $token,
            'X-GitHub-Api-Version: 2022-11-28',
            'User-Agent: CodeIgniter-Asset-Storage'
        );

        curl_setopt_array($curl, array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2
        ));

        if ($payload !== null) {
            $json = json_encode($payload);
            if ($json === false) {
                curl_close($curl);
                return array('ok' => false, 'status' => 0, 'data' => null, 'error' => 'Payload GitHub tidak dapat diproses.');
            }
            curl_setopt($curl, CURLOPT_POSTFIELDS, $json);
            $headers[] = 'Content-Type: application/json';
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        }

        $body = curl_exec($curl);
        $curl_error = curl_error($curl);
        $status = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        if ($body === false) {
            return array('ok' => false, 'status' => $status, 'data' => null, 'error' => $curl_error ?: 'Koneksi ke GitHub gagal.');
        }

        $data = json_decode($body, true);
        $ok = ($status >= 200 && $status < 300);
        $error = '';
        if (!$ok) {
            $error = is_array($data) && !empty($data['message']) ? $data['message'] : ('GitHub API mengembalikan HTTP ' . $status . '.');
        }

        return array('ok' => $ok, 'status' => $status, 'data' => $data, 'error' => $error);
    }

    public function authenticated_user($token)
    {
        return $this->request('GET', '/user', $token);
    }

    public function public_repositories($token)
    {
        $result = $this->request('GET', '/user/repos?visibility=public&affiliation=owner&sort=updated&per_page=100', $token);
        if (!$result['ok'] || !is_array($result['data'])) {
            return $result;
        }

        $repositories = array();
        foreach ($result['data'] as $repository) {
            if (!empty($repository['private']) || empty($repository['full_name'])) {
                continue;
            }
            $repositories[] = array(
                'full_name' => $repository['full_name'],
                'name' => isset($repository['name']) ? $repository['name'] : '',
                'owner' => isset($repository['owner']['login']) ? $repository['owner']['login'] : '',
                'default_branch' => isset($repository['default_branch']) ? $repository['default_branch'] : ''
            );
        }

        $result['data'] = $repositories;
        return $result;
    }

    public function create_repository($token, $name, $description = '')
    {
        return $this->request('POST', '/user/repos', $token, array(
            'name' => $name,
            'description' => $description,
            'private' => false,
            'auto_init' => true
        ));
    }

    public function repositories($token)
    {
        $result = $this->request('GET', '/user/repos?visibility=all&affiliation=owner&sort=updated&per_page=100', $token);
        if (!$result['ok'] || !is_array($result['data'])) return $result;
        $items = array();
        foreach ($result['data'] as $repo) {
            if (empty($repo['full_name']) || !empty($repo['private'])) continue;
            $items[] = array(
                'full_name' => $repo['full_name'],
                'name' => isset($repo['name']) ? $repo['name'] : '',
                'owner' => isset($repo['owner']['login']) ? $repo['owner']['login'] : '',
                'default_branch' => !empty($repo['default_branch']) ? $repo['default_branch'] : 'main'
            );
        }
        $result['data'] = $items;
        return $result;
    }

    private function encoded_path($path)
    {
        $segments = explode('/', trim($path, '/'));
        return implode('/', array_map('rawurlencode', $segments));
    }

    public function get_file($owner, $repository, $path, $branch, $token)
    {
        $endpoint = '/repos/' . rawurlencode($owner) . '/' . rawurlencode($repository)
            . '/contents/' . $this->encoded_path($path) . '?ref=' . rawurlencode($branch);
        return $this->request('GET', $endpoint, $token);
    }

    public function get_blob($owner, $repository, $sha, $token)
    {
        $endpoint = '/repos/' . rawurlencode($owner) . '/' . rawurlencode($repository)
            . '/git/blobs/' . rawurlencode($sha);
        return $this->request('GET', $endpoint, $token);
    }

    public function put_file($owner, $repository, $path, $branch, $token, $contents, $message)
    {
        $existing = $this->get_file($owner, $repository, $path, $branch, $token);
        if (!$existing['ok'] && $existing['status'] !== 404) {
            return $existing;
        }

        $payload = array(
            'message' => $message,
            'content' => base64_encode($contents),
            'branch' => $branch
        );
        if ($existing['ok'] && !empty($existing['data']['sha'])) {
            $payload['sha'] = $existing['data']['sha'];
        }

        $endpoint = '/repos/' . rawurlencode($owner) . '/' . rawurlencode($repository)
            . '/contents/' . $this->encoded_path($path);
        return $this->request('PUT', $endpoint, $token, $payload);
    }

    public function delete_file($owner, $repository, $path, $branch, $token, $message = 'Remove replaced website asset')
    {
        $existing = $this->get_file($owner, $repository, $path, $branch, $token);
        if (!$existing['ok']) {
            if ($existing['status'] === 404) {
                return array('ok' => true, 'status' => 204, 'data' => null, 'error' => '');
            }
            return $existing;
        }
        if (empty($existing['data']['sha'])) {
            return array('ok' => false, 'status' => 0, 'data' => null, 'error' => 'SHA file lama tidak ditemukan.');
        }

        $endpoint = '/repos/' . rawurlencode($owner) . '/' . rawurlencode($repository)
            . '/contents/' . $this->encoded_path($path);
        return $this->request('DELETE', $endpoint, $token, array(
            'message' => $message,
            'sha' => $existing['data']['sha'],
            'branch' => $branch
        ));
    }
}
