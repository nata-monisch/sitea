<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_Models extends CI_Model
{
    public function find_by_username($username)
    {
        return $this->db->where('username', $username)->limit(1)->get('user')->row_array();
    }
}
