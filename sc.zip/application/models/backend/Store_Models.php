<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Store_Models extends CI_Model
{
    private $products = 'store_product';

    public function get_apps()
    {
        $rows = $this->db->select('id, name, publisher, logo, banner')
            ->order_by('name', 'ASC')->get('app')->result_array();
        foreach ($rows as &$row) {
            $row['slug'] = $this->slugify($row['name']);
        }
        unset($row);
        return $rows;
    }

    public function get_app($id)
    {
        return $this->db->where('id', (int) $id)->limit(1)->get('app')->row_array();
    }

    public function get_asset_options($app_id)
    {
        $rows = $this->db->select('id, app_id, name, category, rarity, icon')
            ->where('app_id', (int) $app_id)
            ->order_by("CASE WHEN category IS NULL OR TRIM(category) = '' THEN 1 ELSE 0 END", 'ASC', FALSE)
            ->order_by('category', 'ASC')->order_by('name', 'ASC')
            ->get('app-asset')->result_array();
        $groups = array();
        foreach ($rows as $row) {
            $category = trim((string) $row['category']);
            if ($category === '') $category = 'Uncategorized';
            if (!isset($groups[$category])) $groups[$category] = array();
            $groups[$category][] = array(
                'id' => (int) $row['id'], 'name' => $row['name'],
                'rarity' => $row['rarity'], 'icon' => $row['icon']
            );
        }
        return $groups;
    }

    public function get_asset($asset_id, $app_id)
    {
        return $this->db->where('id', (int) $asset_id)->where('app_id', (int) $app_id)
            ->limit(1)->get('app-asset')->row_array();
    }

    public function get_products($filters = array(), $limit = 25, $offset = 0)
    {
        $this->apply_filters($filters);
        return $this->db->select('p.*, a.name AS app_name, u.display_name AS seller_name, u.username AS seller_username')
            ->from($this->products . ' p')
            ->join('app a', 'a.id = p.app_id', 'left')
            ->join('user u', 'u.user_id = p.user_id', 'left')
            ->order_by('p.created_at', 'DESC')->order_by('p.id', 'DESC')
            ->limit((int) $limit, (int) $offset)->get()->result_array();
    }

    public function count_products($filters = array())
    {
        $this->apply_filters($filters);
        return (int) $this->db->count_all_results($this->products . ' p');
    }

    private function apply_filters($filters)
    {
        if (!empty($filters['user_id'])) $this->db->where('p.user_id', (int) $filters['user_id']);
        if (!empty($filters['search'])) {
            $this->db->group_start()->like('p.title', $filters['search'])->or_like('p.slug', $filters['search'])->group_end();
        }
        if (!empty($filters['app_id'])) $this->db->where('p.app_id', (int) $filters['app_id']);
        if (!empty($filters['type'])) $this->db->where('p.type', $filters['type']);
        if (!empty($filters['status'])) $this->db->where('p.status', $filters['status']);
    }

    public function get_product($id, $owner_id = 0)
    {
        $this->db->select('p.*, a.name AS app_name, a.publisher AS app_publisher, a.logo AS app_logo, a.banner AS app_banner, u.display_name AS seller_name, u.username AS seller_username, u.whatsapp AS seller_whatsapp')
            ->from($this->products . ' p')
            ->join('app a', 'a.id = p.app_id', 'left')
            ->join('user u', 'u.user_id = p.user_id', 'left')
            ->where('p.id', (int) $id);
        if ((int) $owner_id > 0) $this->db->where('p.user_id', (int) $owner_id);
        return $this->db->limit(1)->get()->row_array();
    }

    public function product_slug_exists($app_id, $slug, $except_id = 0)
    {
        $this->db->where('app_id', (int) $app_id)->where('slug', $slug);
        if ($except_id) $this->db->where('id !=', (int) $except_id);
        return $this->db->count_all_results($this->products) > 0;
    }

    public function insert_product($data)
    {
        if (!$this->db->insert($this->products, $data)) return false;
        return (int) $this->db->insert_id();
    }

    public function update_product($id, $data, $owner_id = 0)
    {
        $this->db->where('id', (int) $id);
        if ((int) $owner_id > 0) $this->db->where('user_id', (int) $owner_id);
        return $this->db->update($this->products, $data);
    }

    public function delete_product($id, $owner_id = 0)
    {
        $this->db->where('id', (int) $id);
        if ((int) $owner_id > 0) $this->db->where('user_id', (int) $owner_id);
        return $this->db->delete($this->products);
    }

    public function slugify($value)
    {
        $value = trim((string) $value);
        if (function_exists('mb_strtolower')) $value = mb_strtolower($value, 'UTF-8');
        else $value = strtolower($value);
        if (function_exists('iconv')) {
            $ascii = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);
            if ($ascii !== false) $value = $ascii;
        }
        $value = preg_replace('/[^a-z0-9\s-]/', '', $value);
        $value = preg_replace('/\s+/', '-', $value);
        $value = preg_replace('/-+/', '-', $value);
        return trim($value, '-');
    }
}
