<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile_Models extends CI_Model
{
    public function get_user($user_id)
    {
        return $this->db->where('user_id', (int) $user_id)->limit(1)->get('user')->row_array();
    }

    public function username_exists_except($username, $user_id)
    {
        return $this->db->where('username', $username)
            ->where('user_id !=', (int) $user_id)
            ->count_all_results('user') > 0;
    }

    public function update_user($user_id, array $data)
    {
        return $this->db->where('user_id', (int) $user_id)->update('user', $data);
    }
}
