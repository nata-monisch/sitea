<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Asset_App_Models extends CI_Model
{
    private $apps = 'app';
    private $assets = 'app-asset';

    public function get_apps()
    {
        return $this->db->order_by('name', 'ASC')->get($this->apps)->result_array();
    }

    public function get_app($id)
    {
        return $this->db->where('id', (int) $id)->limit(1)->get($this->apps)->row_array();
    }

    public function name_exists($name)
    {
        return $this->db->where('name', $name)->count_all_results($this->apps) > 0;
    }

    public function repository_exists($owner, $repo)
    {
        return $this->db->where('github_owner', $owner)->where('github_repository', $repo)->count_all_results($this->apps) > 0;
    }

    public function get_used_repositories()
    {
        return $this->db->select('github_owner, github_repository')->get($this->apps)->result_array();
    }

    public function insert_app(array $data)
    {
        $this->db->insert($this->apps, $data);
        return $this->db->insert_id();
    }

    public function update_app($id, array $data)
    {
        return $this->db->where('id', (int) $id)->update($this->apps, $data);
    }

    public function delete_app($id)
    {
        $this->db->trans_start();
        $this->db->where('app_id', (int) $id)->delete($this->assets);
        $this->db->where('id', (int) $id)->delete($this->apps);
        $this->db->trans_complete();
        return $this->db->trans_status();
    }

    /** Return the latest assets first, optionally filtered and paginated. */
    public function get_assets($app_id, $limit = NULL, $offset = 0, array $filters = array())
    {
        $this->apply_asset_filters($app_id, $filters);

        // Keep the same deterministic grouping as the public Assets Database:
        // Category A-Z, then Rarity A-Z, then Asset Name A-Z.
        // Empty values are placed after named values within each field.
        $this->db
            ->order_by("CASE WHEN category IS NULL OR TRIM(category) = '' THEN 1 ELSE 0 END", 'ASC', FALSE)
            ->order_by('category', 'ASC')
            ->order_by("CASE WHEN rarity IS NULL OR TRIM(rarity) = '' THEN 1 ELSE 0 END", 'ASC', FALSE)
            ->order_by('rarity', 'ASC')
            ->order_by('name', 'ASC')
            ->order_by('id', 'ASC');

        if ($limit !== NULL) {
            $this->db->limit(max(1, (int) $limit), max(0, (int) $offset));
        }

        // apply_asset_filters() already sets FROM; do not pass the table again.
        return $this->db->get()->result_array();
    }

    public function count_assets($app_id, array $filters = array())
    {
        $this->apply_asset_filters($app_id, $filters);
        // apply_asset_filters() already sets FROM; avoid adding the table twice.
        return (int) $this->db->count_all_results();
    }

    /** Return distinct filter values for an app. */
    public function get_asset_filter_options($app_id)
    {
        $categories = $this->db
            ->distinct()
            ->select('category')
            ->where('app_id', (int) $app_id)
            ->where('category IS NOT NULL', NULL, FALSE)
            ->where("TRIM(category) != ''", NULL, FALSE)
            ->order_by('category', 'ASC')
            ->get($this->assets)
            ->result_array();

        $rarities = $this->db
            ->distinct()
            ->select('rarity')
            ->where('app_id', (int) $app_id)
            ->where('rarity IS NOT NULL', NULL, FALSE)
            ->where("TRIM(rarity) != ''", NULL, FALSE)
            ->order_by('rarity', 'ASC')
            ->get($this->assets)
            ->result_array();

        return array(
            'categories' => array_values(array_map(function ($row) { return $row['category']; }, $categories)),
            'rarities' => array_values(array_map(function ($row) { return $row['rarity']; }, $rarities))
        );
    }

    private function apply_asset_filters($app_id, array $filters)
    {
        $this->db->from($this->assets)->where('app_id', (int) $app_id);

        $search = isset($filters['search']) ? trim((string) $filters['search']) : '';
        if ($search !== '') {
            // Search is intentionally limited to the asset name.
            $this->db->like('name', $search);
        }

        if (isset($filters['category']) && $filters['category'] !== '') {
            $this->db->where('category', (string) $filters['category']);
        }

        if (isset($filters['rarity']) && $filters['rarity'] !== '') {
            $this->db->where('rarity', (string) $filters['rarity']);
        }
    }

    public function get_asset($asset_id, $app_id)
    {
        return $this->db->where('id', (int) $asset_id)
            ->where('app_id', (int) $app_id)
            ->limit(1)
            ->get($this->assets)
            ->row_array();
    }

    public function asset_name_exists($app_id, $name, $except_id = 0)
    {
        $this->db->where('app_id', (int) $app_id)->where('name', $name);
        if ($except_id) {
            $this->db->where('id !=', (int) $except_id);
        }
        return $this->db->count_all_results($this->assets) > 0;
    }

    public function insert_asset(array $data)
    {
        return $this->db->insert($this->assets, $data);
    }

    public function update_asset($asset_id, $app_id, array $data)
    {
        return $this->db->where('id', (int) $asset_id)
            ->where('app_id', (int) $app_id)
            ->update($this->assets, $data);
    }

    public function delete_asset($asset_id, $app_id)
    {
        return $this->db->where('id', (int) $asset_id)
            ->where('app_id', (int) $app_id)
            ->delete($this->assets);
    }
}
