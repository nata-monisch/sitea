<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Website_Models extends CI_Model
{
    public function get_settings()
    {
        return $this->db->order_by('website_id', 'ASC')->limit(1)->get('website')->row_array();
    }

    public function update_settings(array $data)
    {
        $existing = $this->db->order_by('website_id', 'ASC')->limit(1)->get('website')->row_array();
        if (!$existing) {
            return false;
        }

        return $this->db->where('website_id', $existing['website_id'])->update('website', $data);
    }
}
