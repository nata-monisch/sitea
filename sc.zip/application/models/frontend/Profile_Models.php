<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile_Models extends CI_Model
{
    /**
     * Fetch public profile data by username.
     * Password and other private fields are intentionally excluded.
     */
    public function get_public_profile_by_username($username)
    {
        return $this->db
            ->select('user_id, display_name, username, bio, whatsapp, profile, banner, facebook, instagram, discord, tiktok, youtube')
            ->where('username', (string) $username)
            ->limit(1)
            ->get('user')
            ->row_array();
    }
}
