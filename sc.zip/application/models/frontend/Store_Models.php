<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Store_Models extends CI_Model
{
    private $products = 'store_product';

    public function get_apps()
    {
        $rows = $this->db->select('a.id, a.name, a.description, a.publisher, a.logo, a.banner, (SELECT COUNT(*) FROM ' . $this->products . ' p WHERE p.app_id = a.id AND p.status = \'Ready\') AS product_count', FALSE)
            ->from('app a')->order_by('a.name', 'ASC')->get()->result_array();
        foreach ($rows as &$row) $row['slug'] = $this->slugify($row['name']);
        unset($row);
        return $rows;
    }

    public function get_app_by_slug($slug)
    {
        $apps = $this->get_apps();
        $matches = array();
        foreach ($apps as $app) if ($app['slug'] === strtolower($slug)) $matches[] = $app;
        return count($matches) === 1 ? $matches[0] : null;
    }

    public function get_products($app_id = 0, $limit = 24, $offset = 0, $search = '', $type = '')
    {
        $this->db->select('p.*, a.name AS app_name, a.publisher AS app_publisher, u.display_name AS seller_name, u.username AS seller_username')
            ->from($this->products . ' p')->join('app a', 'a.id = p.app_id', 'left')
            ->join('user u', 'u.user_id = p.user_id', 'left');
        if ($app_id) $this->db->where('p.app_id', (int) $app_id);
        $this->db->where('p.status', 'Ready');
        if ($search !== '') $this->db->like('p.title', $search);
        if ($type !== '' && in_array($type, array('Akun', 'Item', 'Joki'), true)) $this->db->where('p.type', $type);
        return $this->db->order_by('p.created_at', 'DESC')->order_by('p.id', 'DESC')
            ->limit((int) $limit, (int) $offset)->get()->result_array();
    }

    public function count_products($app_id = 0, $search = '', $type = '')
    {
        $this->db->from($this->products . ' p');
        if ($app_id) $this->db->where('p.app_id', (int) $app_id);
        $this->db->where('p.status', 'Ready');
        if ($search !== '') $this->db->like('p.title', $search);
        if ($type !== '' && in_array($type, array('Akun', 'Item', 'Joki'), true)) $this->db->where('p.type', $type);
        return (int) $this->db->count_all_results();
    }

    public function get_product_by_slug($app_id, $slug)
    {
        return $this->db->select('p.*, a.name AS app_name, a.publisher AS app_publisher, a.logo AS app_logo, a.banner AS app_banner, u.display_name AS seller_name, u.username AS seller_username, u.whatsapp AS seller_whatsapp, u.profile AS seller_profile')
            ->from($this->products . ' p')->join('app a', 'a.id = p.app_id', 'left')
            ->join('user u', 'u.user_id = p.user_id', 'left')
            ->where('p.app_id', (int) $app_id)->where('p.slug', $slug)->limit(1)->get()->row_array();
    }

    public function get_related_products($app_id, $exclude_id, $limit = 4)
    {
        return $this->db->select('p.*, a.name AS app_name, u.display_name AS seller_name')
            ->from($this->products . ' p')->join('app a', 'a.id = p.app_id', 'left')
            ->join('user u', 'u.user_id = p.user_id', 'left')
            ->where('p.app_id', (int) $app_id)->where('p.id !=', (int) $exclude_id)->where('p.status', 'Ready')
            ->order_by('p.created_at', 'DESC')->limit((int) $limit)->get()->result_array();
    }


    public function get_latest_products($exclude_id = 0, $limit = 5)
    {
        return $this->db->select('p.id, p.title, p.slug, p.images, p.price, p.price_discount, p.status, p.type, a.name AS app_name')
            ->from($this->products . ' p')->join('app a', 'a.id = p.app_id', 'left')
            ->where('p.id !=', (int) $exclude_id)->where('p.status', 'Ready')
            ->order_by('p.created_at', 'DESC')->order_by('p.id', 'DESC')
            ->limit((int) $limit)->get()->result_array();
    }

    public function get_sitemap_products()
    {
        return $this->db->select('p.id, p.slug, p.updated_at, a.name AS app_name')
            ->from($this->products . ' p')->join('app a', 'a.id = p.app_id', 'left')
            ->order_by('p.updated_at', 'DESC')->get()->result_array();
    }

    public function slugify($value)
    {
        $value = trim((string) $value);
        $value = function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
        if (function_exists('iconv')) {
            $ascii = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);
            if ($ascii !== false) $value = $ascii;
        }
        $value = preg_replace('/[^a-z0-9\s-]/', '', $value);
        $value = preg_replace('/\s+/', '-', $value);
        $value = preg_replace('/-+/', '-', $value);
        return trim($value, '-');
    }
}
