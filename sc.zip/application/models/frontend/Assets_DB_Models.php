<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Assets_DB_Models extends CI_Model
{
    private $apps_table = 'app';
    private $assets_table = 'app-asset';

    /** Return all apps with their public asset counts. */
    public function get_apps_with_asset_counts()
    {
        $apps = $this->db->order_by('name', 'ASC')->get($this->apps_table)->result_array();
        if (!$apps) {
            return array();
        }

        $count_rows = $this->db
            ->select('app_id, COUNT(*) AS asset_count', FALSE)
            ->group_by('app_id')
            ->get($this->assets_table)
            ->result_array();

        $counts = array();
        foreach ($count_rows as $row) {
            $counts[(int) $row['app_id']] = (int) $row['asset_count'];
        }

        foreach ($apps as &$app) {
            $app['asset_count'] = isset($counts[(int) $app['id']]) ? $counts[(int) $app['id']] : 0;
            $app['slug'] = $this->slugify_name($app['name']);
            if ($app['slug'] === '') {
                $app['slug'] = 'app-' . (int) $app['id'];
            }
        }
        unset($app);

        return $apps;
    }

    /** Resolve an app using its URL slug. Ambiguous slugs are rejected. */
    public function get_app_by_slug($slug)
    {
        $slug = strtolower(trim((string) $slug));
        $matches = array();
        $apps = $this->db->order_by('name', 'ASC')->get($this->apps_table)->result_array();

        foreach ($apps as $app) {
            $app_slug = $this->slugify_name($app['name']);
            if ($app_slug === '') {
                $app_slug = 'app-' . (int) $app['id'];
            }
            if ($app_slug === $slug) {
                $matches[] = $app;
            }
        }

        if (count($matches) !== 1) {
            return NULL;
        }

        $matches[0]['slug'] = $this->slugify_name($matches[0]['name']);
        if ($matches[0]['slug'] === '') {
            $matches[0]['slug'] = 'app-' . (int) $matches[0]['id'];
        }
        return $matches[0];
    }

    /** Return all assets belonging to one app. */
    public function get_assets_by_app($app_id)
    {
        $assets = $this->db
            ->where('app_id', (int) $app_id)
            // Keep categories grouped alphabetically, then sort asset names A-Z.
            // Empty categories are placed after named categories.
            ->order_by("CASE WHEN category IS NULL OR TRIM(category) = '' THEN 1 ELSE 0 END", 'ASC', FALSE)
            ->order_by('category', 'ASC')
            // Within each category, order rarity A-Z before asset name A-Z.
            ->order_by("CASE WHEN rarity IS NULL OR TRIM(rarity) = '' THEN 1 ELSE 0 END", 'ASC', FALSE)
            ->order_by('rarity', 'ASC')
            ->order_by('name', 'ASC')
            ->order_by('id', 'ASC')
            ->get($this->assets_table)
            ->result_array();

        foreach ($assets as &$asset) {
            $asset['slug'] = $this->slugify_name($asset['name']);
            if ($asset['slug'] === '') {
                $asset['slug'] = 'asset-' . (int) $asset['id'];
            }
        }
        unset($asset);

        return $assets;
    }

    /** Resolve an asset slug inside a specific app. Ambiguous slugs are rejected. */
    public function get_asset_by_slug($app_id, $slug)
    {
        $slug = strtolower(trim((string) $slug));
        $matches = array();
        $assets = $this->get_assets_by_app($app_id);

        foreach ($assets as $asset) {
            if ($asset['slug'] === $slug) {
                $matches[] = $asset;
            }
        }

        return count($matches) === 1 ? $matches[0] : NULL;
    }

    /**
     * Slug rules for public URLs:
     * - lowercase all text;
     * - transliterate accented characters when possible;
     * - remove special characters (apostrophes are removed, not replaced);
     * - replace whitespace with hyphens and collapse repeated hyphens.
     */
    public function slugify_name($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }

        if (function_exists('mb_strtolower')) {
            $value = mb_strtolower($value, 'UTF-8');
        } else {
            $value = strtolower($value);
        }

        if (function_exists('iconv')) {
            $transliterated = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);
            if ($transliterated !== FALSE) {
                $value = $transliterated;
            }
        }

        // Remove punctuation/symbols first so "Bloodpact's" becomes "bloodpacts".
        $value = preg_replace('/[^a-z0-9\s-]/', '', $value);
        $value = preg_replace('/\s+/', '-', $value);
        $value = preg_replace('/-+/', '-', $value);

        return trim($value, '-');
    }
}
