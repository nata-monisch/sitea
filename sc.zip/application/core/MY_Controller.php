<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller
{
    protected $data = array();
    protected $current_user_password_hash = '';

    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('url', 'form'));
        $this->load->library(array('session', 'form_validation'));
    }

    protected function require_login()
    {
        if (!$this->session->userdata('user_id')) {
            // $this->session->set_flashdata('error', 'Please sign in');
            redirect('auth/');
            exit;
        }
    }

    protected function prepare_backend($page_title, $crumb, $active_menu)
    {
        $this->load->model('backend/Website_Models', 'website_model');
        $this->load->model('backend/Profile_Models', 'profile_model');

        $website = $this->website_model->get_settings();
        if (!$website) {
            show_error('Data konfigurasi website tidak ditemukan di tabel website. Isi data website terlebih dahulu.', 500);
            return;
        }

        $user_id = (int) $this->session->userdata('user_id');
        $user = $user_id ? $this->profile_model->get_user($user_id) : array();

        if (!$user) {
            $this->session->sess_destroy();
            redirect('auth/');
            exit;
        }

        $this->current_user_password_hash = $user['password'];
        unset($user['password']); // Never expose the password hash to view templates.

        $this->data = array(
            'website'      => $website,
            'user'         => $user,
            'title'        => $page_title . ' | ' . $website['name'],
            'description'  => $website['description'],
            'thumbnail'    => $website['banner'],
            'page_url'     => rtrim(current_url(), '/') . '/',
            'crumb'        => $crumb,
            'active_menu'  => $active_menu,
            'flash_success'=> $this->session->flashdata('success'),
            'flash_error'  => $this->session->flashdata('error'),
            'form_errors'  => ''
        );
    }

    protected function render_backend($view)
    {
        $this->load->view($view, $this->data);
    }

    /** Return the decrypted GitHub credentials for backend-only operations. */
    protected function github_storage_context()
    {
        $website = $this->data['website'];
        if (empty($website['github_token']) || empty($website['github_owner']) || empty($website['github_repository'])) {
            return array('ok' => false, 'error' => 'Hubungkan GitHub dan pilih repository publik terlebih dahulu.');
        }
        if (empty($website['github_branch'])) {
            return array('ok' => false, 'error' => 'Branch GitHub belum diatur.');
        }
        if (empty($this->config->item('encryption_key'))) {
            return array('ok' => false, 'error' => 'Encryption key CodeIgniter belum diatur di application/config/config.php.');
        }

        $this->load->library('encryption');
        $token = $this->encryption->decrypt($website['github_token']);
        if (!is_string($token) || $token === '') {
            return array('ok' => false, 'error' => 'Token GitHub tidak dapat dibuka. Periksa encryption_key di config.php.');
        }

        $this->load->library('github_storage');
        return array(
            'ok' => true,
            'token' => $token,
            'owner' => $website['github_owner'],
            'repository' => $website['github_repository'],
            'branch' => $website['github_branch']
        );
    }

    /** Validate and upload one raster image to its fixed path in GitHub. */
    protected function upload_github_image($field, $base_path, $max_size = 5120, $use_custom_cdn = false)
    {
        if (empty($_FILES[$field]) || !isset($_FILES[$field]['name']) || $_FILES[$field]['name'] === '') {
            return array('path' => null, 'url' => null, 'error' => null);
        }

        $file = $_FILES[$field];
        if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK || empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            return array('path' => null, 'url' => null, 'error' => 'Upload gambar gagal atau tidak valid.');
        }
        if (empty($file['size']) || $file['size'] > ($max_size * 1024)) {
            return array('path' => null, 'url' => null, 'error' => 'Ukuran gambar maksimal ' . round($max_size / 1024, 1) . ' MB.');
        }

        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $mime_map = array(
            'png' => 'image/png',
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'webp' => 'image/webp'
        );
        if (!isset($mime_map[$extension])) {
            return array('path' => null, 'url' => null, 'error' => 'Format gambar harus PNG, JPG, JPEG, atau WEBP.');
        }

        $image_info = @getimagesize($file['tmp_name']);
        if (!$image_info || empty($image_info['mime']) || $image_info['mime'] !== $mime_map[$extension]) {
            return array('path' => null, 'url' => null, 'error' => 'Isi file tidak sesuai dengan ekstensi gambar.');
        }
        $contents = @file_get_contents($file['tmp_name']);
        if ($contents === false || $contents === '') {
            return array('path' => null, 'url' => null, 'error' => 'File gambar tidak dapat dibaca.');
        }

        $context = $this->github_storage_context();
        if (!$context['ok']) {
            return array('path' => null, 'url' => null, 'error' => $context['error']);
        }
        // Use a new filename for every upload so browser/CDN caches cannot serve an old image.
        // Timestamp is part of the filename, immediately before the extension.
        $github_path = trim($base_path, '/') . '-' . time() . '.' . $extension;
        $result = $this->github_storage->put_file(
            $context['owner'],
            $context['repository'],
            $github_path,
            $context['branch'],
            $context['token'],
            $contents,
            'Upload website asset: ' . basename($github_path)
        );
        if (!$result['ok']) {
            return array('path' => null, 'url' => null, 'error' => 'GitHub: ' . $result['error']);
        }

        // Save the jsDelivr URL in the database. The Custom CDN is deliberately
        // not wrapped around this URL, so database image fields remain canonical.
        // A unique filename (timestamp before the extension) handles cache busting.
        $public_url = 'https://cdn.jsdelivr.net/gh/' . $context['owner'] . '/'
            . $context['repository'] . '@' . $context['branch'] . '/' . $github_path;

        return array('path' => $github_path, 'url' => $public_url, 'error' => null);
    }

    /** Upload a validated .ico file directly as /favicon.ico in the domain root. */
    protected function upload_root_favicon($field, $max_size = 2048)
    {
        if (empty($_FILES[$field]) || !isset($_FILES[$field]['name']) || $_FILES[$field]['name'] === '') {
            return array('path' => null, 'error' => null);
        }
        $file = $_FILES[$field];
        if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK || empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            return array('path' => null, 'error' => 'Upload favicon gagal atau tidak valid.');
        }
        if (strtolower(pathinfo($file['name'], PATHINFO_EXTENSION)) !== 'ico') {
            return array('path' => null, 'error' => 'Favicon wajib menggunakan ekstensi .ico.');
        }
        if (empty($file['size']) || $file['size'] > ($max_size * 1024)) {
            return array('path' => null, 'error' => 'Ukuran favicon maksimal 2 MB.');
        }

        $handle = @fopen($file['tmp_name'], 'rb');
        $header = $handle ? fread($handle, 6) : false;
        if ($handle) fclose($handle);
        if ($header === false || strlen($header) !== 6) {
            return array('path' => null, 'error' => 'File favicon ICO tidak valid.');
        }
        $ico = unpack('vreserved/vtype/vcount', $header);
        if (!$ico || $ico['reserved'] !== 0 || $ico['type'] !== 1 || $ico['count'] < 1) {
            return array('path' => null, 'error' => 'File favicon harus berupa file ICO yang valid.');
        }

        $destination = FCPATH . 'favicon.ico';
        if (!@move_uploaded_file($file['tmp_name'], $destination)) {
            return array('path' => null, 'error' => 'Favicon tidak dapat disimpan di root domain. Periksa permission folder.');
        }
        @chmod($destination, 0644);
        return array('path' => 'favicon.ico?t=' . time(), 'error' => null);
    }

    /** Parse GitHub repository coordinates from a stored asset URL. */
    protected function github_asset_location_from_url($asset_url)
    {
        $asset_url = trim((string) $asset_url);
        if ($asset_url === '') {
            return null;
        }

        $parts = @parse_url($asset_url);
        if (!is_array($parts) || empty($parts['host']) || empty($parts['path'])) {
            return null;
        }

        $host = strtolower($parts['host']);
        $source_path = $parts['path'];

        // Support the previous jsDelivr URL format, including legacy custom-CDN wrappers.
        if (strpos($host, 'cdn.jsdelivr.net') !== false) {
            $source_url = $asset_url;
            if (!empty($parts['query'])) {
                $query = array();
                parse_str($parts['query'], $query);
                if (!empty($query['url'])) {
                    $source_url = $query['url'];
                }
            }
            $source_url = rawurldecode($source_url);
            $source_path = parse_url($source_url, PHP_URL_PATH);
            if (!$source_path || !preg_match('~^/gh/([^/]+)/([^/]+)@([^/]+)/(.+)$~', $source_path, $matches)) {
                return null;
            }

            return array(
                'owner' => rawurldecode($matches[1]),
                'repository' => rawurldecode($matches[2]),
                'branch' => rawurldecode($matches[3]),
                'path' => rawurldecode($matches[4])
            );
        }

        // New direct raw.githubusercontent.com URL format:
        // /{owner}/{repository}/{branch}/{file-path}
        if ($host === 'raw.githubusercontent.com') {
            $segments = explode('/', trim($source_path, '/'));
            if (count($segments) < 4) {
                return null;
            }
            return array(
                'owner' => rawurldecode($segments[0]),
                'repository' => rawurldecode($segments[1]),
                'branch' => rawurldecode($segments[2]),
                'path' => rawurldecode(implode('/', array_slice($segments, 3)))
            );
        }

        return null;
    }

    protected function github_asset_path_from_url($asset_url)
    {
        $location = $this->github_asset_location_from_url($asset_url);
        return $location ? $location['path'] : null;
    }

    /** Remove a previous asset only when its repository location changed. */
    protected function delete_replaced_github_asset($old_url, $new_path)
    {
        $old_location = $this->github_asset_location_from_url($old_url);
        if (!$old_location) {
            return true;
        }
        $context = $this->github_storage_context();
        if (!$context['ok']) {
            log_message('error', 'GitHub old asset cleanup skipped: ' . $context['error']);
            return false;
        }

        $same_location = ($old_location['owner'] === $context['owner'])
            && ($old_location['repository'] === $context['repository'])
            && ($old_location['branch'] === $context['branch'])
            && ($old_location['path'] === $new_path);
        if ($same_location) {
            return true;
        }

        $result = $this->github_storage->delete_file(
            $old_location['owner'],
            $old_location['repository'],
            $old_location['path'],
            $old_location['branch'],
            $context['token'],
            'Remove replaced website asset: ' . basename($old_location['path'])
        );
        if (!$result['ok']) {
            log_message('error', 'GitHub old asset cleanup failed for ' . $old_location['owner'] . '/' . $old_location['repository'] . '/' . $old_location['path'] . ': ' . $result['error']);
            return false;
        }
        return true;
    }

    /** Roll back a new GitHub asset unless it overwrote the still-referenced old path. */
    protected function rollback_github_asset($old_url, $new_path)
    {
        $old_location = $this->github_asset_location_from_url($old_url);
        $context = $this->github_storage_context();
        if ($old_location && $context['ok']
            && $old_location['owner'] === $context['owner']
            && $old_location['repository'] === $context['repository']
            && $old_location['branch'] === $context['branch']
            && $old_location['path'] === $new_path) {
            return true;
        }
        return $this->delete_github_asset_path($new_path);
    }

    /** Delete a just-uploaded file when the related database update failed. */
    protected function delete_github_asset_path($path)
    {
        if (!$path) return false;
        $context = $this->github_storage_context();
        if (!$context['ok']) return false;
        $result = $this->github_storage->delete_file(
            $context['owner'], $context['repository'], $path,
            $context['branch'], $context['token'], 'Rollback failed website asset update'
        );
        return !empty($result['ok']);
    }

    protected function safe_social_url($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }
        if (!preg_match('~^https?://~i', $value)) {
            return false;
        }
        return filter_var($value, FILTER_VALIDATE_URL) ? $value : false;
    }
}
