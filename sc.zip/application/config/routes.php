<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'backend/auth/index';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

// Public Assets Database pages. More specific detail route comes before app route.
$route['assets-db'] = 'frontend/Assets_DB/index';
$route['assets-db/([a-zA-Z0-9-]+)/([a-zA-Z0-9-]+)'] = 'frontend/Assets_DB/details/$1/$2';
$route['assets-db/([a-zA-Z0-9-]+)'] = 'frontend/Assets_DB/app/$1';

// Public user profile: https://example.com/@username
$route['@([a-zA-Z0-9_-]+)'] = 'frontend/profile/index/$1';

// Public authentication.
$route['auth'] = 'backend/auth/index';
$route['auth/'] = 'backend/auth/index';

// Authenticated backend routes.
$route['backend'] = 'backend/dashboard/index';
$route['backend/'] = 'backend/dashboard/index';
$route['backend/logout'] = 'backend/auth/logout';
$route['backend/logout/'] = 'backend/auth/logout';
$route['backend/profile'] = 'backend/profile/index';
$route['backend/profile/'] = 'backend/profile/index';
$route['backend/web-general'] = 'backend/Web_General/index';
$route['backend/web-general/'] = 'backend/Web_General/index';
$route['backend/web-appearance'] = 'backend/Web_Appearance/index';
$route['backend/web-appearance/'] = 'backend/Web_Appearance/index';
$route['backend/web-social'] = 'backend/Web_Social/index';
$route['backend/web-social/'] = 'backend/Web_Social/index';

$route['backend/web-storage'] = 'backend/Web_Storage/index';
$route['backend/web-storage/'] = 'backend/Web_Storage/index';

// Asset App uses readable app slugs and an optional page number.
$route['backend/asset-app/([a-zA-Z0-9-]+)/([1-9][0-9]*)'] = 'backend/Asset_app/index/$1/$2';
$route['backend/asset-app/([a-zA-Z0-9-]+)'] = 'backend/Asset_app/index/$1';
$route['backend/asset-app'] = 'backend/Asset_app/index';
$route['backend/asset-app/'] = 'backend/Asset_app/index';

// Store products (backend management and public marketplace).
$route['backend/store'] = 'backend/Store/index';
$route['backend/store/'] = 'backend/Store/index';
$route['backend/store/create'] = 'backend/Store/create';
$route['backend/store/create/'] = 'backend/Store/create';
$route['backend/store/edit/([0-9]+)'] = 'backend/Store/edit/$1';
$route['backend/store/edit/([0-9]+)/'] = 'backend/Store/edit/$1';
$route['backend/store/save/([0-9]+)'] = 'backend/Store/save/$1';
$route['backend/store/save/([0-9]+)/'] = 'backend/Store/save/$1';
$route['backend/store/delete/([0-9]+)'] = 'backend/Store/delete/$1';
$route['backend/store/delete/([0-9]+)/'] = 'backend/Store/delete/$1';
$route['backend/store/asset-options/([0-9]+)'] = 'backend/Store/asset_options/$1';
$route['backend/store/asset-options/([0-9]+)/'] = 'backend/Store/asset_options/$1';

// Public store routes and sitemap.
$route['store/sitemap.xml'] = 'frontend/Store/sitemap';
$route['store'] = 'frontend/Store/index';
$route['store/'] = 'frontend/Store/index';
$route['store/([a-z0-9-]+)/([a-z0-9-]+)'] = 'frontend/Store/detail/$1/$2';
$route['store/([a-z0-9-]+)/([a-z0-9-]+)/'] = 'frontend/Store/detail/$1/$2';
$route['store/([a-z0-9-]+)'] = 'frontend/Store/category/$1';
$route['store/([a-z0-9-]+)/'] = 'frontend/Store/category/$1';
