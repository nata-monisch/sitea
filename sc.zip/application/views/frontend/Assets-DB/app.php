<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <?php include APPPATH . 'views/frontend/include/header.php'; ?>
    <?php include APPPATH . 'views/frontend/include/css.php'; ?>
</head>
<body>
    <?php include APPPATH . 'views/frontend/include/menu.php'; ?>

    <main id="main-content">
        <section class="wrap assets-db-section" aria-labelledby="assetsAppTitle">
            <nav class="assets-db-breadcrumb" aria-label="Breadcrumb">
                <a href="<?= base_url(); ?>">Home</a>
                <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
                <a href="<?= site_url('assets-db/'); ?>">Assets Database</a>
                <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
                <span><?= html_escape($app['name']); ?></span>
            </nav>

            <section class="assets-db-app-hero">
                <?php if (!empty($app['banner_url'])): ?>
                    <img class="assets-db-app-hero-image" src="<?= $website['cdn_url'].html_escape($app['banner_url']); ?>" alt="" fetchpriority="high">
                <?php endif; ?>
                <div class="assets-db-app-hero-overlay"></div>
                <div class="assets-db-app-hero-content">
                    <div class="assets-db-app-hero-logo">
                        <?php if (!empty($app['logo_url'])): ?>
                            <img src="<?= $website['cdn_url'].html_escape($app['logo_url']); ?>" alt="<?= html_escape($app['name']); ?>">
                        <?php else: ?>
                            <i class="fa-solid fa-gamepad" aria-hidden="true"></i>
                        <?php endif; ?>
                    </div>
                    <div class="assets-db-app-hero-copy">
                        <h1 id="assetsAppTitle"><?= html_escape($app['name']); ?></h1>
                        <p class="assets-db-publisher">Published by <strong><?= html_escape($app['publisher']); ?></strong></p>
                    </div>
                </div>
            </section>

            <?php if (trim((string) $app['description']) !== ''): ?>
                <div class="assets-db-app-description">
                    <span class="assets-db-section-icon"><i class="fa-regular fa-circle-info" aria-hidden="true"></i></span>
                    <p><?= nl2br(html_escape($app['description'])); ?></p>
                </div>
            <?php endif; ?>

            <div class="assets-db-list-heading">
                <div>
                    <h2>List Assets</h2>
                    <span class="assets-db-result-count"><strong data-assets-result-count><?= (int) count($assets); ?></strong> assets</span>
                </div>
            </div>

            <?php if (!empty($assets)): ?>
                <div class="assets-db-filter-toolbar" role="search" aria-label="Filter assets">
                    <label class="assets-db-search">
                        <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
                        <input type="search" placeholder="Search assets..." aria-label="Search assets" autocomplete="off" data-assets-search>
                    </label>

                    <div class="assets-db-searchable-select" data-assets-category-select>
                        <button class="assets-db-select-trigger" type="button" aria-haspopup="listbox" aria-expanded="false" data-category-trigger>
                            <span data-category-label>All Categories</span>
                            <i class="fa-solid fa-chevron-down" aria-hidden="true"></i>
                        </button>
                        <div class="assets-db-select-menu" data-category-menu hidden>
                            <label class="assets-db-select-search">
                                <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
                                <input type="search" placeholder="Search category..." aria-label="Search categories" autocomplete="off" data-category-search>
                            </label>
                            <div class="assets-db-select-options" role="listbox" aria-label="Categories">
                                <button type="button" role="option" aria-selected="true" data-category-option data-value="">All Categories</button>
                                <?php foreach ($categories as $category): ?>
                                    <button type="button" role="option" aria-selected="false" data-category-option data-value="<?= html_escape(strtolower($category)); ?>"><?= html_escape($category); ?></button>
                                <?php endforeach; ?>
                            </div>
                            <p class="assets-db-select-empty" data-category-empty hidden>No categories found.</p>
                        </div>
                    </div>

                    <label class="assets-db-native-select">
                        <span class="sr-only">Select rarity</span>
                        <select aria-label="Filter by rarity" data-assets-rarity>
                            <option value="">All Rarities</option>
                            <?php
                            $rarities = array();
                            foreach ($assets as $asset) {
                                $rarity = trim((string) $asset['rarity']);
                                if ($rarity !== '') $rarities[strtolower($rarity)] = $rarity;
                            }
                            natcasesort($rarities);
                            foreach ($rarities as $rarity): ?>
                                <option value="<?= html_escape(strtolower($rarity)); ?>"><?= html_escape($rarity); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <i class="fa-solid fa-chevron-down" aria-hidden="true"></i>
                    </label>
                </div>
            <?php endif; ?>

            <?php if (!empty($assets)): ?>
                <div class="assets-db-asset-grid" data-assets-grid>
                    <?php foreach ($assets as $index => $asset): ?>
                        <a class="assets-db-asset-card" href="<?= html_escape($asset['detail_url']); ?>"
                           data-assets-card
                           data-assets-category="<?= html_escape(strtolower((string) $asset['category'])); ?>"
                           data-assets-rarity="<?= html_escape(strtolower((string) $asset['rarity'])); ?>"
                           data-assets-search-text="<?= html_escape(function_exists('mb_strtolower') ? mb_strtolower((string) $asset['name'], 'UTF-8') : strtolower((string) $asset['name'])); ?>">
                            <span class="assets-db-asset-image">
                                <?php if (!empty($asset['icon_url'])): ?>
                                    <?php $icon_src = $website['cdn_url'].html_escape($asset['icon_url']); ?>
                                    <?php if ($index < 20): ?>
                                        <img src="<?= $icon_src; ?>" alt="<?= html_escape($asset['name']); ?>">
                                    <?php else: ?>
                                        <img class="lazy" data-src="<?= $icon_src; ?>" src="data:image/png;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=" alt="<?= html_escape($asset['name']); ?>">
                                    <?php endif; ?>
                                <?php else: ?>
                                    <i class="fa-regular fa-image" aria-hidden="true"></i>
                                <?php endif; ?>
                            </span>
                            <span class="assets-db-asset-copy">
                                <?php if (!empty($asset['category'])): ?><small><?= html_escape($asset['category']); ?></small><?php endif; ?>
                                <strong><?= html_escape($asset['name']); ?></strong>
                                <?php if (!empty($asset['rarity'])): ?><em><?= html_escape($asset['rarity']); ?></em><?php endif; ?>
                            </span>
                        </a>
                    <?php endforeach; ?>
                </div>
                <div class="assets-db-empty assets-db-empty-filter" data-assets-empty hidden>
                    <span><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i></span>
                    <h2>No assets found</h2>
                    <p>Try another keyword or choose a different category or rarity.</p>
                </div>
            <?php else: ?>
                <div class="assets-db-empty">
                    <span><i class="fa-solid fa-box-open" aria-hidden="true"></i></span>
                    <h2>No assets in this app</h2>
                    <p>Assets for <?= html_escape($app['name']); ?> will appear here once they have been added.</p>
                </div>
            <?php endif; ?>

            <div class="assets-db-back-link-wrap">
                <a class="assets-db-back-link" href="<?= site_url('assets-db/'); ?>"><i class="fa-solid fa-arrow-left" aria-hidden="true"></i> All apps</a>
            </div>
        </section>
    </main>

    <?php include APPPATH . 'views/frontend/include/footer.php'; ?>
    <?php include APPPATH . 'views/frontend/include/js.php'; ?>
</body>
</html>
