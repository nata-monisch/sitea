<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <?php include APPPATH . 'views/frontend/include/header.php'; ?>
    <?php include APPPATH . 'views/frontend/include/css.php'; ?>
</head>
<body>
    <?php include APPPATH . 'views/frontend/include/menu.php'; ?>

    <main id="main-content">
        <section class="wrap assets-db-section assets-db-detail-section" aria-labelledby="assetsDetailTitle">
            <nav class="assets-db-breadcrumb" aria-label="Breadcrumb">
                <a href="<?= base_url(); ?>">Home</a>
                <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
                <a href="<?= site_url('assets-db/'); ?>">Assets Database</a>
                <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
                <a href="<?= site_url('assets-db/' . $app['slug'] . '/'); ?>"><?= html_escape($app['name']); ?></a>
                <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
                <span><?= html_escape($app_asset['name']); ?></span>
            </nav>

            <section class="assets-db-detail-hero">
                <div class="assets-db-detail-art">
                    <?php if (!empty($app_asset['icon_url'])): ?>
                        <img src="<?= $website['cdn_url'].html_escape($app_asset['icon_url']); ?>" alt="<?= html_escape($app_asset['name']); ?>" fetchpriority="high">
                    <?php else: ?>
                        <span><i class="fa-regular fa-image" aria-hidden="true"></i></span>
                    <?php endif; ?>
                </div>
                <div class="assets-db-detail-heading">
                    <a class="assets-db-detail-app" href="<?= site_url('assets-db/' . $app['slug'] . '/'); ?>">
                        <?php if (!empty($app['logo_url'])): ?><img src="<?= $website['cdn_url'].html_escape($app['logo_url']); ?>" alt="" loading="lazy"><?php endif; ?>
                        <span><?= html_escape($app['name']); ?></span>
                        <i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></i>
                    </a>
                    <h1 id="assetsDetailTitle"><?= html_escape($app_asset['name']); ?></h1>
                    <div class="assets-db-detail-tags">
                        <?php if (!empty($app_asset['category'])): ?><span><i class="fa-solid fa-layer-group" aria-hidden="true"></i> <?= html_escape($app_asset['category']); ?></span><?php endif; ?>
                        <?php if (!empty($app_asset['rarity'])): ?><span class="assets-db-rarity"><i class="fa-solid fa-sparkles" aria-hidden="true"></i> <?= html_escape($app_asset['rarity']); ?></span><?php endif; ?>
                    </div>
                    <?php if (!empty($app_asset['description'])): ?>
                        <p class="assets-db-detail-description"><?= nl2br(html_escape($app_asset['description'])); ?></p>
                    <?php endif; ?>
                </div>
            </section>

            <div class="assets-db-detail-layout">
                <article class="assets-db-detail-content">
                    <div class="assets-db-detail-content-heading">
                        <span class="assets-db-section-icon"><i class="fa-regular fa-file-lines" aria-hidden="true"></i></span>
                        <div><span class="assets-db-eyebrow">ASSET INFORMATION</span><h2>About this asset</h2></div>
                    </div>
                    <?php if (trim((string) $app_asset['detail']) !== ''): ?>
                        <div class="assets-db-detail-text"><?= nl2br(html_escape($app_asset['detail'])); ?></div>
                    <?php elseif (!empty($app_asset['description'])): ?>
                        <div class="assets-db-detail-text"><?= nl2br(html_escape($app_asset['description'])); ?></div>
                    <?php else: ?>
                        <p class="assets-db-muted">No additional information has been added for this asset yet.</p>
                    <?php endif; ?>
                </article>

                <aside class="assets-db-detail-sidebar">
                    <section class="assets-db-detail-info-card">
                        <h2>Information</h2>
                        <dl>
                            <div><dt>App</dt><dd><?= html_escape($app['name']); ?></dd></div>
                            <?php if (!empty($app_asset['category'])): ?><div><dt>Category</dt><dd><?= html_escape($app_asset['category']); ?></dd></div><?php endif; ?>
                            <?php if (!empty($app_asset['rarity'])): ?><div><dt>Rarity</dt><dd><?= html_escape($app_asset['rarity']); ?></dd></div><?php endif; ?>
                        </dl>
                    </section>
                </aside>
            </div>
            
            <!--
            <?php if (!empty($related_assets)): ?>
                <section class="assets-db-related" aria-labelledby="assetsRelatedTitle">
                    <div class="assets-db-list-heading">
                        <div><span class="assets-db-eyebrow">KEEP EXPLORING</span><h2 id="assetsRelatedTitle">Related Assets</h2></div>
                        <a class="assets-db-text-link" href="<?= site_url('assets-db/' . $app['slug'] . '/'); ?>">View all <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></a>
                    </div>
                    <div class="assets-db-asset-grid assets-db-related-grid">
                        <?php foreach ($related_assets as $related): ?>
                            <a class="assets-db-asset-card" href="<?= html_escape($related['detail_url']); ?>">
                                <span class="assets-db-asset-image">
                                    <?php if (!empty($related['icon_url'])): ?><img src="<?= html_escape($related['icon_url']); ?>" alt="<?= html_escape($related['name']); ?>" loading="lazy"><?php else: ?><i class="fa-regular fa-image" aria-hidden="true"></i><?php endif; ?>
                                </span>
                                <span class="assets-db-asset-copy">
                                    <?php if (!empty($related['category'])): ?><small><?= html_escape($related['category']); ?></small><?php endif; ?>
                                    <strong><?= html_escape($related['name']); ?></strong>
                                    <?php if (!empty($related['rarity'])): ?><em><?= html_escape($related['rarity']); ?></em><?php endif; ?>
                                </span>
                                <i class="fa-solid fa-arrow-up-right-from-square assets-db-card-arrow" aria-hidden="true"></i>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </section>
            <?php endif; ?>

            <div class="assets-db-back-link-wrap">
                <a class="assets-db-back-link" href="<?= site_url('assets-db/' . $app['slug'] . '/'); ?>"><i class="fa-solid fa-arrow-left" aria-hidden="true"></i> Back to <?= html_escape($app['name']); ?></a>
            </div>
            -->
        </section>
    </main>

    <?php include APPPATH . 'views/frontend/include/footer.php'; ?>
    <?php include APPPATH . 'views/frontend/include/js.php'; ?>
</body>
</html>
