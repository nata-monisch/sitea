<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <?php include APPPATH . 'views/frontend/include/header.php'; ?>
    <?php include APPPATH . 'views/frontend/include/css.php'; ?>
</head>
<body>
    <?php include APPPATH . 'views/frontend/include/menu.php'; ?>

    <main id="main-content">
        <section class="wrap assets-db-section" aria-labelledby="assetsDbTitle">
            <nav class="assets-db-breadcrumb" aria-label="Breadcrumb">
                <a href="<?= base_url(); ?>">Home</a>
                <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
                <span>Assets Database</span>
            </nav>

            <header class="assets-db-heading">
                <div class="assets-db-heading-copy">
                    <span class="assets-db-eyebrow"><i class="fa-solid fa-database" aria-hidden="true"></i> COLLECTION ARCHIVE</span>
                    <h1 id="assetsDbTitle">Assets Database</h1>
                    <p>Explore characters, items, and collections from your favorite games in one place.</p>
                </div>
                <div class="assets-db-heading-icon" aria-hidden="true"><img src="<?= $website['cdn_url'].base_url('assets/img/Assets-DB.png');?>"></div>
            </header>

            <div class="assets-db-toolbar">
                <div class="assets-db-search">
                    <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
                    <input type="search" placeholder="Search apps or publishers..." aria-label="Search apps" autocomplete="off" data-assets-search>
                    <kbd>⌕</kbd>
                </div>
            </div>

            <?php if (!empty($apps)): ?>
                <div class="assets-db-app-grid" data-assets-grid>
                    <?php foreach ($apps as $app): ?>
                        <a class="assets-db-app-card" href="<?= site_url('assets-db/' . $app['slug'] . '/'); ?>"
                           data-assets-card
                           data-assets-search-text="<?= html_escape(strtolower($app['name'] . ' ' . $app['publisher'] . ' ' . strip_tags((string) $app['description']))); ?>">
                            <div class="assets-db-app-banner">
                                <?php if (!empty($app['banner_url'])): ?>
                                    <img src="<?= $website['cdn_url'].html_escape($app['banner_url']); ?>" alt="" loading="lazy">
                                <?php else: ?>
                                    <span class="assets-db-banner-fallback"><i class="fa-solid fa-gamepad" aria-hidden="true"></i></span>
                                <?php endif; ?>
                            </div>
                            <div class="assets-db-app-card-body">
                                <span class="assets-db-app-logo">
                                    <?php if (!empty($app['logo_url'])): ?>
                                        <img src="<?= $website['cdn_url'].html_escape($app['logo_url']); ?>" alt="<?= html_escape($app['name']); ?>" loading="lazy">
                                    <?php else: ?>
                                        <i class="fa-solid fa-gamepad" aria-hidden="true"></i>
                                    <?php endif; ?>
                                </span>
                                <div class="assets-db-app-card-copy">
                                    <h2><?= html_escape($app['name']); ?></h2>
                                    <span><?= html_escape($app['publisher']); ?></span>
                                </div>
                                <i class="fa-solid fa-arrow-up-right-from-square assets-db-card-arrow" aria-hidden="true"></i>
                                <p><?= html_escape(trim((string) $app['description']) !== '' ? $app['description'] : 'Browse the assets available for this app.'); ?></p>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
                <div class="assets-db-empty assets-db-empty-filter" data-assets-empty hidden>
                    <span><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i></span>
                    <h2>No apps found</h2>
                    <p>Try another app name or publisher.</p>
                </div>
            <?php else: ?>
                <div class="assets-db-empty">
                    <span><i class="fa-solid fa-box-open" aria-hidden="true"></i></span>
                    <h2>No apps yet</h2>
                    <p>Apps and their asset collections will appear here once they have been added.</p>
                </div>
            <?php endif; ?>
        </section>
    </main>

    <?php include APPPATH . 'views/frontend/include/footer.php'; ?>
    <?php include APPPATH . 'views/frontend/include/js.php'; ?>
</body>
</html>
