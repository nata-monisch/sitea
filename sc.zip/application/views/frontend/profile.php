<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <?php include APPPATH . 'views/frontend/include/header.php'; ?>
    <?php include APPPATH . 'views/frontend/include/css.php'; ?>
</head>
<body>
    <?php include APPPATH . 'views/frontend/include/menu.php'; ?>

    <main id="main-content">
        <section class="wrap profile-section" aria-labelledby="profileName">
            <div class="profile-banner">
                <?php if (!empty($banner_image_url)): ?>
                    <img src="<?= html_escape($website['cdn_url'].$banner_image_url); ?>" alt="<?= html_escape($user['display_name']); ?>" fetchpriority="high">
                <?php else: ?>
                    <div class="profile-banner-placeholder" aria-hidden="true"></div>
                <?php endif; ?>
            </div>

            <div class="profile-info">
                <div class="profile-info-row">
                    <div class="profile-avatar" aria-label="Foto profil <?= html_escape($user['display_name']); ?>">
                        <?php if (!empty($profile_image_url)): ?>
                            <img src="<?= html_escape($website['cdn_url'].$profile_image_url); ?>" alt="Foto profil <?= html_escape($user['display_name']); ?>">
                        <?php else: ?>
                            <span><?= html_escape($profile_initial); ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="profile-name">
                        <h1 id="profileName"><?= html_escape($user['display_name']); ?></h1>
                        <p class="username">@<?= html_escape($user['username']); ?></p>
                    </div>

                    <div class="profile-actions">
                        <a class="profile-action profile-action-primary" href="<?= !empty($contact_url) ? html_escape($contact_url) : '#about'; ?>" <?= !empty($contact_url) ? 'target="_blank" rel="noopener noreferrer"' : ''; ?>>
                            <i class="fa-solid fa-paper-plane" aria-hidden="true"></i>
                            <span>Hubungi</span>
                        </a>
                        <a class="profile-action" href="<?= base_url(); ?>">
                            <i class="fa-solid fa-house" aria-hidden="true"></i>
                            <span>Beranda</span>
                        </a>
                    </div>
                </div>

                <div class="profile-tabs" role="tablist" aria-label="Konten profile">
                    <button class="profile-tab is-active" id="tab-posts" type="button" role="tab" aria-selected="true" aria-controls="panel-posts" data-profile-tab="posts">
                        <i class="fa-regular fa-file-lines" aria-hidden="true"></i>
                        <span>Post</span>
                    </button>
                    <button class="profile-tab" id="tab-products" type="button" role="tab" aria-selected="false" aria-controls="panel-products" data-profile-tab="products" tabindex="-1">
                        <i class="fa-solid fa-box-open" aria-hidden="true"></i>
                        <span>Product</span>
                    </button>
                </div>
            </div>

            <div class="profile-content-grid">
                <aside class="profile-sidebar" id="about">
                    <section class="profile-info-card">
                        <div class="card-heading">
                            <span class="card-heading-icon"><i class="fa-regular fa-user" aria-hidden="true"></i></span>
                            <h2>About</h2>
                        </div>

                        <?php if (!empty($user['bio'])): ?>
                            <p class="profile-bio"><?= nl2br(html_escape($user['bio'])); ?></p>
                        <?php else: ?>
                            <p class="profile-bio profile-muted">Pengguna ini belum menambahkan bio.</p>
                        <?php endif; ?>
                    </section>

                    <section class="profile-info-card connection-card">
                        <div class="card-heading">
                            <span class="card-heading-icon"><i class="fa-solid fa-link" aria-hidden="true"></i></span>
                            <h2>Connection</h2>
                        </div>

                        <?php if (!empty($social_links)): ?>
                            <div class="profile-connections">
                                <?php foreach ($social_links as $link): ?>
                                    <a class="profile-connection" href="<?= html_escape($link['url']); ?>" target="_blank" rel="noopener noreferrer">
                                        <span class="profile-connection-icon"><i class="<?= html_escape($link['icon']); ?>" aria-hidden="true"></i></span>
                                        <span class="profile-connection-text">
                                            <b><?= html_escape($link['label']); ?></b>
                                            <small><?= html_escape($link['display']); ?></small>
                                        </span>
                                        <i class="fa-solid fa-arrow-up-right-from-square connection-arrow" aria-hidden="true"></i>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <p class="profile-empty-note">Belum ada social link yang ditambahkan.</p>
                        <?php endif; ?>
                    </section>
                </aside>

                <section class="profile-feed" aria-label="Konten pengguna">
                    <div class="profile-panel is-active" id="panel-posts" role="tabpanel" aria-labelledby="tab-posts" data-profile-panel="posts">
                        <div class="feed-heading">
                            <div>
                                <span class="section-kicker">USER CONTENT</span>
                                <h2>Latest Posts</h2>
                            </div>
                            <span class="feed-heading-icon"><i class="fa-regular fa-file-lines" aria-hidden="true"></i></span>
                        </div>
                        <div class="profile-empty-state">
                            <span class="empty-state-icon"><i class="fa-regular fa-folder-open" aria-hidden="true"></i></span>
                            <h3>Belum ada post</h3>
                            <p>Post yang dibuat oleh <?= html_escape($user['display_name']); ?> akan ditampilkan di sini.</p>
                        </div>
                    </div>

                    <div class="profile-panel" id="panel-products" role="tabpanel" aria-labelledby="tab-products" data-profile-panel="products" hidden>
                        <div class="feed-heading">
                            <div>
                                <span class="section-kicker">USER COLLECTION</span>
                                <h2>Products</h2>
                            </div>
                            <span class="feed-heading-icon"><i class="fa-solid fa-box-open" aria-hidden="true"></i></span>
                        </div>
                        <div class="profile-empty-state">
                            <span class="empty-state-icon"><i class="fa-solid fa-box-open" aria-hidden="true"></i></span>
                            <h3>Belum ada produk</h3>
                            <p>Produk milik <?= html_escape($user['display_name']); ?> akan ditampilkan di sini.</p>
                        </div>
                    </div>
                </section>
            </div>
        </section>
    </main>

    <?php include APPPATH . 'views/frontend/include/footer.php'; ?>
    <?php include APPPATH . 'views/frontend/include/js.php'; ?>
</body>
</html>
