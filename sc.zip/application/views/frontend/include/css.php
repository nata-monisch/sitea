<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= base_url('assets/fonts/fontawesome-pro/css/all.min.css'); ?>">
<link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>?v=<?= time();?>">
