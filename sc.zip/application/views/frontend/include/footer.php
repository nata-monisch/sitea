	<footer class="site-footer">
		<div class="wrap footer-main">
			<div class="footer-brand">
				<a class="brand" href="<?= base_url(); ?>">
					<?php if (!empty($website_logo_url)): ?>
                    <img class="brand-logo" src="<?= html_escape($website_logo_url); ?>" alt="<?= html_escape($website['name']); ?>">
                    <?php else: ?>
                    <span class="brand-mark"><?= html_escape(!empty($website_initial) ? $website_initial : 'N'); ?></span>
                    <?php endif; ?>
					<span class="brand-accent"><?= html_escape($website['name']);?></span>
				</a>
				<p><?= html_escape($website['description']);?></p>
				<?php if (!empty($website_social_links)): ?>
                <div class="socials" aria-label="Social media website">
                    <?php foreach ($website_social_links as $link): ?>
                        <a href="<?= html_escape($link['url']); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?= html_escape($link['label']); ?>">
                            <i class="<?= html_escape($link['icon']); ?>" aria-hidden="true"></i>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
			</div>
			<div class="footer-column">
				<b>Jelajahi</b>
				<a href="#topup">Top Up Game</a>
				<a href="#popular">Game Coins</a>
				<a href="#giftcards">Gift Cards</a>
			</div>
			<div class="footer-column">
				<b>Bantuan</b>
				<a href="#why">Pusat Bantuan</a>
				<a href="#faq">FAQ</a>
				<a href="#contact">Hubungi Kami</a>
			</div>
			<div class="footer-column">
				<b>Informasi</b>
				<a href="#terms">Syarat & Ketentuan</a>
				<a href="#privacy">Kebijakan Privasi</a>
				<a href="#refund">Kebijakan Refund</a>
			</div>
		</div>

		<div class="wrap footer-bottom">
			<span>Build with <i class="fa-solid fa-heart" style="color:#ff0000;"></i> by <a href="<?= base_url(); ?>" target="_blank" style="color:var(--foreground)"><b><?= html_escape($website['name']);?></b></a></span>
		</div>
	</footer>