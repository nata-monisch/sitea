<script src="<?= base_url('assets/js/script.js?v=1.0.0'); ?>?v=<?= time();?>" defer></script>
