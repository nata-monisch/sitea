<?php
$meta_title = isset($title) ? (string) $title : (isset($website['name']) ? (string) $website['name'] : '');
$meta_description = isset($description) ? (string) $description : '';
$meta_keywords = isset($keyword) ? (string) $keyword : '';
$canonical_url = !empty($canonical) ? $canonical : current_url();
$meta_image = !empty($thumbnail_url) ? $thumbnail_url : (isset($thumbnail) ? $thumbnail : '');
$meta_favicon = !empty($favicon_url) ? $favicon_url : (!empty($website['favicon']) ? base_url(ltrim($website['favicon'], '/')) : '');
$meta_theme_color = !empty($website['browser_color']) ? $website['browser_color'] : '#0b0911';
$meta_og_type = !empty($og_type) ? (string) $og_type : 'article';
?>
<meta content="width=device-width, initial-scale=1.0, user-scalable=1.0, minimum-scale=1.0, maximum-scale=5.0" name="viewport">
<meta content="text/html; charset=UTF-8" http-equiv="Content-Type">
<meta content="IE=Edge" http-equiv="X-UA-Compatible">

<!-- TITLE -->
<title><?= html_escape($meta_title); ?></title>
<meta content="<?= html_escape($meta_title); ?>" property="og:title">
<meta content="<?= html_escape($meta_title); ?>" property="og:image:alt">
<meta content="<?= html_escape($meta_title); ?>" name="twitter:title">
<meta content="<?= html_escape($meta_title); ?>" name="twitter:image:alt">
<meta content="<?= html_escape(isset($website['name']) ? $website['name'] : ''); ?>" property="og:site_name">

<!-- DESCRIPTION -->
<meta content="<?= html_escape($meta_description); ?>" name="description">
<meta content="<?= html_escape($meta_description); ?>" property="og:description">
<meta content="<?= html_escape($meta_description); ?>" name="twitter:description">

<!-- CANONICAL -->
<link href="<?= html_escape($canonical_url); ?>" rel="canonical">
<meta content="<?= html_escape($canonical_url); ?>" property="og:url">

<!-- THUMBNAIL -->
<?php if ($meta_image !== ''): ?>
<meta content="<?= html_escape($meta_image); ?>" property="og:image">
<meta content="<?= html_escape($meta_image); ?>" name="twitter:image">
<?php endif; ?>

<!-- KEYWORD -->
<meta content="<?= html_escape($meta_keywords); ?>" name="keywords">
<meta content="<?= html_escape($meta_keywords); ?>" property="article:tag">

<!-- TRACKING CODE -->
<?php if (!empty($website['google_verif'])): ?><meta content="<?= html_escape($website['google_verif']); ?>" name="google-site-verification"><?php endif; ?>
<?php if (!empty($website['bing_verif'])): ?><meta content="<?= html_escape($website['bing_verif']); ?>" name="msvalidate.01"><?php endif; ?>

<!-- FAVICON -->
<?php if ($meta_favicon !== ''): ?>
<link href="<?= html_escape($meta_favicon); ?>" rel="icon" type="image/x-icon">
<link href="<?= html_escape($meta_favicon); ?>" rel="apple-touch-icon">
<?php endif; ?>

<!-- THEME COLOR -->
<meta content="<?= html_escape($meta_theme_color); ?>" name="theme-color">
<meta content="<?= html_escape($meta_theme_color); ?>" name="msapplication-navbutton-color">
<meta content="<?= html_escape($meta_theme_color); ?>" name="apple-mobile-web-app-status-bar-style">
<meta content="yes" name="apple-mobile-web-app-capable">
<meta content="yes" name="mobile-web-app-capable">

<!-- OPEN GRAPH -->
<meta content="<?= html_escape($meta_og_type); ?>" property="og:type">
<meta content="id_ID" property="og:locale">
<meta content="en_US" property="og:locale:alternate">
<meta content="summary_large_image" name="twitter:card">
<link href="<?= html_escape(base_url()); ?>" rel="publisher">

<!-- ROBOTS INDEX -->
<meta content="all" name="robots">
<meta content="all" name="googlebot">
<meta content="all" name="Googlebot-Image">
<meta content="all" name="MSNBot">
<meta content="all" name="MSNBot-Media">
