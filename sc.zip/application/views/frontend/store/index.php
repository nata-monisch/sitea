<?php
 defined('BASEPATH') OR exit('No direct script access allowed');
 $items_json = array();
 foreach ($products as $product) {
     $items_json[] = array(
         '@type' => 'ListItem', 'position' => count($items_json) + 1,
         'url' => $product['detail_url'],
         'item' => array('@type' => 'Product', 'name' => $product['title'], 'image' => $product['cover_url'])
     );
 }
 $collection_schema = array('@context' => 'https://schema.org', '@type' => 'CollectionPage', 'name' => $title, 'description' => $description, 'url' => $canonical, 'mainEntity' => array('@type' => 'ItemList', 'itemListElement' => $items_json));
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <?php include APPPATH . 'views/frontend/include/header.php'; ?>
    <?php include APPPATH . 'views/frontend/include/css.php'; ?>
    <link rel="stylesheet" href="<?= base_url('assets/css/store.css?v=' . (is_file(FCPATH . 'assets/css/store.css') ? filemtime(FCPATH . 'assets/css/store.css') : '1')); ?>">
    <script type="application/ld+json"><?= json_encode($collection_schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?></script>
</head>
<body>
<?php include APPPATH . 'views/frontend/include/menu.php'; ?>
<main id="main-content" class="store-front-page">
    <section class="wrap store-front-wrap">
        <nav class="store-breadcrumb" aria-label="Breadcrumb"><a href="<?= base_url(); ?>">Home</a><i class="fa-solid fa-chevron-right"></i><?php if ($app): ?><a href="<?= site_url('store/'); ?>">Store</a><i class="fa-solid fa-chevron-right"></i><span aria-current="page"><?= html_escape($app['name']); ?></span><?php else: ?><span aria-current="page">Store</span><?php endif; ?></nav>

        <?php if ($app): ?>
            <section class="store-category-hero">
                <?php if (!empty($app['banner_url'])): ?><img class="store-category-banner" src="<?= html_escape($app['banner_url']); ?>" alt="" fetchpriority="high"><?php endif; ?>
                <div class="store-category-overlay"></div>
                <div class="store-category-content">
                    <?php if (!empty($app['logo_url'])): ?><img src="<?= html_escape($app['logo_url']); ?>" alt="<?= html_escape($app['name']); ?>" class="store-category-logo"><?php endif; ?>
                    <div><span class="store-eyebrow">GAME MARKETPLACE</span><h1>Jual Akun, Item & Joki <?= html_escape($app['name']); ?></h1><p>Temukan penawaran <?= html_escape($app['name']); ?> terbaru dengan informasi produk dan harga yang jelas.</p></div>
                </div>
            </section>
        <?php else: ?>
            <header class="store-page-heading"><span class="store-eyebrow"><i class="fa-solid fa-bag-shopping"></i> NTMN MARKETPLACE</span><h1>Jual Akun Game, Item & Joki</h1><p>Temukan akun game, item, dan jasa joki dari berbagai game. Pilih produk yang kamu cari dan hubungi penjual melalui WhatsApp.</p></header>
        <?php endif; ?>

        <div class="store-category-links" aria-label="Kategori game">
            <a class="<?= !$app ? 'active' : ''; ?>" href="<?= site_url('store/'); ?>">Semua Game</a>
            <?php foreach ($apps as $category): ?><a class="<?= $app && (int) $app['id'] === (int) $category['id'] ? 'active' : ''; ?>" href="<?= site_url('store/' . $category['slug'] . '/'); ?>"><?= html_escape($category['name']); ?> <small><?= (int) $category['product_count']; ?></small></a><?php endforeach; ?>
        </div>

        <form class="store-front-filters" method="get" action="<?= html_escape($base_listing_url); ?>">
            <label class="store-front-search"><i class="fa-solid fa-magnifying-glass"></i><input type="search" name="search" value="<?= html_escape($search); ?>" placeholder="Cari produk..." aria-label="Cari produk"></label>
            <select name="type" aria-label="Filter tipe produk"><option value="">Semua Tipe</option><?php foreach (array('Akun','Item','Joki') as $type): ?><option value="<?= $type; ?>" <?= $type_filter === $type ? 'selected' : ''; ?>><?= $type; ?></option><?php endforeach; ?></select>
            <button type="submit"><i class="fa-solid fa-filter"></i> Filter</button>
            <?php if ($search !== '' || $type_filter !== ''): ?><a href="<?= html_escape($base_listing_url); ?>">Reset</a><?php endif; ?>
        </form>

        <div class="store-list-heading"><div><span class="store-eyebrow">LATEST LISTINGS</span><h2><?= $app ? 'Produk ' . html_escape($app['name']) : 'Produk Terbaru'; ?></h2></div><span class="store-product-count"><?= (int) $total; ?> produk</span></div>

        <?php if (!empty($products)): ?>
            <div class="store-product-grid">
                <?php foreach ($products as $product): $is_discount = $product['price_discount'] !== null && (float) $product['price_discount'] > 0; $current_price = $is_discount ? (float) $product['price_discount'] : (float) $product['price']; ?>
                    <a class="store-product-card" href="<?= html_escape($product['detail_url']); ?>">
                        <span class="store-product-card-media">
                            <?php if (!empty($product['cover_url']) && preg_match('/\.mp4(?:\?|$)/i', $product['cover_url'])): ?><span class="store-video-cover"><i class="fa-solid fa-play"></i></span>
                            <?php elseif (!empty($product['cover_url'])): ?><img src="<?= html_escape($product['cover_url']); ?>" alt="<?= html_escape($product['title']); ?>" loading="lazy">
                            <?php else: ?><span class="store-no-image"><i class="fa-regular fa-image"></i></span><?php endif; ?>
                        </span>
                        <span class="store-product-card-content">
                            <span class="store-product-card-meta"><span><?= html_escape($product['app_name']); ?></span><b><?= html_escape($product['type']); ?></b></span>
                            <strong class="store-product-card-title"><?= html_escape($product['title']); ?></strong>
                            <span class="store-product-card-price"><?php if ($is_discount): ?><del>Rp <?= number_format((float) $product['price'], 0, ',', '.'); ?></del><?php endif; ?><b>Rp <?= number_format($current_price, 0, ',', '.'); ?></b></span>
                            <span class="store-product-card-seller"><i class="fa-regular fa-user"></i> <?= html_escape($product['seller_name']); ?></span>
                        </span>
                    </a>
                <?php endforeach; ?>
            </div>
            <?php if ($total_pages > 1): ?><nav class="store-pagination" aria-label="Pagination">
                <?php for ($n = 1; $n <= $total_pages; $n++): $params = array_filter(array('search' => $search, 'type' => $type_filter, 'page' => $n), function($v){ return $v !== '' && $v !== 0; }); ?>
                    <a class="<?= $n === $page ? 'active' : ''; ?>" href="<?= html_escape($base_listing_url . '?' . http_build_query($params)); ?>" <?= $n === $page ? 'aria-current="page"' : ''; ?>><?= $n; ?></a>
                <?php endfor; ?>
            </nav><?php endif; ?>
        <?php else: ?>
            <div class="store-empty-state"><span><i class="fa-solid fa-box-open"></i></span><h2>Belum ada produk</h2><p><?= $search !== '' || $type_filter !== '' ? 'Coba ubah kata kunci atau filter pencarian.' : 'Produk terbaru untuk kategori ini akan muncul di sini.'; ?></p></div>
        <?php endif; ?>
    </section>
</main>
<?php include APPPATH . 'views/frontend/include/footer.php'; ?>
<?php include APPPATH . 'views/frontend/include/js.php'; ?>
</body>
</html>
