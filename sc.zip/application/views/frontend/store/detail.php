<?php
 defined('BASEPATH') OR exit('No direct script access allowed');
 $product_url = site_url('store/' . $app['slug'] . '/' . $product['slug'] . '/');
 $images = $product['images_array'];
 $current_price = (float) $price_current;
 $discounted = $product['price_discount'] !== null && (float) $product['price_discount'] > 0;
 $schema_offer = array('@type'=>'Offer','url'=>$product_url,'priceCurrency'=>'IDR','price'=>number_format($current_price, 0, '.', ''),'availability'=>$product['status'] === 'Ready' ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock','seller'=>array('@type'=>'Person','name'=>$product['seller_name']));
 if ($product['type'] === 'Joki') {
     $schema = array('@context'=>'https://schema.org','@type'=>'Service','name'=>$product['title'],'description'=>$description,'image'=>array_values(array_filter(array_column($images, 'url'))),'serviceType'=>'Joki ' . $app['name'],'provider'=>array('@type'=>'Person','name'=>$product['seller_name']),'offers'=>$schema_offer);
 } else {
     $schema = array('@context'=>'https://schema.org','@type'=>'Product','name'=>$product['title'],'description'=>$description,'image'=>array_values(array_filter(array_column($images, 'url'))),'category'=>$app['name'] . ' ' . $product['type'],'brand'=>array('@type'=>'Brand','name'=>$app['name']),'sku'=>'NTMN-' . (int) $product['id'],'offers'=>$schema_offer);
 }
 $breadcrumb_schema = array('@context'=>'https://schema.org','@type'=>'BreadcrumbList','itemListElement'=>array(
    array('@type'=>'ListItem','position'=>1,'name'=>'Home','item'=>base_url()),
    array('@type'=>'ListItem','position'=>2,'name'=>'Store','item'=>site_url('store/')),
    array('@type'=>'ListItem','position'=>3,'name'=>$app['name'],'item'=>site_url('store/' . $app['slug'] . '/')),
    array('@type'=>'ListItem','position'=>4,'name'=>$product['title'],'item'=>$product_url)
 ));
 $spec_groups = array();
 foreach ($product['specifications_array'] as $spec) { $group = !empty($spec['category']) ? $spec['category'] : 'Other'; if (!isset($spec_groups[$group])) $spec_groups[$group] = array(); $spec_groups[$group][] = $spec; }
 $spec_tabs = array();
 $spec_tab_index = 0;
 foreach ($spec_groups as $group_name => $group_items) { $spec_tabs[] = array('id' => 'spec-' . $spec_tab_index++, 'name' => $group_name, 'items' => $group_items); }
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <?php include APPPATH . 'views/frontend/include/header.php'; ?>
    <?php include APPPATH . 'views/frontend/include/css.php'; ?>
    <link rel="stylesheet" href="<?= base_url('assets/css/store.css?v=' . (is_file(FCPATH . 'assets/css/store.css') ? filemtime(FCPATH . 'assets/css/store.css') : '1')); ?>">
    <script type="application/ld+json"><?= json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?></script>
    <script type="application/ld+json"><?= json_encode($breadcrumb_schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?></script>
</head>
<body>
<?php include APPPATH . 'views/frontend/include/menu.php'; ?>
<main id="main-content" class="store-front-page">
    <section class="wrap store-detail-wrap">
        <nav class="store-breadcrumb" aria-label="Breadcrumb"><a href="<?= base_url(); ?>">Home</a><i class="fa-solid fa-chevron-right"></i><a href="<?= site_url('store/'); ?>">Store</a><i class="fa-solid fa-chevron-right"></i><a href="<?= site_url('store/' . $app['slug'] . '/'); ?>"><?= html_escape($app['name']); ?></a><i class="fa-solid fa-chevron-right"></i><span><?= html_escape($product['title']); ?></span></nav>

        <div class="store-detail-layout">
            <div class="store-detail-main">
                
                <header class="store-detail-product-heading">
                    <h1><?= html_escape($product['title']); ?></h1>
                </header>
                
                <section class="store-detail-gallery" data-store-gallery aria-label="Galeri produk">
                    <?php if (!empty($images)): ?>
                        <div class="store-gallery-stage">
                            <?php foreach ($images as $index => $media): $is_video = isset($media['mime']) && strpos($media['mime'], 'video/') === 0; ?>
                                <div class="store-detail-media <?= $index === 0 ? 'is-active' : ''; ?>" data-gallery-slide="<?= (int) $index; ?>" <?= $index === 0 ? '' : 'hidden'; ?>>
                                    <?php if ($is_video): ?><video src="<?= html_escape($media['url']); ?>" controls preload="metadata" playsinline></video>
                                    <?php else: ?><img src="<?= html_escape($media['url']); ?>" alt="<?= html_escape($product['title']); ?> - media <?= $index + 1; ?>" <?= $index === 0 ? 'fetchpriority="high"' : 'loading="lazy"'; ?>><?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                            <?php if (count($images) > 1): ?>
                                <button class="store-gallery-nav prev" type="button" data-gallery-prev aria-label="Media sebelumnya"><i class="fa-solid fa-chevron-left"></i></button>
                                <button class="store-gallery-nav next" type="button" data-gallery-next aria-label="Media berikutnya"><i class="fa-solid fa-chevron-right"></i></button>
                                <span class="store-gallery-counter" data-gallery-counter>1 / <?= count($images); ?></span>
                            <?php endif; ?>
                        </div>
                        <?php if (count($images) > 1): ?><div class="store-gallery-thumbs" aria-label="Pilih media produk">
                            <?php foreach ($images as $index => $media): $is_video = isset($media['mime']) && strpos($media['mime'], 'video/') === 0; ?>
                                <button class="store-gallery-thumb <?= $index === 0 ? 'is-active' : ''; ?>" type="button" data-gallery-thumb="<?= (int) $index; ?>" aria-label="Tampilkan media <?= $index + 1; ?>" aria-pressed="<?= $index === 0 ? 'true' : 'false'; ?>">
                                    <?php if ($is_video): ?><span class="store-gallery-video-thumb"><i class="fa-solid fa-play"></i></span><?php else: ?><img src="<?= html_escape($media['url']); ?>" alt="" loading="lazy"><?php endif; ?>
                                </button>
                            <?php endforeach; ?>
                        </div><?php endif; ?>
                    <?php else: ?><div class="store-detail-no-media"><i class="fa-regular fa-image"></i><span>No product media</span></div><?php endif; ?>
                </section>
                
                <section class="store-detail-tabs card" data-store-tabs>
                    <div class="store-detail-tab-list" role="tablist" aria-label="Informasi produk">
                        <button class="store-detail-tab is-active" type="button" role="tab" aria-selected="true" data-store-tab="description">Description</button>
                        <?php if ($product['type'] === 'Akun'): foreach ($spec_tabs as $spec_tab): ?>
                            <button class="store-detail-tab" type="button" role="tab" aria-selected="false" data-store-tab="<?= html_escape($spec_tab['id']); ?>"><?= html_escape($spec_tab['name']); ?></button>
                        <?php endforeach; endif; ?>
                    </div>
                    <div class="store-detail-tab-panel" role="tabpanel" data-store-panel="description">
                        <h2 style="display:none">Deskripsi Produk</h2>
                        <?php if (trim((string) $product['description']) !== ''): ?><div class="store-description-copy"><?= nl2br(html_escape($product['description'])); ?></div><?php else: ?><p class="store-muted">Penjual belum menambahkan deskripsi produk.</p><?php endif; ?>
                    </div>
                    <?php if ($product['type'] === 'Akun'): foreach ($spec_tabs as $spec_tab): ?>
                        <div class="store-detail-tab-panel" role="tabpanel" data-store-panel="<?= html_escape($spec_tab['id']); ?>" hidden>
                            <span class="store-eyebrow" style="display:none">ACCOUNT SPECIFICATIONS</span>
                            <h2 style="display:none"><?= html_escape($spec_tab['name']); ?></h2>
                            <div class="store-spec-display-list">
                                <?php foreach ($spec_tab['items'] as $spec): ?><div class="store-spec-display-item">
                                    <?php if (!empty($spec['icon'])): ?><img src="<?= html_escape($spec['icon']); ?>" alt="" loading="lazy"><?php endif; ?>
                                    <span><strong><?= html_escape($spec['name']); ?></strong><?php if (!empty($spec['rarity'])): ?><small><?= html_escape($spec['rarity']); ?></small><?php endif; ?></span>
                                    <?php if (!empty($spec['value'])): ?><b><?= html_escape($spec['value']); ?></b><?php endif; ?>
                                </div><?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; endif; ?>
                </section>
            </div>

            <aside class="store-detail-sidebar">
                <div class="store-product-summary card">
                    <section class="store-seller-section" aria-labelledby="storeSellerHeading">
                        <a class="store-seller store-seller-profile-link" href="<?= site_url('@' . rawurlencode((string) $product['seller_username'])); ?>" aria-label="Lihat profil <?= html_escape($product['seller_name']); ?> (@<?= html_escape($product['seller_username']); ?>)">
                            <span class="store-seller-avatar">
                                <?php if (!empty($product['seller_profile_url'])): ?>
                                    <img src="<?= html_escape($product['seller_profile_url']); ?>" alt="Foto profil <?= html_escape($product['seller_name']); ?>" loading="lazy">
                                <?php else: ?>
                                    <span aria-hidden="true"><?= html_escape(function_exists('mb_substr') ? mb_strtoupper($product['seller_name'], 'UTF-8') : strtoupper(substr($product['seller_name'], 0, 1))); ?></span>
                                <?php endif; ?>
                            </span>
                            <span class="store-seller-identity"><strong><?= html_escape($product['seller_name']); ?></strong><small>@<?= html_escape($product['seller_username']); ?></small></span>
                        </a>
                    </section>
                    <div class="store-price-card-divider store-price-card-divider-seller"></div>
                    <div class="store-price-card-heading">
                        <div class="store-price-card-label">
                            <h2>Harga</h2>
                            <?php if ($discounted && (float) $product['price'] > 0): ?>
                                <span class="store-discount-badge">-<?= (int) round((1 - ($current_price / (float) $product['price'])) * 100); ?>%</span>
                            <?php endif; ?>
                        </div>
                        <div class="store-detail-price">
                            <strong>Rp <?= number_format($current_price, 0, ',', '.'); ?></strong>
                            <?php if ($discounted): ?><del>Rp <?= number_format((float) $product['price'], 0, ',', '.'); ?></del><small>Hemat Rp <?= number_format((float) $product['price'] - $current_price, 0, ',', '.'); ?></small><?php endif; ?>
                        </div>
                    </div>
                    <div class="store-price-card-divider"></div>
                    <dl class="store-price-details">
                        <div class="store-price-detail-row">
                            <dt>Produk</dt>
                            <dd><?= html_escape($product['title']); ?></dd>
                        </div>
                        <div class="store-price-detail-row">
                            <dt>Kategori</dt>
                            <dd><a href="<?= site_url('store/' . $app['slug'] . '/'); ?>"><?= html_escape($app['name']); ?></a></dd>
                        </div>
                        <div class="store-price-detail-row">
                            <dt>Type</dt>
                            <dd><?= html_escape($product['type']); ?></dd>
                        </div>
                        <div class="store-price-detail-row">
                            <dt>Status</dt>
                            <dd><span class="store-product-status-text <?= $product['status'] === 'Ready' ? 'ready' : 'sold'; ?>"><?= html_escape($product['status']); ?></span></dd>
                        </div>
                    </dl>
                    <div class="store-price-card-divider store-price-card-divider-bottom"></div>
                    <?php if ($product['status'] === 'Ready' && $whatsapp_url !== ''): ?><a class="store-buy-button" href="<?= html_escape($whatsapp_url); ?>" target="_blank" rel="nofollow noopener noreferrer"><i class="fa-brands fa-whatsapp"></i> Beli via WhatsApp</a>
                    <?php elseif ($product['status'] === 'Sold'): ?><button class="store-buy-button is-disabled" type="button" disabled><i class="fa-solid fa-circle-check"></i> Produk Terjual</button>
                    <?php else: ?><button class="store-buy-button is-disabled" type="button" disabled><i class="fa-brands fa-whatsapp"></i> Kontak penjual belum tersedia</button><?php endif; ?>
                    <p class="store-contact-note"><i class="fa-solid fa-shield-halved"></i> Pastikan membaca deskripsi dan menyepakati detail transaksi langsung dengan penjual sebelum melakukan pembayaran.</p>
                </div>
                <?php if (!empty($latest_products)): ?><section class="store-side-widget card"><h2>Produk Terbaru</h2><div class="store-latest-list">
                    <?php foreach ($latest_products as $latest): ?><a class="store-latest-item" href="<?= html_escape($latest['detail_url']); ?>">
                        <?php if (!empty($latest['cover_url'])): ?><img src="<?= html_escape($latest['cover_url']); ?>" alt="" loading="lazy"><?php else: ?><span class="store-latest-placeholder"><i class="fa-regular fa-image"></i></span><?php endif; ?>
                        <span><strong><?= html_escape($latest['title']); ?></strong><small><?= html_escape($latest['app_name']); ?></small><b>Rp <?= number_format((float) $latest['current_price'], 0, ',', '.'); ?></b></span>
                    </a><?php endforeach; ?>
                </div></section><?php endif; ?>
                <?php if (!empty($website_social_links)): ?><section class="store-side-widget card"><h2>Follow Us</h2><div class="store-follow-links">
                    <?php foreach ($website_social_links as $social): ?><a href="<?= html_escape($social['url']); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?= html_escape($social['label']); ?>"><i class="<?= html_escape($social['icon']); ?>"></i><span><?= html_escape($social['label']); ?></span></a><?php endforeach; ?>
                </div></section><?php endif; ?>
            </aside>
        </div>

        <?php if (!empty($related_products)): ?><section class="store-related-products"><div class="store-list-heading"><div><span class="store-eyebrow">MORE TO EXPLORE</span><h2>Produk Lainnya</h2></div><a href="<?= site_url('store/' . $app['slug'] . '/'); ?>">Lihat semua <i class="fa-solid fa-arrow-right"></i></a></div><div class="store-product-grid">
            <?php foreach ($related_products as $related): $related_cover = $related['cover_url']; $related_url = $related['detail_url']; $related_price = $related['current_price']; ?>
                <a class="store-product-card" href="<?= html_escape($related_url); ?>"><span class="store-product-card-media"><?php if ($related_cover): ?><img src="<?= html_escape($related_cover); ?>" alt="<?= html_escape($related['title']); ?>" loading="lazy"><?php else: ?><span class="store-no-image"><i class="fa-regular fa-image"></i></span><?php endif; ?><span class="store-card-status <?= $related['status'] === 'Ready' ? 'ready' : 'sold'; ?>"><?= html_escape($related['status']); ?></span></span><span class="store-product-card-content"><span class="store-product-card-meta"><span><?= html_escape($app['name']); ?></span><b><?= html_escape($related['type']); ?></b></span><strong class="store-product-card-title"><?= html_escape($related['title']); ?></strong><span class="store-product-card-price"><b>Rp <?= number_format((float) $related_price, 0, ',', '.'); ?></b></span></span></a>
            <?php endforeach; ?>
        </div></section><?php endif; ?>
    </section>
</main>
<?php include APPPATH . 'views/frontend/include/footer.php'; ?>
<?php include APPPATH . 'views/frontend/include/js.php'; ?>
<script src="<?= base_url('assets/js/store-detail.js?v=' . (is_file(FCPATH . 'assets/js/store-detail.js') ? filemtime(FCPATH . 'assets/js/store-detail.js') : '1')); ?>" defer></script>
</body>
</html>
