<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?= base_url('assets/backend/script.js?v=' . (is_file(FCPATH . 'assets/backend/script.js') ? filemtime(FCPATH . 'assets/backend/script.js') : '1')); ?>"></script>
