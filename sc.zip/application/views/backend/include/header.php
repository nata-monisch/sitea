<?php
$meta_image_url = !empty($thumbnail) ? (preg_match('~^https?://~i', $thumbnail) ? $thumbnail : base_url($thumbnail)) : ''; 
$meta_page_url = isset($page_url) ? $page_url : (rtrim(current_url(), '/') . '/');
$meta_site_name = $website['name'];
$favicon_url = !empty($website['favicon']) ? base_url($website['favicon']) : ''; 
?>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php if (!empty($website['browser_color'])): ?><meta name="theme-color" content="<?= html_escape($website['browser_color']); ?>"><?php endif; ?>
<title><?= html_escape($title); ?></title>
<meta name="description" content="<?= html_escape($description); ?>">
<?php if ($meta_site_name !== ''): ?><meta name="author" content="<?= html_escape($meta_site_name); ?>"><?php endif; ?>
<meta name="robots" content="noindex, nofollow">
<link rel="preconnect" href="https://cdnjs.cloudflare.com">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<meta property="og:title" content="<?= html_escape($title); ?>">
<?php if ($meta_site_name !== ''): ?><meta property="og:site_name" content="<?= html_escape($meta_site_name); ?>"><?php endif; ?>
<meta property="og:description" content="<?= html_escape($description); ?>">
<meta property="og:type" content="website">
<meta property="og:url" content="<?= html_escape($meta_page_url); ?>">
<?php if ($meta_image_url !== ''): ?><meta property="og:image" content="<?= html_escape($meta_image_url); ?>"><?php endif; ?>
<?php if ($favicon_url !== ''): ?><link rel="shortcut icon" type="image/x-icon" href="<?= html_escape($favicon_url); ?>">
<link rel="icon" type="image/x-icon" href="<?= html_escape($favicon_url); ?>">
<link rel="apple-touch-icon" href="<?= html_escape($favicon_url); ?>"><?php endif; ?>
