<?php
$avatar_url = !empty($user['profile']) ? $website['cdn_url'].$user['profile'] : ''; 
?>
<header class="topbar">
    <div class="top-left">
        <button class="icon-btn mobile-toggle" type="button" aria-label="Open navigation"><i class="fa-solid fa-bars"></i></button>
        <div class="crumb"><a href="<?= site_url('backend/'); ?>">Dashboard</a><span style="padding:0 7px;color:#625a6e">/</span><b><?= html_escape($crumb); ?></b></div>
    </div>
    <div class="top-actions">
        <div class="user-menu">
            <button class="icon-btn user-menu-toggle" type="button" aria-label="Open user menu" aria-expanded="false">
                <?php if ($avatar_url !== ''): ?><img class="user-menu-avatar" src="<?= html_escape($avatar_url); ?>" alt="Profile photo"><?php endif; ?>
            </button>
            <div class="user-dropdown" hidden>
                <div class="user-dropdown-head">
                    <?php if ($avatar_url !== ''): ?><img class="user-dropdown-avatar" src="<?= html_escape($avatar_url); ?>" alt="Profile photo"><?php endif; ?>
                    <span class="user-dropdown-identity"><strong><?= html_escape($user['display_name']); ?></strong><small>@<?= html_escape($user['username']); ?></small></span>
                </div>
                <a href="<?= site_url('backend/profile/'); ?>"><i class="fa-regular fa-user"></i><span>Profile</span></a>
                <a class="signout-link" href="<?= site_url('backend/logout/'); ?>"><i class="fa-solid fa-arrow-right-from-bracket"></i><span>Sign out</span></a>
            </div>
        </div>
    </div>
</header>
