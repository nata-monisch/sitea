<?php $brand_name = $website['name']; ?>
<aside class="sidebar">
    <a class="brand" href="<?= site_url('backend/'); ?>">
        <span class="brand-mark"><!-- <?= html_escape(substr($brand_name, 0, 1)); ?> --> <img src='<?= $website['cdn_url'].$website['logo']; ?>' style='width:35px'></span><span><?= html_escape($brand_name); ?></span>
    </a>
    <nav class="nav-group sidebar-nav" aria-label="Main navigation">
        <div class="nav-label nav-section-label">Overview</div>
        <a class="nav-link <?= $active_menu === 'dashboard' ? 'active' : ''; ?>" href="<?= site_url('backend/'); ?>">
            <i class="fa-solid fa-house"></i><span>Dashboard</span>
        </a>
        <div class="nav-label nav-section-label">Account</div>
        <a class="nav-link <?= $active_menu === 'profile' ? 'active' : ''; ?>" href="<?= site_url('backend/profile/'); ?>">
            <i class="fa-regular fa-user"></i><span>Edit Profile</span>
        </a>
        <?php $website_active = in_array($active_menu, array('web-general', 'web-appearance', 'web-social', 'web-storage'), TRUE); ?>
        <div class="nav-item has-children <?= $website_active ? 'is-current is-open' : ''; ?>">
            <button class="nav-link nav-parent <?= $website_active ? 'active' : ''; ?>" type="button" aria-expanded="<?= $website_active ? 'true' : 'false'; ?>" aria-controls="menu-website">
                <i class="fa-solid fa-globe"></i><span>Website Settings</span><i class="fa-solid fa-chevron-down nav-chevron"></i>
            </button>
            <div class="nav-submenu" id="menu-website" <?= $website_active ? '' : 'hidden'; ?>>
                <a class="nav-link nav-child <?= $active_menu === 'web-general' ? 'active' : ''; ?>" href="<?= site_url('backend/web-general/'); ?>"><i class="fa-solid fa-sliders"></i><span>General</span></a>
                <a class="nav-link nav-child <?= $active_menu === 'web-appearance' ? 'active' : ''; ?>" href="<?= site_url('backend/web-appearance/'); ?>"><i class="fa-regular fa-eye"></i><span>Appearance</span></a>
                <a class="nav-link nav-child <?= $active_menu === 'web-social' ? 'active' : ''; ?>" href="<?= site_url('backend/web-social/'); ?>"><i class="fa-solid fa-share-nodes"></i><span>Social Links</span></a>
                <a class="nav-link nav-child <?= $active_menu === 'web-storage' ? 'active' : ''; ?>" href="<?= site_url('backend/web-storage/'); ?>"><i class="fa-brands fa-github"></i><span>GitHub Storage</span></a>
            </div>
        </div>
        <div class="nav-label nav-section-label">Content</div>
        <a class="nav-link <?= $active_menu === 'asset-app' ? 'active' : ''; ?>" href="<?= site_url('backend/asset-app/'); ?>">
            <i class="fa-solid fa-gamepad"></i><span>Asset App</span>
        </a>
        <a class="nav-link <?= $active_menu === 'store' ? 'active' : ''; ?>" href="<?= site_url('backend/store/'); ?>">
            <i class="fa-solid fa-store"></i><span>Store</span>
        </a>
        <div class="nav-label nav-section-label">Session</div>
        <a class="nav-link signout-link" href="<?= site_url('backend/logout/'); ?>">
            <i class="fa-solid fa-arrow-right-from-bracket"></i><span>Sign out</span>
        </a>
    </nav>
</aside>
