<!DOCTYPE html>
<html lang="id">
<head>
    <?php include APPPATH . 'views/backend/include/header.php'; ?>
    <?php include APPPATH . 'views/backend/include/css.php'; ?>
</head>
<body>
    <?php include APPPATH . 'views/backend/include/menu.php'; ?>
    <div class="overlay"></div>
    <main class="main">
        <?php include APPPATH . 'views/backend/include/topbar.php'; ?>
        <section class="content profile-page-content">
            <div class="page-head"><div><h1>Edit Profile</h1><p><?= $description; ?></p></div></div>
            <?php if (!empty($flash_success)): ?><div class="backend-alert success" role="status"><i class="fa-solid fa-circle-check"></i><?= html_escape($flash_success); ?></div><?php endif; ?>
            <?php if (!empty($flash_error)): ?><div class="backend-alert error" role="alert"><i class="fa-solid fa-circle-exclamation"></i><?= html_escape($flash_error); ?></div><?php endif; ?>
            <?php if (!empty($form_errors)): ?><div class="backend-alert error" role="alert"><?= $form_errors; ?></div><?php endif; ?>

            <?php
            $profile_url = !empty($user['profile']) ? $website['cdn_url'].$user['profile'] : '';
            $banner_url = !empty($user['banner']) ? $website['cdn_url'].$user['banner'] : ''; 
            ?>
            <form class="profile-settings-form" method="post" enctype="multipart/form-data" action="<?= site_url('backend/profile/'); ?>">
                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                <div class="profile-settings-layout">
                    <aside class="card profile-sidebar-card">
                        <div class="profile-cover" id="profileCover"<?php if ($banner_url !== ''): ?> style="background-image: url('<?= html_escape($banner_url); ?>')"<?php endif; ?>>
                            <span class="profile-cover-decoration" aria-hidden="true"></span>
                            <?php if ($profile_url !== ''): ?><img class="profile-avatar" id="profileAvatarPreview" src="<?= html_escape($profile_url); ?>" alt="Profile photo"><?php else: ?><span class="profile-avatar profile-avatar-empty" id="profileAvatarPreview" aria-label="No profile photo"><i class="fa-regular fa-user"></i></span><?php endif; ?>
                        </div>
                        <div class="profile-sidebar-identity"><h2><?= html_escape($user['display_name']); ?></h2><p>@<?= html_escape($user['username']); ?></p></div>
                        <div class="profile-sidebar-divider"></div>
                        <nav class="tabs profile-tabs" role="tablist" aria-label="Profile settings">
                            <button class="tab active" type="button" role="tab" aria-selected="true" aria-controls="profile-general" id="tab-general" data-profile-tab="general"><i class="fa-regular fa-user"></i><span>General</span></button>
                            <button class="tab" type="button" role="tab" aria-selected="false" aria-controls="profile-image" id="tab-image" data-profile-tab="image"><i class="fa-regular fa-image"></i><span>Image</span></button>
                            <button class="tab" type="button" role="tab" aria-selected="false" aria-controls="profile-connection" id="tab-connection" data-profile-tab="connection"><i class="fa-solid fa-link"></i><span>Connection</span></button>
                            <button class="tab" type="button" role="tab" aria-selected="false" aria-controls="profile-password" id="tab-password" data-profile-tab="password"><i class="fa-solid fa-lock"></i><span>Password</span></button>
                        </nav>
                    </aside>

                    <div class="card profile-content-card">
                        <section class="profile-tab-panel active" id="profile-general" role="tabpanel" aria-labelledby="tab-general" data-profile-panel="general">
                            <div class="profile-panel-heading"><span class="profile-heading-icon"><i class="fa-regular fa-user"></i></span><div><h2>Profile information</h2><p>Keep your personal details up to date.</p></div></div>
                            <div class="form-grid">
                                <div class="form-group floating-field"><input class="control" id="display_name" name="display_name" value="<?= html_escape(set_value('display_name', $user['display_name'])); ?>" placeholder=" " maxlength="120" required><label for="display_name">Display Name</label></div>
                                <div class="form-group floating-field"><input class="control" id="username" name="username" value="<?= html_escape(set_value('username', $user['username'])); ?>" placeholder=" " maxlength="60" required><label for="username">Username</label></div>
                                <div class="form-group full floating-field"><input class="control" id="whatsapp" name="whatsapp" type="tel" value="<?= html_escape(set_value('whatsapp', $user['whatsapp'])); ?>" placeholder=" "><label for="whatsapp">WhatsApp</label></div>
                                <div class="form-group full floating-field profile-bio-field"><textarea class="control textarea" id="bio" name="bio" placeholder=" "><?= html_escape(set_value('bio', $user['bio'])); ?></textarea><label for="bio">Bio</label></div>
                            </div>
                        </section>

                        <section class="profile-tab-panel" id="profile-image" role="tabpanel" aria-labelledby="tab-image" data-profile-panel="image" hidden>
                            <div class="profile-panel-heading"><span class="profile-heading-icon"><i class="fa-regular fa-image"></i></span><div><h2>Profile images</h2><p>Update your profile photo and banner image.</p></div></div>
                            <div class="profile-image-grid">
                                <div class="profile-image-upload-card"><div class="profile-image-preview profile-photo-preview"><?php if ($profile_url !== ''): ?><img id="profileImagePreview" src="<?= html_escape($profile_url); ?>" alt="Profile photo preview"><?php else: ?><i class="fa-regular fa-user" id="profileImagePlaceholder"></i><?php endif; ?></div><div class="profile-image-copy"><strong>Profile photo</strong><small>PNG, JPG, atau WEBP. Max 5 MB.</small><label class="btn profile-file-button" for="profileImageInput"><i class="fa-solid fa-camera"></i>Change photo</label><input class="profile-file-input" id="profileImageInput" type="file" name="profile_image" accept="image/png,image/jpg,image/jpeg,image/webp"></div></div>
                                <div class="profile-image-upload-card"><div class="profile-image-preview profile-banner-preview" id="bannerImagePreview"<?php if ($banner_url !== ''): ?> style="background-image: url('<?= html_escape($banner_url); ?>')"<?php endif; ?>></div><div class="profile-image-copy"><strong>Profile banner</strong><small>PNG, JPG, atau WEBP. Max 5 MB.</small><label class="btn profile-file-button" for="bannerImageInput"><i class="fa-solid fa-image"></i>Change banner</label><input class="profile-file-input" id="bannerImageInput" type="file" name="banner_image" accept="image/png,image/jpg,image/jpeg,image/webp"></div></div>
                            </div>
                            <p class="form-hint profile-image-hint"><i class="fa-solid fa-circle-info"></i> The preview updates immediately. <b>Save Changes</b> to upload and save your images.</p>
                        </section>

                        <section class="profile-tab-panel" id="profile-connection" role="tabpanel" aria-labelledby="tab-connection" data-profile-panel="connection" hidden>
                            <div class="profile-panel-heading"><span class="profile-heading-icon"><i class="fa-solid fa-link"></i></span><div><h2>Social Links</h2><p>Add links where visitors can find and connect with you.</p></div></div>
                            <div class="form-grid">
                                <?php foreach (array('facebook' => 'Facebook', 'instagram' => 'Instagram', 'discord' => 'Discord invite', 'tiktok' => 'TikTok', 'youtube' => 'YouTube') as $field => $label): ?>
                                <div class="form-group floating-field"><input class="control" id="<?= $field; ?>" name="<?= $field; ?>" type="url" value="<?= html_escape(set_value($field, $user[$field])); ?>" placeholder="https://"><label for="<?= $field; ?>"><?= html_escape($label); ?></label></div>
                                <?php endforeach; ?>
                            </div>
                        </section>

                        <section class="profile-tab-panel" id="profile-password" role="tabpanel" aria-labelledby="tab-password" data-profile-panel="password" hidden>
                            <div class="profile-panel-heading"><span class="profile-heading-icon"><i class="fa-solid fa-lock"></i></span><div><h2>Security</h2><p>Use a strong password that you don't use elsewhere.</p></div></div>
                            <div class="form-grid">
                                <div class="form-group full floating-field"><input class="control" id="current_password" name="current_password" type="password" autocomplete="current-password" placeholder=""><label for="current_password">Current password</label></div>
                                <div class="form-group floating-field"><input class="control" id="new_password" name="new_password" type="password" autocomplete="new-password" placeholder=""><label for="new_password">New password</label></div>
                                <div class="form-group floating-field"><input class="control" id="confirm_password" name="confirm_password" type="password" autocomplete="new-password" placeholder=""><label for="confirm_password">Confirm new password</label></div>
                            </div>
                            <div class="security-note"><i class="fa-solid fa-shield-halved"></i><span>For better security, use at least 8 characters with a mix of letters, numbers and symbols.</span></div>
                        </section>

                        <div class="profile-form-actions"><button class="btn btn-primary" type="submit"><i class="fa-solid fa-check"></i>Save Changes</button></div>
                    </div>
                </div>
            </form>
        </section>
    </main>
    <?php include APPPATH . 'views/backend/include/js.php'; ?>
</body>
</html>
