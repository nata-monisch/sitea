<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$selected_app = !empty($selected_app) ? $selected_app : NULL;
$asset_filters = isset($asset_filters) ? $asset_filters : array('search' => '', 'category' => '', 'rarity' => '');
$asset_filter_options = isset($asset_filter_options) ? $asset_filter_options : array('categories' => array(), 'rarities' => array());
$asset_filter_query = !empty($asset_filter_query) ? $asset_filter_query : '';
$asset_post_action = !empty($asset_post_action) ? $asset_post_action : site_url('backend/asset-app/');
$asset_page = isset($asset_page) ? (int) $asset_page : 1;
$asset_total_pages = isset($asset_total_pages) ? (int) $asset_total_pages : 1;
$asset_total = isset($asset_total) ? (int) $asset_total : 0;
$asset_all_total = isset($asset_all_total) ? (int) $asset_all_total : 0;
$asset_slug = $selected_app && !empty($selected_app['slug']) ? $selected_app['slug'] : '';
$asset_query_suffix = $asset_filter_query !== '' ? '?' . $asset_filter_query : '';
$asset_base_path = $asset_slug !== '' ? 'backend/asset-app/' . $asset_slug . '/' : 'backend/asset-app/';
$asset_first_page_path = $asset_base_path . '1/';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <?php include APPPATH . 'views/backend/include/header.php'; ?>
    <?php include APPPATH . 'views/backend/include/css.php'; ?>
</head>
<body>
<?php include APPPATH . 'views/backend/include/menu.php'; ?>
<div class="overlay"></div>
<main class="main">
    <?php include APPPATH . 'views/backend/include/topbar.php'; ?>
    <section class="content asset-app-page">
        <div class="page-head">
            <div><h1>Asset App</h1><p>Manage your game applications and their visual assets.</p></div>
        </div>
        <?php if (!empty($flash_success)): ?><div class="backend-alert success" data-swal-toast="success" data-swal-message="<?= html_escape($flash_success); ?>" hidden></div><?php endif; ?>
        <?php if (!empty($flash_error)): ?><div class="backend-alert error" data-swal-toast="error" data-swal-message="<?= html_escape($flash_error); ?>" hidden></div><?php endif; ?>

        <div class="asset-app-toolbar">
            <div class="asset-app-select-wrap">
                <label class="sr-only" for="assetAppSelect">Select App</label>
                <select class="control" id="assetAppSelect" <?= empty($apps) ? 'disabled' : ''; ?>>
                    <?php if (empty($apps)): ?><option value="">No App Available</option><?php endif; ?>
                    <?php foreach ($apps as $app): ?>
                        <?php $app_option_slug = !empty($app['slug']) ? $app['slug'] : ''; ?>
                        <option value="<?= html_escape(site_url('backend/asset-app/' . $app_option_slug . '/1/')); ?>" <?= $selected_app && (int) $selected_app['id'] === (int) $app['id'] ? 'selected' : ''; ?>><?= html_escape($app['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button class="btn btn-primary" type="button" data-open-modal="createAppModal"><i class="fa-solid fa-plus"></i><span>Add App</span></button>
        </div>

        <?php if ($selected_app): ?>
        <div class="asset-app-summary card">
            <div class="asset-app-brand">
                <?php if (!empty($selected_app['logo'])): ?><img src="<?= html_escape($website['cdn_url'].$selected_app['logo']); ?>" alt="<?= html_escape($selected_app['name']); ?>"><?php else: ?><span><i class="fa-solid fa-gamepad"></i></span><?php endif; ?>
                <div><h2><?= html_escape($selected_app['name']); ?></h2><p><?= html_escape($selected_app['publisher']); ?> · <?= html_escape($selected_app['github_owner'].'/'.$selected_app['github_repository']); ?></p></div>
            </div>
            <div class="asset-app-summary-actions">
                <button class="btn btn-ghost" type="button" data-open-modal="editAppModal" data-app-name="<?= html_escape($selected_app['name']); ?>" data-app-description="<?= html_escape($selected_app['description']); ?>" data-app-publisher="<?= html_escape($selected_app['publisher']); ?>" data-app-logo="<?= html_escape(isset($selected_app['logo']) ? $selected_app['logo'] : ''); ?>" data-app-banner="<?= html_escape(isset($selected_app['banner']) ? $selected_app['banner'] : ''); ?>"><i class="fa-regular fa-pen-to-square"></i> Edit App</button>
                <a class="btn btn-ghost" href="https://github.com/<?= rawurlencode($selected_app['github_owner']); ?>/<?= rawurlencode($selected_app['github_repository']); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-github"></i> Repository</a>
                <form method="post" action="<?= html_escape($asset_post_action); ?>" data-swal-confirm data-swal-title="Hapus App?" data-swal-text="App dan seluruh data assets akan dihapus dari database. Repository GitHub tidak akan dihapus." data-swal-confirm-text="Ya, hapus App">
                    <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                    <input type="hidden" name="action" value="delete_app"><input type="hidden" name="app_id" value="<?= (int) $selected_app['id']; ?>">
                    <button class="btn btn-danger" type="submit" title="Delete App"><i class="fa-regular fa-trash-can"></i></button>
                </form>
            </div>
        </div>

        <div class="asset-list-toolbar">
            <form class="asset-filter-form" id="assetFilterForm" method="get" action="<?= html_escape($asset_filter_action); ?>" data-ajax-filter>
                <div class="asset-filter-controls">
                    <div class="asset-search">
                        <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
                        <input type="search" id="assetSearch" name="search" class="control" value="<?= html_escape($asset_filters['search']); ?>" placeholder="Search assets..." autocomplete="off">
                        <button class="asset-search-submit" type="submit" aria-label="Search assets"><i class="fa-solid fa-arrow-right"></i></button>
                    </div>

                    <div class="asset-searchable-select" data-searchable-select>
                        <input type="hidden" name="category" value="<?= html_escape($asset_filters['category']); ?>" data-select-value>
                        <button class="control asset-select-trigger" type="button" data-select-trigger aria-haspopup="listbox" aria-expanded="false">
                            <span data-select-label><?= $asset_filters['category'] !== '' ? html_escape($asset_filters['category']) : 'All Categories'; ?></span>
                            <i class="fa-solid fa-chevron-down" aria-hidden="true"></i>
                        </button>
                        <div class="asset-select-menu" data-select-menu hidden>
                            <label class="asset-select-search"><i class="fa-solid fa-magnifying-glass"></i><input type="search" placeholder="Search category..." autocomplete="off" data-select-search></label>
                            <div class="asset-select-options" role="listbox" aria-label="Categories">
                                <button type="button" role="option" aria-selected="<?= $asset_filters['category'] === '' ? 'true' : 'false'; ?>" data-select-option data-value="">All Categories</button>
                                <?php foreach ($asset_filter_options['categories'] as $category): ?>
                                    <button type="button" role="option" aria-selected="<?= $asset_filters['category'] === $category ? 'true' : 'false'; ?>" data-select-option data-value="<?= html_escape($category); ?>"><?= html_escape($category); ?></button>
                                <?php endforeach; ?>
                            </div>
                            <p class="asset-select-no-results" data-select-no-results hidden>No categories found.</p>
                        </div>
                    </div>

                    <label class="asset-native-select">
                        <span class="sr-only">Select rarity</span>
                        <select class="control" name="rarity" aria-label="Filter by rarity" >
                            <option value="">All Rarities</option>
                            <?php foreach ($asset_filter_options['rarities'] as $rarity): ?>
                                <option value="<?= html_escape($rarity); ?>" <?= $asset_filters['rarity'] === $rarity ? 'selected' : ''; ?>><?= html_escape($rarity); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <i class="fa-solid fa-chevron-down" aria-hidden="true"></i>
                    </label>
                </div>
            </form>
            <button class="btn btn-primary asset-add-button" type="button" data-open-modal="assetModal" data-asset-create><i class="fa-solid fa-plus"></i><span>Add Assets</span></button>
        </div>

        <div class="asset-result-meta" id="assetResultMeta">
            <span>Showing <strong><?= (int) $asset_from; ?>–<?= (int) $asset_to; ?></strong> of <strong><?= (int) $asset_total; ?></strong> assets</span>
            <?php if ($asset_filters['search'] !== '' || $asset_filters['category'] !== '' || $asset_filters['rarity'] !== ''): ?>
                <a href="<?= html_escape(site_url($asset_first_page_path)); ?>" data-clear-asset-filters>Clear filters</a>
            <?php endif; ?>
        </div>

        <div class="card table-card asset-table-card" id="assetTableContainer">
            <div class="table-scroll">
                <table class="data-table asset-data-table">
                    <thead><tr><th>Asset</th><th>Category</th><th>Rarity</th><th class="text-right">Actions</th></tr></thead>
                    <tbody id="assetTableBody">
                    <?php foreach ($assets as $asset_index => $asset): ?>
                    <tr data-asset-row>
                        <td><div class="asset-table-name">
                            <?php if (!empty($asset['icon'])): ?>
                                <?php if ($asset_offset + $asset_index < 20): ?>
                                    <img src="<?= html_escape($website['cdn_url'].$asset['icon']); ?>" alt="<?= html_escape($asset['name']); ?>">
                                <?php else: ?>
                                    <img class="lazy" data-src="<?= html_escape($website['cdn_url'].$asset['icon']); ?>" src="data:image/png;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=" alt="<?= html_escape($asset['name']); ?>">
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="asset-icon-empty"><i class="fa-regular fa-image"></i></span>
                            <?php endif; ?>
                            <strong><?= html_escape($asset['name']); ?></strong>
                        </div></td>
                        <td><?= $asset['category'] !== '' ? html_escape($asset['category']) : '<span class="muted">—</span>'; ?></td>
                        <td><?= $asset['rarity'] !== '' ? '<span class="rarity-tag">'.html_escape($asset['rarity']).'</span>' : '<span class="muted">—</span>'; ?></td>
                        <td><div class="table-actions">
                            <button class="icon-btn" type="button" title="Edit Asset" data-open-modal="assetModal" data-asset-edit data-id="<?= (int) $asset['id']; ?>" data-name="<?= html_escape($asset['name']); ?>" data-category="<?= html_escape($asset['category']); ?>" data-rarity="<?= html_escape($asset['rarity']); ?>" data-description="<?= html_escape($asset['description']); ?>" data-detail="<?= html_escape($asset['detail']); ?>"><i class="fa-regular fa-pen-to-square"></i></button>
                            <form method="post" action="<?= html_escape($asset_post_action); ?>" data-swal-confirm data-swal-title="Hapus Asset?" data-swal-text="Asset ini akan dihapus dari database dan file icon terkait akan dihapus dari repository." data-swal-confirm-text="Ya, hapus">
                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                                <input type="hidden" name="action" value="delete_asset"><input type="hidden" name="app_id" value="<?= (int) $selected_app['id']; ?>"><input type="hidden" name="asset_id" value="<?= (int) $asset['id']; ?>">
                                <button class="icon-btn danger-icon" type="submit" title="Delete Asset"><i class="fa-regular fa-trash-can"></i></button>
                            </form>
                        </div></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php if ($asset_total === 0 && $asset_all_total === 0): ?>
                <div class="asset-empty-state" id="assetEmptyState"><span><i class="fa-regular fa-folder-open"></i></span><strong>No assets yet</strong><p>Add your first asset to this app.</p></div>
            <?php elseif ($asset_total === 0): ?>
                <div class="asset-no-results">No assets match your filters. Try another keyword or clear the filters.</div>
            <?php endif; ?>
        </div>

        <?php if ($asset_total_pages > 1): ?>
            <nav class="asset-pagination" id="assetPagination" aria-label="Assets pagination">
                <?php if ($asset_page > 1): ?>
                    <?php $previous_path = $asset_base_path . ($asset_page - 1) . '/'; ?>
                    <a class="asset-page-link asset-page-arrow" href="<?= html_escape(site_url($previous_path) . $asset_query_suffix); ?>" aria-label="Previous page"><i class="fa-solid fa-chevron-left"></i></a>
                <?php else: ?>
                    <span class="asset-page-link asset-page-arrow is-disabled"><i class="fa-solid fa-chevron-left"></i></span>
                <?php endif; ?>

                <?php
                $pagination_start = max(1, $asset_page - 2);
                $pagination_end = min($asset_total_pages, $asset_page + 2);
                if ($pagination_start > 1): ?>
                    <a class="asset-page-link" href="<?= html_escape(site_url($asset_first_page_path) . $asset_query_suffix); ?>">1</a>
                    <?php if ($pagination_start > 2): ?><span class="asset-page-ellipsis">…</span><?php endif; ?>
                <?php endif; ?>
                <?php for ($page_number = $pagination_start; $page_number <= $pagination_end; $page_number++): ?>
                    <?php $number_path = $asset_base_path . $page_number . '/'; ?>
                    <a class="asset-page-link <?= $page_number === $asset_page ? 'is-active' : ''; ?>" href="<?= html_escape(site_url($number_path) . $asset_query_suffix); ?>" <?= $page_number === $asset_page ? 'aria-current="page"' : ''; ?>><?= $page_number; ?></a>
                <?php endfor; ?>
                <?php if ($pagination_end < $asset_total_pages): ?>
                    <?php if ($pagination_end < $asset_total_pages - 1): ?><span class="asset-page-ellipsis">…</span><?php endif; ?>
                    <?php $last_path = $asset_base_path . $asset_total_pages . '/'; ?>
                    <a class="asset-page-link" href="<?= html_escape(site_url($last_path) . $asset_query_suffix); ?>"><?= $asset_total_pages; ?></a>
                <?php endif; ?>

                <?php if ($asset_page < $asset_total_pages): ?>
                    <?php $next_path = $asset_base_path . ($asset_page + 1) . '/'; ?>
                    <a class="asset-page-link asset-page-arrow" href="<?= html_escape(site_url($next_path) . $asset_query_suffix); ?>" aria-label="Next page"><i class="fa-solid fa-chevron-right"></i></a>
                <?php else: ?>
                    <span class="asset-page-link asset-page-arrow is-disabled"><i class="fa-solid fa-chevron-right"></i></span>
                <?php endif; ?>
            </nav>
        <?php endif; ?>
        <?php else: ?>
        <div class="card asset-no-app"><span><i class="fa-solid fa-gamepad"></i></span><h2>No Game App Yet</h2><p>Create your first app to start managing its assets.</p><button class="btn btn-primary" type="button" data-open-modal="createAppModal"><i class="fa-solid fa-plus"></i>Create App</button></div>
        <?php endif; ?>
    </section>
</main>

<!-- Create App: three-step workflow -->
<div class="asset-modal-backdrop" id="createAppModal" aria-hidden="true">
    <section class="asset-modal asset-create-modal" role="dialog" aria-modal="true" aria-labelledby="createAppTitle">
        <div class="asset-modal-head"><div><span class="eyebrow">NEW APPLICATION</span><h2 id="createAppTitle">Create Game App</h2></div><button type="button" class="icon-btn" data-close-modal aria-label="Close"><i class="fa-solid fa-xmark"></i></button></div>
        <div class="asset-step-indicator"><span class="active" data-step-dot="1">1 <small>Details</small></span><i></i><span data-step-dot="2">2 <small>Repository</small></span><i></i><span data-step-dot="3">3 <small>Images</small></span></div>
        <form method="post" action="<?= site_url('backend/asset-app/'); ?>" enctype="multipart/form-data" id="createAppForm">
            <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
            <input type="hidden" name="action" value="create_app">
            <div class="asset-step-panel active" data-step-panel="1">
                <div class="form-group"><label for="newAppName">App Name <b>*</b></label><input class="control" id="newAppName" name="name" maxlength="120" required placeholder="e.g. Wuthering Waves"></div>
                <div class="form-group"><label for="newAppDescription">Description</label><textarea class="control textarea" id="newAppDescription" name="description" rows="3" placeholder="Describe this game app..."></textarea></div>
                <div class="form-group"><label for="newAppPublisher">Publisher <b>*</b></label><input class="control" id="newAppPublisher" name="publisher" maxlength="120" required placeholder="e.g. Kuro Games"></div>
                <div class="asset-modal-actions"><button type="button" class="btn btn-primary" data-next-step="2">Continue <i class="fa-solid fa-arrow-right"></i></button></div>
            </div>
            <div class="asset-step-panel" data-step-panel="2" hidden>
                <p class="asset-step-description">Choose a public repository for storing this app's images. One repository can only be assigned to one app.</p>
                <div class="repo-mode-options">
                    <label class="repo-mode-card"><input type="radio" name="repository_mode" value="new" checked><span><i class="fa-solid fa-folder-plus"></i><b>Create new repository</b><small>Use the app name as the repository name.</small></span></label>
                    <label class="repo-mode-card"><input type="radio" name="repository_mode" value="existing"><span><i class="fa-brands fa-github"></i><b>Use existing repository</b><small>Choose an unused public repository.</small></span></label>
                </div>
                <div class="form-group existing-repo-field" id="existingRepoField" hidden><label for="existingRepository">Available Repository</label><select class="control" name="existing_repository" id="existingRepository"><option value="">Select repository</option><?php foreach ($github_repositories as $repo): ?><option value="<?= html_escape($repo['full_name']); ?>"><?= html_escape($repo['full_name']); ?></option><?php endforeach; ?></select><?php if ($github_error): ?><small class="form-hint error-text"><?= html_escape($github_error); ?></small><?php endif; ?></div>
                <?php if ($github_error): ?><div class="backend-alert error"><i class="fa-solid fa-circle-exclamation"></i><?= html_escape($github_error); ?></div><?php endif; ?>
                <div class="asset-modal-actions"><button type="button" class="btn btn-ghost" data-prev-step="1">Back</button><button type="button" class="btn btn-primary" data-next-step="3">Continue <i class="fa-solid fa-arrow-right"></i></button></div>
            </div>
            <div class="asset-step-panel" data-step-panel="3" hidden>
                <p class="asset-step-description">Upload your app logo and banner. Files are stored in the selected GitHub repository.</p>
                <div class="form-group"><label for="newAppLogo">App Logo</label><input class="control file-control" id="newAppLogo" type="file" name="logo" accept=".png,.jpg,.jpeg,.webp,.svg,image/png,image/jpeg,image/webp,image/svg+xml"><small class="form-hint">PNG, JPG, JPEG, WEBP, SVG · Max 10 MB</small></div>
                <div class="form-group"><label for="newAppBanner">App Banner</label><input class="control file-control" id="newAppBanner" type="file" name="banner" accept=".png,.jpg,.jpeg,.webp,.svg,image/png,image/jpeg,image/webp,image/svg+xml"><small class="form-hint">PNG, JPG, JPEG, WEBP, SVG · Max 10 MB</small></div>
                <div class="asset-modal-actions"><button type="button" class="btn btn-ghost" data-prev-step="2">Back</button><button type="submit" class="btn btn-primary"><i class="fa-solid fa-check"></i>Create App</button></div>
            </div>
        </form>
    </section>
</div>

<!-- Edit App -->
<div class="asset-modal-backdrop" id="editAppModal" aria-hidden="true">
    <section class="asset-modal" role="dialog" aria-modal="true" aria-labelledby="editAppTitle">
        <div class="asset-modal-head"><div><span class="eyebrow">APPLICATION SETTINGS</span><h2 id="editAppTitle">Edit App</h2></div><button type="button" class="icon-btn" data-close-modal aria-label="Close"><i class="fa-solid fa-xmark"></i></button></div>
        <form method="post" action="<?= html_escape($asset_post_action); ?>" enctype="multipart/form-data" id="editAppForm">
            <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
            <input type="hidden" name="action" value="edit_app"><input type="hidden" name="app_id" value="<?= !empty($selected_app) ? (int)$selected_app['id'] : 0; ?>">
            <div class="form-group"><label for="editAppName">App Name <b>*</b></label><input class="control" id="editAppName" name="edit_name" maxlength="120" required></div>
            <div class="form-group"><label for="editAppPublisher">Publisher <b>*</b></label><input class="control" id="editAppPublisher" name="edit_publisher" maxlength="120" required></div>
            <div class="form-group"><label for="editAppDescription">Description</label><textarea class="control textarea" id="editAppDescription" name="edit_description" rows="4"></textarea></div>

            <div class="app-media-upload-grid">
                <div class="form-group app-media-upload-card">
                    <label for="editAppLogo">App Icon / Logo</label>
                    <div class="app-media-preview app-media-preview-logo">
                        <img id="editAppLogoPreview" alt="Current app icon" hidden>
                        <span id="editAppLogoPlaceholder"><i class="fa-solid fa-gamepad"></i></span>
                    </div>
                    <input class="control file-control" id="editAppLogo" type="file" name="edit_logo" accept=".png,.jpg,.jpeg,.webp,.svg,image/png,image/jpeg,image/webp,image/svg+xml">
                    <small class="form-hint">PNG, JPG, JPEG, WEBP, SVG · Max 10 MB. Kosongkan jika tidak ingin mengganti icon.</small>
                </div>
                <div class="form-group app-media-upload-card">
                    <label for="editAppBanner">App Banner</label>
                    <div class="app-media-preview app-media-preview-banner">
                        <img id="editAppBannerPreview" alt="Current app banner" hidden>
                        <span id="editAppBannerPlaceholder"><i class="fa-regular fa-image"></i></span>
                    </div>
                    <input class="control file-control" id="editAppBanner" type="file" name="edit_banner" accept=".png,.jpg,.jpeg,.webp,.svg,image/png,image/jpeg,image/webp,image/svg+xml">
                    <small class="form-hint">PNG, JPG, JPEG, WEBP, SVG · Max 10 MB. Kosongkan jika tidak ingin mengganti banner.</small>
                </div>
            </div>

            <p class="form-hint">Repository assignment is fixed after app creation. File baru akan disimpan ke repository GitHub App ini.</p>
            <div class="asset-modal-actions"><button type="button" class="btn btn-ghost" data-close-modal>Cancel</button><button type="submit" class="btn btn-primary"><i class="fa-solid fa-check"></i>Save Changes</button></div>
        </form>
    </section>
</div>

<!-- Add/Edit Asset -->
<div class="asset-modal-backdrop" id="assetModal" aria-hidden="true">
    <section class="asset-modal" role="dialog" aria-modal="true" aria-labelledby="assetModalTitle">
        <div class="asset-modal-head"><div><span class="eyebrow">APP CONTENT</span><h2 id="assetModalTitle">Add Asset</h2></div><button type="button" class="icon-btn" data-close-modal aria-label="Close"><i class="fa-solid fa-xmark"></i></button></div>
        <form method="post" action="<?= html_escape($asset_post_action); ?>" enctype="multipart/form-data">
            <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
            <input type="hidden" name="action" value="save_asset"><input type="hidden" name="app_id" value="<?= !empty($selected_app) ? (int)$selected_app['id'] : 0; ?>"><input type="hidden" name="asset_id" id="editAssetId" value="0">
            <div class="form-group"><label for="assetName">Name <b>*</b></label><input class="control" id="assetName" name="asset_name" maxlength="120" required placeholder="Asset name"></div>
            <div class="form-grid">
                <div class="form-group"><label for="assetCategory">Category</label><input class="control" id="assetCategory" name="category" maxlength="100" placeholder="Character, Weapon..."></div>
                <div class="form-group"><label for="assetRarity">Rarity</label><input class="control" id="assetRarity" name="rarity" maxlength="50" placeholder="5-Star, SSR..."></div>
            </div>
            <div class="form-group"><label for="assetIcon">Icon</label><input class="control file-control" id="assetIcon" type="file" name="asset_icon" accept=".png,.jpg,.jpeg,.webp,.svg,image/png,image/jpeg,image/webp,image/svg+xml"><small class="form-hint">PNG, JPG, JPEG, WEBP, SVG · Max 10 MB. Leave empty to keep the current icon.</small></div>
            <div class="form-group"><label for="assetDescription">Description</label><textarea class="control textarea" id="assetDescription" name="asset_description" rows="3"></textarea></div>
            <div class="form-group"><label for="assetDetail">Detail</label><textarea class="control textarea" id="assetDetail" name="detail" rows="5"></textarea></div>
            <div class="asset-modal-actions"><button type="button" class="btn btn-ghost" data-close-modal>Cancel</button><button type="submit" class="btn btn-primary"><i class="fa-solid fa-check"></i>Save Asset</button></div>
        </form>
    </section>
</div>
<?php include APPPATH . 'views/backend/include/js.php'; ?>
</body>
</html>
