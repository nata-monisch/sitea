<!DOCTYPE html>
<html lang="id">
<head>
    <?php include APPPATH . 'views/backend/include/header.php'; ?>
    <?php include APPPATH . 'views/backend/include/css.php'; ?>
</head>
<body>
    <?php include APPPATH . 'views/backend/include/menu.php'; ?>
    <div class="overlay"></div>
    <main class="main">
        <?php include APPPATH . 'views/backend/include/topbar.php'; ?>
        <section class="content">
            <div class="page-head">
                <div>
                    <h1>Dashboard</h1>
                    <p>Selamat datang kembali, <?= html_escape($user['display_name']); ?>. Berikut ringkasan konfigurasi website kamu.</p>
                </div>
                <div class="actions">
                    <a class="btn btn-primary" href="<?= site_url('backend/web-general/'); ?>"><i class="fa-solid fa-sliders"></i> Website Settings</a>
                </div>
            </div>

            <div class="grid stats-grid">
                <?php foreach ($metrics as $metric): ?>
                <article class="card stat-card">
                    <div class="stat-top"><?= html_escape($metric['label']); ?> <span class="stat-icon"><i class="fa-solid <?= html_escape($metric['icon']); ?>"></i></span></div>
                    <div class="stat-value dashboard-stat-value"><?= html_escape($metric['value']); ?></div>
                    <div class="stat-foot"><?= html_escape($metric['note']); ?></div>
                </article>
                <?php endforeach; ?>
            </div>

            <div class="grid dashboard-grid">
                <article class="card">
                    <div class="card-head">
                        <div><h2>Website overview</h2><p>Informasi dasar dari pengaturan website.</p></div>
                        <a class="btn btn-ghost" href="<?= site_url('backend/web-general/'); ?>">Edit <i class="fa-solid fa-arrow-up-right-from-square"></i></a>
                    </div>
                    <div class="card-body overview-body">
                        <div class="overview-brand">
                            <?php if (!empty($website['logo'])): ?><img src="<?= html_escape(preg_match('~^https?://~i', $website['logo']) ? $website['logo'] : base_url($website['logo'])); ?>" alt="Website logo"><?php endif; ?>
                            <div><strong><?= html_escape($website['name']); ?></strong><small>Website configuration</small></div>
                        </div>
                        <p class="overview-description"><?= nl2br(html_escape($website['description'])); ?></p>
                        <?php if (!empty($website['announcement'])): ?>
                            <div class="overview-announcement"><i class="fa-solid fa-bullhorn"></i><span><?= nl2br(html_escape($website['announcement'])); ?></span></div>
                        <?php endif; ?>
                        <div class="overview-meta"><span><i class="fa-solid fa-palette"></i> Browser color</span><code><?= html_escape($website['browser_color']); ?></code></div>
                    </div>
                </article>

                <article class="card">
                    <div class="card-head"><div><h2>Quick settings</h2><p>Kelola bagian penting website.</p></div></div>
                    <div class="card-body activity quick-settings-list">
                        <a class="activity-item" href="<?= site_url('backend/profile/'); ?>"><span class="activity-icon"><i class="fa-regular fa-user"></i></span><div><strong>Edit profile</strong><p>Ubah informasi akun dan keamanan.</p></div><i class="fa-solid fa-chevron-right quick-arrow"></i></a>
                        <a class="activity-item" href="<?= site_url('backend/web-general/'); ?>"><span class="activity-icon"><i class="fa-solid fa-globe"></i></span><div><strong>General settings</strong><p>Nama, deskripsi, verifikasi, dan announcement.</p></div><i class="fa-solid fa-chevron-right quick-arrow"></i></a>
                        <a class="activity-item" href="<?= site_url('backend/web-appearance/'); ?>"><span class="activity-icon"><i class="fa-solid fa-palette"></i></span><div><strong>Appearance</strong><p>Logo, favicon, banner, dan browser color.</p></div><i class="fa-solid fa-chevron-right quick-arrow"></i></a>
                        <a class="activity-item" href="<?= site_url('backend/web-social/'); ?>"><span class="activity-icon"><i class="fa-solid fa-share-nodes"></i></span><div><strong>Social links</strong><p>Atur tautan media sosial website.</p></div><i class="fa-solid fa-chevron-right quick-arrow"></i></a>
                    </div>
                </article>
            </div>
        </section>
    </main>
    <?php include APPPATH . 'views/backend/include/js.php'; ?>
</body>
</html>
