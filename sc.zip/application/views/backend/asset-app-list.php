<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$asset_slug = !empty($selected_app['slug']) ? $selected_app['slug'] : '';
$asset_base_path = 'backend/asset-app/' . $asset_slug . '/';
$asset_query_suffix = !empty($asset_filter_query) ? '?' . $asset_filter_query : '';
?>
<div class="asset-result-meta" id="assetResultMeta">
    <span>Showing <strong><?= (int) $asset_from; ?>–<?= (int) $asset_to; ?></strong> of <strong><?= (int) $asset_total; ?></strong> assets</span>
    <?php if (!empty($asset_filters['search']) || !empty($asset_filters['category']) || !empty($asset_filters['rarity'])): ?>
        <a href="<?= html_escape(site_url($asset_base_path . '1/')); ?>" data-clear-asset-filters>Clear filters</a>
    <?php endif; ?>
</div>

<div class="card table-card asset-table-card" id="assetTableContainer">
    <div class="table-scroll">
        <table class="data-table asset-data-table">
            <thead><tr><th>Asset</th><th>Category</th><th>Rarity</th><th class="text-right">Actions</th></tr></thead>
            <tbody id="assetTableBody">
            <?php foreach ($assets as $asset_index => $asset): ?>
                <tr data-asset-row>
                    <td><div class="asset-table-name">
                        <?php if (!empty($asset['icon'])): ?>
                            <?php if ($asset_offset + $asset_index < 20): ?>
                                <img src="<?= html_escape($asset['icon']); ?>" alt="<?= html_escape($asset['name']); ?>">
                            <?php else: ?>
                                <img class="lazy" data-src="<?= html_escape($asset['icon']); ?>" src="data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=" alt="<?= html_escape($asset['name']); ?>">
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="asset-icon-empty"><i class="fa-regular fa-image"></i></span>
                        <?php endif; ?>
                        <strong><?= html_escape($asset['name']); ?></strong>
                    </div></td>
                    <td><?= $asset['category'] !== '' ? html_escape($asset['category']) : '<span class="muted">—</span>'; ?></td>
                    <td><?= $asset['rarity'] !== '' ? '<span class="rarity-tag">'.html_escape($asset['rarity']).'</span>' : '<span class="muted">—</span>'; ?></td>
                    <td><div class="table-actions">
                        <button class="icon-btn" type="button" title="Edit Asset" data-open-modal="assetModal" data-asset-edit data-id="<?= (int) $asset['id']; ?>" data-name="<?= html_escape($asset['name']); ?>" data-category="<?= html_escape($asset['category']); ?>" data-rarity="<?= html_escape($asset['rarity']); ?>" data-description="<?= html_escape($asset['description']); ?>" data-detail="<?= html_escape($asset['detail']); ?>"><i class="fa-regular fa-pen-to-square"></i></button>
                        <form method="post" action="<?= html_escape($asset_post_action); ?>" data-swal-confirm data-swal-title="Hapus Assets <?= html_escape($asset['name']); ?>?" data-swal-text="Assets ini akan dihapus dari database dan file icon terkait akan dihapus dari repository." data-swal-confirm-text="Ya, hapus">
                            <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                            <input type="hidden" name="action" value="delete_asset"><input type="hidden" name="app_id" value="<?= (int) $selected_app['id']; ?>"><input type="hidden" name="asset_id" value="<?= (int) $asset['id']; ?>">
                            <button class="icon-btn danger-icon" type="submit" title="Delete Asset"><i class="fa-regular fa-trash-can"></i></button>
                        </form>
                    </div></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php if ($asset_total === 0 && $asset_all_total === 0): ?>
        <div class="asset-empty-state" id="assetEmptyState"><span><i class="fa-regular fa-folder-open"></i></span><strong>No assets yet</strong><p>Add your first asset to this app.</p></div>
    <?php elseif ($asset_total === 0): ?>
        <div class="asset-no-results">No assets match your filters. Try another keyword or clear the filters.</div>
    <?php endif; ?>
</div>

<?php if ($asset_total_pages > 1): ?>
<nav class="asset-pagination" id="assetPagination" aria-label="Assets pagination">
    <?php if ($asset_page > 1): ?>
        <a class="asset-page-link asset-page-arrow" href="<?= html_escape(site_url($asset_base_path . ($asset_page - 1) . '/') . $asset_query_suffix); ?>" aria-label="Previous page"><i class="fa-solid fa-chevron-left"></i></a>
    <?php else: ?>
        <span class="asset-page-link asset-page-arrow is-disabled"><i class="fa-solid fa-chevron-left"></i></span>
    <?php endif; ?>
    <?php
    $pagination_start = max(1, $asset_page - 2);
    $pagination_end = min($asset_total_pages, $asset_page + 2);
    if ($pagination_start > 1): ?>
        <a class="asset-page-link" href="<?= html_escape(site_url($asset_base_path . '1/') . $asset_query_suffix); ?>">1</a>
        <?php if ($pagination_start > 2): ?><span class="asset-page-ellipsis">…</span><?php endif; ?>
    <?php endif; ?>
    <?php for ($page_number = $pagination_start; $page_number <= $pagination_end; $page_number++): ?>
        <a class="asset-page-link <?= $page_number === $asset_page ? 'is-active' : ''; ?>" href="<?= html_escape(site_url($asset_base_path . $page_number . '/') . $asset_query_suffix); ?>" <?= $page_number === $asset_page ? 'aria-current="page"' : ''; ?>><?= $page_number; ?></a>
    <?php endfor; ?>
    <?php if ($pagination_end < $asset_total_pages): ?>
        <?php if ($pagination_end < $asset_total_pages - 1): ?><span class="asset-page-ellipsis">…</span><?php endif; ?>
        <a class="asset-page-link" href="<?= html_escape(site_url($asset_base_path . $asset_total_pages . '/') . $asset_query_suffix); ?>"><?= $asset_total_pages; ?></a>
    <?php endif; ?>
    <?php if ($asset_page < $asset_total_pages): ?>
        <a class="asset-page-link asset-page-arrow" href="<?= html_escape(site_url($asset_base_path . ($asset_page + 1) . '/') . $asset_query_suffix); ?>" aria-label="Next page"><i class="fa-solid fa-chevron-right"></i></a>
    <?php else: ?>
        <span class="asset-page-link asset-page-arrow is-disabled"><i class="fa-solid fa-chevron-right"></i></span>
    <?php endif; ?>
</nav>
<?php endif; ?>
