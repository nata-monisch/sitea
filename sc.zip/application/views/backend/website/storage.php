<!DOCTYPE html>
<html lang="id">
<head>
    <?php include APPPATH . 'views/backend/include/header.php'; ?>
    <?php include APPPATH . 'views/backend/include/css.php'; ?>
</head>
<body>
    <?php include APPPATH . 'views/backend/include/menu.php'; ?>
    <div class="overlay"></div>
    <main class="main">
        <?php include APPPATH . 'views/backend/include/topbar.php'; ?>
        <section class="content">
            <div class="page-head">
                <div>
                    <h1>GitHub Storage</h1>
                    <p>Hubungkan GitHub dan pilih repository publik untuk menyimpan asset website.</p>
                </div>
            </div>

            <?php if (!empty($flash_success)): ?><div class="backend-alert success" role="status"><i class="fa-solid fa-circle-check"></i><?= html_escape($flash_success); ?></div><?php endif; ?>
            <?php if (!empty($flash_error)): ?><div class="backend-alert error" role="alert"><i class="fa-solid fa-circle-exclamation"></i><?= html_escape($flash_error); ?></div><?php endif; ?>
            <?php if (!empty($form_errors)): ?><div class="backend-alert error" role="alert"><?= $form_errors; ?></div><?php endif; ?>

            <?php
                $github_connected = !empty($website['github_token']) && !empty($website['github_account']);
                $current_repository = (!empty($website['github_owner']) && !empty($website['github_repository'])) ? $website['github_owner'] . '/' . $website['github_repository'] : '';
            ?>
            <div class="storage-layout">
                <div class="card storage-card">
                    <div class="storage-card-heading">
                        <span class="storage-icon"><i class="fa-brands fa-github"></i></span>
                        <div>
                            <h2>GitHub account</h2>
                            <p>Gunakan Fine-grained Personal Access Token untuk memberi akses kepada website.</p>
                        </div>
                    </div>

                    <?php if ($github_connected): ?>
                        <div class="storage-connection connected">
                            <span class="storage-status-icon"><i class="fa-solid fa-check"></i></span>
                            <div class="storage-connection-copy">
                                <strong>Connected</strong>
                                <span>@<?= html_escape($website['github_account']); ?></span>
                            </div>
                            <span class="storage-status-pill">Active</span>
                        </div>
                    <?php else: ?>
                        <div class="storage-connection disconnected">
                            <span class="storage-status-icon"><i class="fa-solid fa-link-slash"></i></span>
                            <div class="storage-connection-copy">
                                <strong>Not connected</strong>
                                <span>Hubungkan akun GitHub untuk mengaktifkan upload asset.</span>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($github_connection_error)): ?>
                        <div class="backend-alert error storage-inline-alert" role="alert"><i class="fa-solid fa-circle-exclamation"></i><?= html_escape($github_connection_error); ?></div>
                    <?php endif; ?>

                    <form class="storage-form" method="post" action="<?= site_url('backend/web-storage/'); ?>" autocomplete="off">
                        <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                        <div class="storage-field">
                            <label for="github_pat">GitHub Personal Access Token</label>
                            <input class="control" id="github_pat" name="github_pat" type="password" autocomplete="new-password" placeholder="<?= $github_connected ? 'Kosongkan jika tidak ingin mengganti token' : 'github_pat_...'; ?>">
                            <small>Token dienkripsi sebelum disimpan. Token yang tersimpan tidak ditampilkan kembali.</small>
                        </div>

                        <div class="storage-field">
                            <label for="github_repository">Repository asset</label>
                            <select class="control" id="github_repository" name="github_repository">
                                <option value="">-- Pilih repository publik --</option>
                                <?php foreach ($github_repositories as $repository): ?>
                                    <option value="<?= html_escape($repository['full_name']); ?>" data-default-branch="<?= html_escape($repository['default_branch']); ?>" <?= $current_repository === $repository['full_name'] ? 'selected' : ''; ?>><?= html_escape($repository['full_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <small>Repository harus Public agar gambar dapat diakses pengunjung melalui URL GitHub langsung.</small>
                        </div>

                        <div class="storage-field storage-branch-field">
                            <label for="github_branch">Branch</label>
                            <input class="control" id="github_branch" name="github_branch" value="<?= html_escape($website['github_branch']); ?>" placeholder="Branch repository" maxlength="100">
                        </div>

                        <?php if ($current_repository): ?>
                            <div class="storage-selected-repo">
                                <i class="fa-solid fa-code-branch"></i>
                                <span>Repository aktif</span>
                                <strong><?= html_escape($current_repository); ?></strong>
                            </div>
                        <?php endif; ?>

                        <div class="storage-security-note">
                            <i class="fa-solid fa-shield-halved"></i>
                            <p>Gunakan Fine-grained PAT dengan <strong>Contents: Read and write</strong> dan <strong>Metadata: Read-only</strong>. Akses token hanya digunakan oleh server.</p>
                        </div>

                        <div class="storage-actions">
                            <button class="btn-primary" type="submit" name="github_action" value="connect"><i class="fa-brands fa-github"></i><?= $github_connected ? 'Save GitHub Settings' : 'Connect GitHub'; ?></button>
                            <?php if ($github_connected): ?>
                                <button class="btn storage-disconnect" type="submit" name="github_action" value="disconnect" formnovalidate data-swal-confirm data-swal-title="Putuskan koneksi GitHub?" data-swal-text="File yang sudah tersimpan di repository tidak akan dihapus." data-swal-confirm-text="Ya, putuskan" ><i class="fa-solid fa-link-slash"></i>Disconnect</button>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>

                <aside class="storage-side-card">
                    <div class="storage-side-icon"><i class="fa-solid fa-circle-info"></i></div>
                    <h3>About GitHub Storage</h3>
                    <p>GitHub digunakan sebagai tempat penyimpanan file gambar. Asset publik menggunakan URL raw GitHub langsung tanpa perantara CDN.</p>
                    <ul>
                        <li><i class="fa-solid fa-check"></i> Repository harus berstatus Public.</li>
                        <li><i class="fa-solid fa-check"></i> File website disimpan pada folder asset yang sudah ditentukan.</li>
                        <li><i class="fa-solid fa-check"></i> PAT tidak pernah dikirim ke browser.</li>
                    </ul>
                    <a href="https://github.com/settings/personal-access-tokens" target="_blank" rel="noopener noreferrer">Manage GitHub tokens <i class="fa-solid fa-arrow-up-right-from-square"></i></a>
                </aside>
            </div>
        </section>
    </main>
    <script>
    (function () {
        var repository = document.getElementById('github_repository');
        var branch = document.getElementById('github_branch');
        if (!repository || !branch) return;
        repository.addEventListener('change', function () {
            var option = repository.options[repository.selectedIndex];
            var defaultBranch = option ? option.getAttribute('data-default-branch') : '';
            if (defaultBranch) branch.value = defaultBranch;
        });
    }());
    </script>
    <?php include APPPATH . 'views/backend/include/js.php'; ?>
</body>
</html>
