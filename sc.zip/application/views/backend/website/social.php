<!DOCTYPE html>
<html lang="id">
<head>
    <?php include APPPATH . 'views/backend/include/header.php'; ?>
    <?php include APPPATH . 'views/backend/include/css.php'; ?>
</head>
<body>
    <?php include APPPATH . 'views/backend/include/menu.php'; ?>
    <div class="overlay"></div>
    <main class="main">
        <?php include APPPATH . 'views/backend/include/topbar.php'; ?>
        <section class="content">
            <div class="page-head"><div><h1>Website Settings - Social Links</h1><p><?= $description; ?></p></div></div>
            <?php if (!empty($flash_success)): ?><div class="backend-alert success" role="status"><i class="fa-solid fa-circle-check"></i><?= html_escape($flash_success); ?></div><?php endif; ?>
            <?php if (!empty($flash_error)): ?><div class="backend-alert error" role="alert"><i class="fa-solid fa-circle-exclamation"></i><?= html_escape($flash_error); ?></div><?php endif; ?>
            <?php if (!empty($form_errors)): ?><div class="backend-alert error" role="alert"><?= $form_errors; ?></div><?php endif; ?>
            <form class="profile-settings-form website-settings-form" method="post" action="<?= site_url('backend/web-social/'); ?>">
                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                <div class="card profile-content-card website-settings-card">
                    <div class="profile-panel-heading"><span class="profile-heading-icon"><i class="fa-solid fa-link"></i></span><div><h2>Social Links</h2><p>Enter full URL including https://</p></div></div>
                    <div class="form-grid">
                        <div class="form-group floating-field"><input class="control" id="facebook" name="facebook" type="url" value="<?= html_escape(set_value('facebook', $website['facebook'])); ?>" placeholder="https://facebook.com/username"><label for="facebook"><i class="fa-brands fa-facebook"></i> Facebook</label></div>
                        <div class="form-group floating-field"><input class="control" id="instagram" name="instagram" type="url" value="<?= html_escape(set_value('instagram', $website['instagram'])); ?>" placeholder="https://instagram.com/username"><label for="instagram"><i class="fa-brands fa-instagram"></i> Instagram</label></div>
                        <div class="form-group floating-field"><input class="control" id="discord" name="discord" type="url" value="<?= html_escape(set_value('discord', $website['discord'])); ?>" placeholder="https://discord.gg/invite"><label for="discord"><i class="fa-brands fa-discord"></i> Discord invite</label></div>
                        <div class="form-group floating-field"><input class="control" id="tiktok" name="tiktok" type="url" value="<?= html_escape(set_value('tiktok', $website['tiktok'])); ?>" placeholder="https://tiktok.com/@username"><label for="tiktok"><i class="fa-brands fa-tiktok"></i> TikTok</label></div>
                        <div class="form-group floating-field"><input class="control" id="youtube" name="youtube" type="url" value="<?= html_escape(set_value('youtube', $website['youtube'])); ?>" placeholder="https://youtube.com/@channel"><label for="youtube"><i class="fa-brands fa-youtube"></i> YouTube</label></div>
                    </div>
                    <div class="profile-form-actions"><button class="btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Save Changes</button></div>
                </div>
            </form>
        </section>
    </main>
    <?php include APPPATH . 'views/backend/include/js.php'; ?>
</body>
</html>
