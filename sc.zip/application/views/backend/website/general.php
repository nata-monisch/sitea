<!DOCTYPE html>
<html lang="id">
<head>
    <?php include APPPATH . 'views/backend/include/header.php'; ?>
    <?php include APPPATH . 'views/backend/include/css.php'; ?>
</head>
<body>
    <?php include APPPATH . 'views/backend/include/menu.php'; ?>
    <div class="overlay"></div>
    <main class="main">
        <?php include APPPATH . 'views/backend/include/topbar.php'; ?>
        <section class="content">
            <div class="page-head"><div><h1>Website Settings - General</h1><p><?= $description;?></p></div></div>
            <?php if (!empty($flash_success)): ?><div class="backend-alert success" role="status"><i class="fa-solid fa-circle-check"></i><?= html_escape($flash_success); ?></div><?php endif; ?>
            <?php if (!empty($flash_error)): ?><div class="backend-alert error" role="alert"><i class="fa-solid fa-circle-exclamation"></i><?= html_escape($flash_error); ?></div><?php endif; ?>
            <?php if (!empty($form_errors)): ?><div class="backend-alert error" role="alert"><?= $form_errors; ?></div><?php endif; ?>

            <form class="profile-settings-form website-settings-form" method="post" action="<?= site_url('backend/web-general/'); ?>">
                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                <div class="card profile-content-card website-settings-card">
                    <div class="profile-panel-heading"><span class="profile-heading-icon"><i class="fa-solid fa-globe"></i></span><div><h2>General information</h2><p>Manage the basic information and verification for your website.</p></div></div>
                    <div class="form-grid profile-general-grid">
                        <div class="form-group floating-field">
                            <input class="control" id="name" name="name" value="<?= html_escape(set_value('name', $website['name'])); ?>" required>
                            <label for="name">Name</label>
                        </div>
                        <div class="form-group floating-field">
                            <input class="control" id="cdn_url" name="cdn_url" type="text" value="<?= set_value('cdn_url', $website['cdn_url']); ?>">
                            <label for="cdn_url">CDN Endpoint</label>
                        </div>
                        <div class="form-group full floating-field">
                            <textarea class="control textarea website-textarea" id="description" name="description"><?= set_value('description', $website['description']); ?></textarea>
                            <label for="description">Description</label>
                        </div>
                        <div class="form-group floating-field">
                            <input class="control" id="google_verif" name="google_verif" value="<?= html_escape(set_value('google_verif', $website['google_verif'])); ?>">
                            <label for="google_verif">Google Verification</label>
                        </div>
                        <div class="form-group floating-field">
                            <input class="control" id="bing_verif" name="bing_verif" value="<?= html_escape(set_value('bing_verif', $website['bing_verif'])); ?>">
                            <label for="bing_verif">Bing Verification</label>
                        </div>
                        <div class="form-group full floating-field">
                            <textarea class="control textarea website-textarea" id="announcement" name="announcement"><?= set_value('announcement', $website['announcement']); ?></textarea>
                            <label for="announcement">Announcement</label>
                        </div>
                    </div>
                    <div class="profile-form-actions"><button class="btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Save Changes</button></div>
                </div>
            </form>

        </section>
    </main>
    <?php include APPPATH . 'views/backend/include/js.php'; ?>
</body>
</html>
