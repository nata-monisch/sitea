<!DOCTYPE html>
<html lang="id">
<head>
    <?php include APPPATH . 'views/backend/include/header.php'; ?>
    <?php include APPPATH . 'views/backend/include/css.php'; ?>
</head>
<body>
    <?php include APPPATH . 'views/backend/include/menu.php'; ?>
    <div class="overlay"></div>
    <main class="main">
        <?php include APPPATH . 'views/backend/include/topbar.php'; ?>
        <section class="content">
            <div class="page-head"><div><h1>Website Settings - Appearance</h1><p><?= $description;?></p></div></div>
            <?php if (!empty($flash_success)): ?><div class="backend-alert success" role="status"><i class="fa-solid fa-circle-check"></i><?= html_escape($flash_success); ?></div><?php endif; ?>
            <?php if (!empty($flash_error)): ?><div class="backend-alert error" role="alert"><i class="fa-solid fa-circle-exclamation"></i><?= html_escape($flash_error); ?></div><?php endif; ?>
            <?php if (!empty($form_errors)): ?><div class="backend-alert error" role="alert"><?= $form_errors; ?></div><?php endif; ?>
            <?php
            $favicon_url = !empty($website['favicon']) ? base_url($website['favicon']) : '';
            $logo_url = !empty($website['logo']) ? $website['cdn_url'].$website['logo'] : '';
            $banner_url = !empty($website['banner']) ? $website['cdn_url'].$website['banner'] : ''; 
            ?>
            <form class="profile-settings-form website-settings-form" method="post" enctype="multipart/form-data" action="<?= site_url('backend/web-appearance/'); ?>">
                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                <div class="card profile-content-card website-settings-card">
                    <div class="profile-panel-heading"><span class="profile-heading-icon"><i class="fa-solid fa-palette"></i></span><div><h2>Website appearance</h2><p>Customize the images and browser theme color of your website.</p></div></div>
                    <div class="profile-image-grid website-image-grid">
                        <div class="profile-image-upload-card">
                            <div class="profile-image-preview website-asset-preview website-icon-preview"><?php if ($favicon_url !== ''): ?><img id="faviconPreview" src="<?= html_escape($favicon_url); ?>" alt="Favicon preview"><?php else: ?><i class="fa-solid fa-image" id="faviconPlaceholder"></i><?php endif; ?></div>
                            <div class="profile-image-copy"><strong>Favicon</strong><small>Extension must be <b>.ico</b> & max 2 MB.</small><label class="btn profile-file-button" for="faviconInput"><i class="fa-solid fa-upload"></i>Choose favicon</label><input class="profile-file-input" id="faviconInput" type="file" name="favicon" accept=".ico,image/x-icon,image/vnd.microsoft.icon" data-image-preview="faviconPreview" data-placeholder="faviconPlaceholder"></div>
                        </div>
                        <div class="profile-image-upload-card">
                            <div class="profile-image-preview website-asset-preview website-logo-preview"><?php if ($logo_url !== ''): ?><img id="logoPreview" src="<?= html_escape($logo_url); ?>" alt="Logo preview"><?php else: ?><i class="fa-solid fa-image" id="logoPlaceholder"></i><?php endif; ?></div>
                            <div class="profile-image-copy"><strong>Logo</strong><small>PNG, JPG or WEBP & max 5 MB.</small><label class="btn profile-file-button" for="logoInput"><i class="fa-solid fa-upload"></i>Choose logo</label><input class="profile-file-input" id="logoInput" type="file" name="logo" accept="image/png,image/jpeg,image/webp" data-image-preview="logoPreview" data-placeholder="logoPlaceholder"></div>
                        </div>
                        <div class="profile-image-upload-card website-banner-card">
                            <div class="profile-image-preview profile-banner-preview website-banner-preview" id="bannerPreview"<?php if ($banner_url !== ''): ?> style="background-image: url('<?= html_escape($banner_url); ?>')"<?php endif; ?>></div>
                            <div class="profile-image-copy"><strong>Banner</strong><small>PNG, JPG or WEBP & max 8 MB.</small><label class="btn profile-file-button" for="bannerInput"><i class="fa-solid fa-upload"></i>Choose banner</label><input class="profile-file-input" id="bannerInput" type="file" name="banner" accept="image/png,image/jpeg,image/webp" data-background-preview="bannerPreview"></div>
                        </div>
                    </div>
                    <div class="form-grid website-theme-field">
                        <div class="form-group floating-field"><input class="control" id="browser_theme_color" name="browser_color" type="text" value="<?= html_escape(set_value('browser_color', $website['browser_color'])); ?>" placeholder=" " pattern="^#[0-9A-Fa-f]{6}$" required><label for="browser_theme_color">Theme color browser (Hex Code)</label></div>
                        <div class="website-color-preview-wrap"><span>Preview</span><?php if (!empty($website['browser_color'])): ?><input type="color" id="browserThemePicker" value="<?= html_escape($website['browser_color']); ?>" aria-label="Choose browser theme color"><span id="browserThemeValue"><?= html_escape(strtolower($website['browser_color'])); ?></span><?php else: ?><span>Belum ada warna tersimpan</span><?php endif; ?></div>
                    </div>
                    <p class="form-hint profile-image-hint"><i class="fa-solid fa-circle-info"></i> Image previews update immediately after selecting a file.</p>
                    <div class="profile-form-actions"><button class="btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Save Changes</button></div>
                </div>
            </form>
        </section>
    </main>
    <?php include APPPATH . 'views/backend/include/js.php'; ?>
</body>
</html>
