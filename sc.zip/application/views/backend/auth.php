<!DOCTYPE html>
<html lang="id">
<head>
    <?php include APPPATH . 'views/backend/include/header.php'; ?>
    <?php include APPPATH . 'views/backend/include/css.php'; ?>
    <style>.reference-login-visual {background:#17134d url('<?= $website["cdn_url"].base_url("assets/backend/login-bg.jpg");?>') center/cover no-repeat}</style>
</head>
<body class="reference-login-body">
    <main class="reference-login">
        <section class="reference-login-visual" aria-label="Welcome"></section>
        <section class="reference-login-panel" aria-label="Sign in form">
            <div class="reference-login-content">
                <div class="login-main-logo">
                    <?php if (!empty($website['logo'])): ?><img src="<?= $website['cdn_url'].$website['logo']; ?>" alt="<?= html_escape($website['name']); ?> logo"><?php endif; ?>
                </div>
                <div class="reference-form-heading">
                    <h2>Welcome back</h2>
                    <p><?= $description; ?></p>
                </div>
                <?php if (!empty($error)): ?><div class="reference-login-error" role="alert"><?= html_escape($error); ?></div><?php endif; ?>
                <?php if (!empty($form_errors)): ?><div class="reference-login-error" role="alert"><?= $form_errors; ?></div><?php endif; ?>
                <form class="reference-login-form" method="post" action="<?= site_url('auth/'); ?>">
                    <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                    <label class="reference-login-field">
                        <i class="fa-regular fa-user" aria-hidden="true"></i>
                        <span class="sr-only">Username</span>
                        <input type="text" name="identity" value="<?= html_escape(set_value('identity')); ?>" placeholder="Username" autocomplete="username" required autofocus>
                    </label>
                    <label class="reference-login-field reference-password-field">
                        <i class="fa-solid fa-lock" aria-hidden="true"></i>
                        <span class="sr-only">Password</span>
                        <input id="loginPassword" type="password" name="password" placeholder="Password" autocomplete="current-password" required>
                        <button class="reference-password-toggle" type="button" aria-label="Show password" aria-pressed="false"><i class="fa-regular fa-eye-slash"></i></button>
                    </label>
                    <button class="login-btn" type="submit"><span>Login</span></button>
                </form>
            </div>
        </section>
    </main>
    <script>
    (() => {
        const toggle = document.querySelector('.reference-password-toggle');
        const password = document.getElementById('loginPassword');
        if (!toggle || !password) return;
        toggle.addEventListener('click', () => {
            const visible = password.type === 'password';
            password.type = visible ? 'text' : 'password';
            toggle.setAttribute('aria-pressed', String(visible));
            toggle.setAttribute('aria-label', visible ? 'Hide password' : 'Show password');
            toggle.innerHTML = visible ? '<i class="fa-regular fa-eye"></i>' : '<i class="fa-regular fa-eye-slash"></i>';
        });
    })();
    </script>
</body>
</html>
