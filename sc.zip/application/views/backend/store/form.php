<?php
 defined('BASEPATH') OR exit('No direct script access allowed');
 $product = !empty($product) ? $product : array();
 $posted = !empty($posted) ? $posted : array();
 $value = function($key, $default = '') use ($posted, $product) {
     if (array_key_exists($key, $posted)) return is_array($posted[$key]) ? '' : $posted[$key];
     return isset($product[$key]) ? $product[$key] : $default;
 };
 $initial_specs = isset($posted['specifications_json']) ? $posted['specifications_json'] : json_encode(isset($product['specifications_array']) ? $product['specifications_array'] : array(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
 $existing_images = isset($product['images_array']) ? $product['images_array'] : array();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <?php include APPPATH . 'views/backend/include/header.php'; ?>
    <?php include APPPATH . 'views/backend/include/css.php'; ?>
    <link rel="stylesheet" href="<?= base_url('assets/backend/store.css?v=' . (is_file(FCPATH . 'assets/backend/store.css') ? filemtime(FCPATH . 'assets/backend/store.css') : '1')); ?>">
</head>
<body>
<?php include APPPATH . 'views/backend/include/menu.php'; ?>
<div class="overlay"></div>
<main class="main">
    <?php include APPPATH . 'views/backend/include/topbar.php'; ?>
    <section class="content store-admin-page">
        <div class="page-head"><div><h1><?= !empty($product) ? 'Edit Product' : 'Create Product'; ?></h1><p>Prepare your game account, item, or service listing.</p></div><a class="btn btn-ghost" href="<?= site_url('backend/store/'); ?>"><i class="fa-solid fa-arrow-left"></i> Back to Store</a></div>
        <?php if (!empty($flash_success)): ?><div class="backend-alert success" data-swal-toast="success" data-swal-message="<?= html_escape($flash_success); ?>" hidden></div><?php endif; ?>
        <?php if (!empty($flash_error)): ?><div class="backend-alert error" data-swal-toast="error" data-swal-message="<?= html_escape($flash_error); ?>" hidden></div><?php endif; ?>
        <?php if (!empty($form_errors)): ?><div class="backend-alert error" data-swal-toast="error" data-swal-message="<?= html_escape($form_errors); ?>" hidden></div><?php endif; ?>
        <?php if (empty($storage_ready)): ?><div class="store-storage-warning"><i class="fa-solid fa-triangle-exclamation"></i><span>GitHub Storage belum siap: <?= html_escape($storage_error); ?>. Hubungkan dan pilih repository di <a href="<?= site_url('backend/web-storage/'); ?>">Website Settings → GitHub Storage</a>.</span></div><?php endif; ?>

        <form class="store-product-form" method="post" action="<?= html_escape($form_action); ?>" enctype="multipart/form-data" data-store-product-form data-assets-url="<?= html_escape($asset_options_url); ?>" data-initial-specs='<?= html_escape($initial_specs); ?>'>
            <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
            <input type="hidden" name="specifications_json" value="<?= html_escape($initial_specs); ?>" data-specifications-json>
            <div class="store-product-layout">
                <div class="store-product-main">
                    <div class="card store-form-card">
                        <div class="store-form-section-title"><span class="store-form-icon"><i class="fa-solid fa-pen-to-square"></i></span><div><h2>Product Information</h2><p>Write a clear title and explain what the buyer will receive.</p></div></div>
                        <label class="store-field"><span>Title <b>*</b></span><input class="control" type="text" name="title" maxlength="255" required value="<?= html_escape($value('title')); ?>" placeholder="Contoh: Starter Carlotta" data-product-title></label>
                        <label class="store-field"><span>Slug / URL</span><input class="control" type="text" name="slug" maxlength="255" value="<?= html_escape($value('slug')); ?>" placeholder="starter-carlotta" data-product-slug><small>Otomatis dibuat dari title. Bisa kamu sesuaikan.</small></label>
                        <label class="store-field"><span>Description</span><textarea class="control store-description" name="description" rows="10" placeholder="Jelaskan detail produk, syarat trade, cara pengerjaan, dan informasi penting lainnya."><?= html_escape($value('description')); ?></textarea><small>Gunakan baris baru atau daftar untuk memudahkan pembeli membaca informasi produk.</small></label>
                        <label class="store-field"><span>SEO Keywords</span><input class="control" type="text" name="keyword" maxlength="500" value="<?= html_escape($value('keyword')); ?>" placeholder="jual akun carlotta, starter account wuthering waves"><small>Pisahkan keyword dengan koma. Hindari mengulang keyword secara berlebihan.</small></label>
                    </div>

                    <div class="card store-form-card">
                        <div class="store-form-section-title"><span class="store-form-icon"><i class="fa-solid fa-images"></i></span><div><h2>Upload Photos & Videos</h2><p>Drag and drop your media files, or click to browse.</p></div></div>
                        <label class="store-upload-dropzone" data-upload-dropzone>
                            <input type="file" name="images[]" accept=".png,.jpg,.jpeg,.webp,.svg,.gif,.mp4,image/png,image/jpeg,image/webp,image/svg+xml,image/gif,video/mp4" multiple data-media-input>
                            <span class="store-upload-cloud"><i class="fa-solid fa-cloud-arrow-up"></i></span>
                            <strong>Drop media files here or <u>browse</u></strong>
                            <small>PNG, JPG, JPEG, WEBP, SVG, GIF, MP4 · Max 10 MB per file · Up to 20 files</small>
                        </label>
                        <?php if (!empty($existing_images)): ?><div class="store-media-heading"><strong>Existing media</strong><span>Select the remove option to delete a file when saving.</span></div><div class="store-media-grid">
                            <?php foreach ($existing_images as $media): $is_video = isset($media['mime']) && strpos($media['mime'], 'video/') === 0; ?>
                                <label class="store-media-item is-existing"><input type="checkbox" name="remove_images[]" value="<?= html_escape($media['path']); ?>"><span class="store-media-remove"><i class="fa-solid fa-xmark"></i></span>
                                    <?php if ($is_video): ?><video src="<?= html_escape($media['url']); ?>" muted preload="metadata"></video><?php else: ?><img src="<?= html_escape($media['url']); ?>" alt="<?= html_escape(isset($media['name']) ? $media['name'] : 'Product image'); ?>" loading="lazy"><?php endif; ?>
                                    <small><?= html_escape(isset($media['name']) ? $media['name'] : basename($media['path'])); ?></small>
                                </label>
                            <?php endforeach; ?>
                        </div><?php endif; ?>
                        <div class="store-media-grid" data-new-media-preview></div>
                        <div class="store-upload-footer"><span><i class="fa-regular fa-circle-info"></i> Use clear images that show the actual product.</span><strong data-media-count><?= count($existing_images); ?>/20 files</strong></div>
                    </div>

                    <div class="card store-form-card" data-account-spec-section hidden>
                        <div class="store-form-section-title"><span class="store-form-icon"><i class="fa-solid fa-list-check"></i></span><div><h2>Account Specifications</h2><p>Select assets from the App Asset Database and enter their value or quantity.</p></div></div>
                        <div class="store-spec-groups" data-spec-groups><div class="store-spec-loading">Choose an App to load its Asset Database categories.</div></div>
                    </div>
                </div>

                <aside class="store-product-sidebar">
                    <div class="card store-form-card store-publish-card">
                        <div class="store-form-section-title"><span class="store-form-icon"><i class="fa-solid fa-paper-plane"></i></span><div><h2>Publish</h2><p>Set visibility and pricing.</p></div></div>
                        <label class="store-field"><span>Category / App <b>*</b></span><select class="control" name="app_id" required data-app-select><option value="">Select App</option><?php foreach ($apps as $app): ?><option value="<?= (int) $app['id']; ?>" <?= (int) $value('app_id', isset($product['app_id']) ? $product['app_id'] : 0) === (int) $app['id'] ? 'selected' : ''; ?>><?= html_escape($app['name']); ?> — <?= html_escape($app['publisher']); ?></option><?php endforeach; ?></select></label>
                        <label class="store-field"><span>Type <b>*</b></span><select class="control" name="type" required data-product-type><option value="Akun" <?= $value('type', 'Akun') === 'Akun' ? 'selected' : ''; ?>>Akun</option><option value="Item" <?= $value('type') === 'Item' ? 'selected' : ''; ?>>Item</option><option value="Joki" <?= $value('type') === 'Joki' ? 'selected' : ''; ?>>Joki</option></select></label>
                        <label class="store-field"><span>Status</span><select class="control" name="status"><option value="Ready" <?= $value('status', 'Ready') === 'Ready' ? 'selected' : ''; ?>>Ready</option><option value="Sold" <?= $value('status') === 'Sold' ? 'selected' : ''; ?>>Sold</option></select></label>
                        <label class="store-field"><span>Price (Rp) <b>*</b></span><input class="control" type="number" name="price" min="0" step="1" required value="<?= html_escape($value('price')); ?>" placeholder="90000"></label>
                        <label class="store-field"><span>Discount Price (Rp)</span><input class="control" type="number" name="price_discount" min="0" step="1" value="<?= html_escape($value('price_discount')); ?>" placeholder="80000"><small>Opsional. Harus lebih kecil dari harga normal.</small></label>
                        <button class="btn btn-primary store-publish-button" type="submit"><i class="fa-solid fa-cloud-arrow-up"></i> <?= !empty($product) ? 'Save Changes' : 'Create Product'; ?></button>
                    </div>
                    <div class="store-publish-note"><i class="fa-solid fa-circle-info"></i><span>Tombol beli pada halaman produk akan membuka WhatsApp yang tersimpan di Edit Profile akun pembuat produk.</span></div>
                </aside>
            </div>
        </form>
    </section>
</main>
<?php include APPPATH . 'views/backend/include/js.php'; ?>
<script src="<?= base_url('assets/backend/store.js?v=' . (is_file(FCPATH . 'assets/backend/store.js') ? filemtime(FCPATH . 'assets/backend/store.js') : '1')); ?>" defer></script>
</body>
</html>
