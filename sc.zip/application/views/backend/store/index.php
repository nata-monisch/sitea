<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <?php include APPPATH . 'views/backend/include/header.php'; ?>
    <?php include APPPATH . 'views/backend/include/css.php'; ?>
    <link rel="stylesheet" href="<?= base_url('assets/backend/store.css?v=' . (is_file(FCPATH . 'assets/backend/store.css') ? filemtime(FCPATH . 'assets/backend/store.css') : '1')); ?>">
</head>
<body>
<?php include APPPATH . 'views/backend/include/menu.php'; ?>
<div class="overlay"></div>
<main class="main">
    <?php include APPPATH . 'views/backend/include/topbar.php'; ?>
    <section class="content store-admin-page">
        <div class="page-head store-admin-heading">
            <div><h1>Store</h1><p>Manage your game accounts, items, and game services.</p></div>
            <a class="btn btn-primary" href="<?= site_url('backend/store/create/'); ?>"><i class="fa-solid fa-plus"></i> Add Product</a>
        </div>

        <?php if (!empty($flash_success)): ?><div class="backend-alert success" data-swal-toast="success" data-swal-message="<?= html_escape($flash_success); ?>" hidden></div><?php endif; ?>
        <?php if (!empty($flash_error)): ?><div class="backend-alert error" data-swal-toast="error" data-swal-message="<?= html_escape($flash_error); ?>" hidden></div><?php endif; ?>

        <form class="store-admin-filters card" method="get" action="<?= site_url('backend/store/'); ?>">
            <label class="store-filter-search"><i class="fa-solid fa-magnifying-glass"></i><input type="search" name="search" value="<?= html_escape($filters['search']); ?>" placeholder="Search product title..."></label>
            <select class="control" name="app_id"><option value="0">All Categories</option><?php foreach ($apps as $app): ?><option value="<?= (int) $app['id']; ?>" <?= (int) $filters['app_id'] === (int) $app['id'] ? 'selected' : ''; ?>><?= html_escape($app['name']); ?></option><?php endforeach; ?></select>
            <select class="control" name="type"><option value="">All Types</option><?php foreach (array('Akun','Item','Joki') as $type): ?><option value="<?= $type; ?>" <?= $filters['type'] === $type ? 'selected' : ''; ?>><?= $type; ?></option><?php endforeach; ?></select>
            <select class="control" name="status"><option value="">All Statuses</option><?php foreach (array('Ready','Sold') as $status): ?><option value="<?= $status; ?>" <?= $filters['status'] === $status ? 'selected' : ''; ?>><?= $status; ?></option><?php endforeach; ?></select>
            <button class="btn btn-primary" type="submit">Filter</button>
            <a class="btn btn-ghost" href="<?= site_url('backend/store/'); ?>">Reset</a>
        </form>

        <div class="store-admin-results"><span>Showing <strong><?= (int) $from; ?>–<?= (int) $to; ?></strong> of <strong><?= (int) $total; ?></strong> products</span></div>

        <div class="card store-admin-table-card">
            <div class="table-scroll">
                <table class="data-table store-admin-table">
                    <thead><tr><th>Product</th><th>Category</th><th>Type</th><th>Price</th><th>Status</th><th>Created</th><th class="text-right">Actions</th></tr></thead>
                    <tbody>
                    <?php foreach ($products as $product): $cover = !empty($product['images_array'][0]['url']) ? $product['images_array'][0]['url'] : ''; ?>
                        <tr>
                            <td><div class="store-admin-product">
                                <?php if ($cover && preg_match('/\.mp4(?:\?|$)/i', $cover)): ?><span class="store-admin-product-media"><i class="fa-solid fa-video"></i></span>
                                <?php elseif ($cover): ?><img src="<?= html_escape($cover); ?>" alt="" loading="lazy">
                                <?php else: ?><span class="store-admin-product-media"><i class="fa-regular fa-image"></i></span><?php endif; ?>
                                <span><strong><?= html_escape($product['title']); ?></strong><small><?= html_escape($product['slug']); ?></small></span>
                            </div></td>
                            <td><?= html_escape($product['app_name']); ?></td>
                            <td><span class="store-type-pill"><?= html_escape($product['type']); ?></span></td>
                            <td><strong>Rp <?= number_format((float) (($product['price_discount'] !== null && (float) $product['price_discount'] > 0) ? $product['price_discount'] : $product['price']), 0, ',', '.'); ?></strong><?php if ($product['price_discount'] !== null && (float) $product['price_discount'] > 0): ?><small class="store-old-price">Rp <?= number_format((float) $product['price'], 0, ',', '.'); ?></small><?php endif; ?></td>
                            <td><span class="store-status <?= $product['status'] === 'Ready' ? 'is-ready' : 'is-sold'; ?>"><?= html_escape($product['status']); ?></span></td>
                            <td><?= html_escape(date('d M Y', strtotime($product['created_at']))); ?></td>
                            <td><div class="table-actions">
                                <a class="icon-btn" href="<?= site_url('backend/store/edit/' . (int) $product['id'] . '/'); ?>" title="Edit"><i class="fa-regular fa-pen-to-square"></i></a>
                                <a class="icon-btn" href="<?= html_escape($product['detail_url']); ?>" target="_blank" rel="noopener" title="View product"><i class="fa-solid fa-arrow-up-right-from-square"></i></a>
                                <form method="post" action="<?= site_url('backend/store/delete/' . (int) $product['id'] . '/'); ?>" data-swal-confirm data-swal-title="Hapus <?= html_escape($product['title']); ?>?" data-swal-text="Produk dan media yang terkait akan dihapus." data-swal-confirm-text="Ya, hapus produk">
                                    <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                                    <button class="icon-btn danger-icon" type="submit" title="Delete"><i class="fa-regular fa-trash-can"></i></button>
                                </form>
                            </div></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($products)): ?><tr><td colspan="7"><div class="store-admin-empty"><i class="fa-solid fa-box-open"></i><strong>No products found</strong><span>Create your first product to start selling.</span><a class="btn btn-primary" href="<?= site_url('backend/store/create/'); ?>">Add Product</a></div></td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php if ($total_pages > 1): ?><nav class="store-admin-pagination" aria-label="Product pagination">
            <?php for ($n = 1; $n <= $total_pages; $n++): $params = array_filter(array('search'=>$filters['search'], 'app_id'=>$filters['app_id'], 'type'=>$filters['type'], 'status'=>$filters['status'], 'page'=>$n), function($v){ return $v !== '' && $v !== 0; }); ?>
                <a class="<?= $n === $page ? 'active' : ''; ?>" href="<?= site_url('backend/store/') . '?' . http_build_query($params); ?>"><?= $n; ?></a>
            <?php endfor; ?>
        </nav><?php endif; ?>
    </section>
</main>
<?php include APPPATH . 'views/backend/include/js.php'; ?>
</body>
</html>
