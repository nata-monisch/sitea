(() => {
    'use strict';
    
    const announcement = document.querySelector('.announcement');
    const announcementClose = document.querySelector('.announcement-close');

    if (announcement && announcementClose) {
        announcementClose.addEventListener('click', () => {
            try {
                localStorage.setItem('ntmn_announcement_dismissed_at', String(Date.now()));
            } catch (error) {
                // Tetap tutup untuk sesi saat ini jika localStorage tidak tersedia.
            }

            announcement.remove();
            document.documentElement.classList.add('announcement-dismissed');
        });
    }

    const initMobileNavigation = () => {
        const button = document.querySelector('.mobile-menu-button');
        const navigation = document.querySelector('#mobileNav');

        if (!button || !navigation) return;

        const closeMenu = () => {
            button.setAttribute('aria-expanded', 'false');
            button.setAttribute('aria-label', 'Buka menu');
            navigation.classList.remove('is-open');
            navigation.hidden = true;
        };

        button.addEventListener('click', () => {
            const isExpanded = button.getAttribute('aria-expanded') === 'true';
            button.setAttribute('aria-expanded', String(!isExpanded));
            button.setAttribute('aria-label', isExpanded ? 'Buka menu' : 'Tutup menu');
            navigation.hidden = isExpanded;
            navigation.classList.toggle('is-open', !isExpanded);
        });

        navigation.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', closeMenu);
        });

        document.addEventListener('keydown', event => {
            if (event.key === 'Escape') closeMenu();
        });

        document.addEventListener('click', event => {
            if (!navigation.hidden && !navigation.contains(event.target) && !button.contains(event.target)) {
                closeMenu();
            }
        });
    };

    const initProfileTabs = () => {
        const tabs = [...document.querySelectorAll('[data-profile-tab]')];
        const panels = [...document.querySelectorAll('[data-profile-panel]')];

        if (!tabs.length || !panels.length) return;

        const activateTab = tab => {
            const selected = tab.dataset.profileTab;

            tabs.forEach(item => {
                const active = item === tab;
                item.classList.toggle('is-active', active);
                item.setAttribute('aria-selected', String(active));
                item.tabIndex = active ? 0 : -1;
            });

            panels.forEach(panel => {
                const active = panel.dataset.profilePanel === selected;
                panel.classList.toggle('is-active', active);
                panel.hidden = !active;
            });
        };

        tabs.forEach((tab, index) => {
            tab.addEventListener('click', () => activateTab(tab));
            tab.addEventListener('keydown', event => {
                let nextIndex = index;
                if (event.key === 'ArrowRight') nextIndex = (index + 1) % tabs.length;
                else if (event.key === 'ArrowLeft') nextIndex = (index - 1 + tabs.length) % tabs.length;
                else if (event.key === 'Home') nextIndex = 0;
                else if (event.key === 'End') nextIndex = tabs.length - 1;
                else return;

                event.preventDefault();
                tabs[nextIndex].focus();
                activateTab(tabs[nextIndex]);
            });
        });
    };

    const initLazyLoadImages = () => {
        const images = [...document.querySelectorAll('img.lazy[data-src]')];
        if (!images.length) return;

        const loadImage = image => {
            const source = image.dataset.src;
            if (!source) return;
            image.src = source;
            image.removeAttribute('data-src');
            image.classList.remove('lazy');
        };

        if ('IntersectionObserver' in window) {
            const observer = new IntersectionObserver((entries, currentObserver) => {
                entries.forEach(entry => {
                    if (!entry.isIntersecting) return;
                    loadImage(entry.target);
                    currentObserver.unobserve(entry.target);
                });
            }, { rootMargin: '180px 0px' });

            images.forEach(image => observer.observe(image));
            return;
        }

        // Fallback for browsers without IntersectionObserver.
        const loadVisibleImages = () => {
            images.forEach(image => {
                if (!image.dataset.src) return;
                const bounds = image.getBoundingClientRect();
                if (bounds.top <= window.innerHeight + 180 && bounds.bottom >= -180) {
                    loadImage(image);
                }
            });
        };

        window.addEventListener('scroll', loadVisibleImages, { passive: true });
        window.addEventListener('resize', loadVisibleImages);
        loadVisibleImages();
    };

    const initAssetsDatabaseFilters = () => {
        const searchInput = document.querySelector('[data-assets-search]');
        const cards = [...document.querySelectorAll('[data-assets-card]')];
        const emptyState = document.querySelector('[data-assets-empty]');
        const resultCount = document.querySelector('[data-assets-result-count]');
        const raritySelect = document.querySelector('[data-assets-rarity]');
        const categorySelect = document.querySelector('[data-assets-category-select]');

        initLazyLoadImages();
        if (!cards.length) return;

        let activeCategory = '';
        let activeRarity = '';

        const updateResults = () => {
            const keyword = searchInput ? searchInput.value.trim().toLocaleLowerCase() : '';
            let visibleCount = 0;

            cards.forEach(card => {
                const searchableText = (card.dataset.assetsSearchText || '').toLocaleLowerCase();
                const category = (card.dataset.assetsCategory || '').toLocaleLowerCase();
                const rarity = (card.dataset.assetsRarity || '').toLocaleLowerCase();
                const matchesKeyword = !keyword || searchableText.includes(keyword);
                const matchesCategory = !activeCategory || category === activeCategory;
                const matchesRarity = !activeRarity || rarity === activeRarity;
                const visible = matchesKeyword && matchesCategory && matchesRarity;

                card.hidden = !visible;
                if (visible) visibleCount += 1;
            });

            if (emptyState) emptyState.hidden = visibleCount !== 0;
            if (resultCount) resultCount.textContent = String(visibleCount);
        };

        if (searchInput) searchInput.addEventListener('input', updateResults);

        if (raritySelect) {
            raritySelect.addEventListener('change', () => {
                activeRarity = (raritySelect.value || '').toLocaleLowerCase();
                updateResults();
            });
        }

        if (categorySelect) {
            const trigger = categorySelect.querySelector('[data-category-trigger]');
            const menu = categorySelect.querySelector('[data-category-menu]');
            const label = categorySelect.querySelector('[data-category-label]');
            const categorySearch = categorySelect.querySelector('[data-category-search]');
            const options = [...categorySelect.querySelectorAll('[data-category-option]')];
            const noResults = categorySelect.querySelector('[data-category-empty]');

            const closeMenu = () => {
                if (!menu || !trigger) return;
                menu.hidden = true;
                trigger.setAttribute('aria-expanded', 'false');
                categorySelect.classList.remove('is-open');
            };

            if (trigger && menu) {
                trigger.addEventListener('click', () => {
                    const isOpen = !menu.hidden;
                    menu.hidden = isOpen;
                    trigger.setAttribute('aria-expanded', String(!isOpen));
                    categorySelect.classList.toggle('is-open', !isOpen);
                    if (!isOpen && categorySearch) {
                        categorySearch.value = '';
                        options.forEach(option => { option.hidden = false; });
                        if (noResults) noResults.hidden = true;
                        categorySearch.focus();
                    }
                });
            }

            if (categorySearch) {
                categorySearch.addEventListener('input', () => {
                    const query = categorySearch.value.trim().toLocaleLowerCase();
                    let visible = 0;
                    options.forEach(option => {
                        const matches = option.textContent.trim().toLocaleLowerCase().includes(query);
                        option.hidden = !matches;
                        if (matches) visible += 1;
                    });
                    if (noResults) noResults.hidden = visible !== 0;
                });
            }

            options.forEach(option => {
                option.addEventListener('click', () => {
                    activeCategory = (option.dataset.value || '').toLocaleLowerCase();
                    options.forEach(item => item.setAttribute('aria-selected', String(item === option)));
                    if (label) label.textContent = option.textContent.trim();
                    closeMenu();
                    updateResults();
                });
            });

            document.addEventListener('click', event => {
                if (!categorySelect.contains(event.target)) closeMenu();
            });

            document.addEventListener('keydown', event => {
                if (event.key === 'Escape') closeMenu();
            });
        }

        updateResults();
    };

    const init = () => {
        initMobileNavigation();
        initProfileTabs();
        initAssetsDatabaseFilters();
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init, { once: true });
    } else {
        init();
    }
})();
