NTMN - Announcement dismiss 1 day patch

Perubahan:
- Saat pengunjung menekan tombol X pada announcement frontend, waktu penutupan disimpan di localStorage browser.
- Announcement disembunyikan selama 24 jam sejak ditutup.
- Setelah 24 jam, announcement tampil kembali secara otomatis.
- Status penutupan berlaku per browser/perangkat, bukan untuk semua pengunjung.
- Announcement yang kosong tetap tidak ditampilkan sesuai perilaku sebelumnya.

File yang perlu di-replace:
1. application/views/frontend/include/menu.php
2. assets/js/script.js

Tidak ada perubahan database atau controller.

Catatan:
Jika pengunjung menghapus data situs/browser atau menggunakan browser/perangkat lain, announcement dapat tampil kembali karena penyimpanan dilakukan di browser masing-masing.
