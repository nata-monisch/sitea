<script>
(function () {
    try {
        var dismissedAt = Number(localStorage.getItem('ntmn_announcement_dismissed_at') || 0);
        var oneDay = 24 * 60 * 60 * 1000;

        if (dismissedAt && Date.now() - dismissedAt < oneDay) {
            document.documentElement.classList.add('announcement-dismissed');
        } else if (dismissedAt) {
            localStorage.removeItem('ntmn_announcement_dismissed_at');
        }
    } catch (error) {
        // Announcement tetap bisa ditutup meski penyimpanan browser tidak tersedia.
    }
})();
</script>

<style>
.announcement-dismissed .announcement {
    display: none !important;
}

.announcement {

    min-height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    background: var(--accent);
    color: var(--foreground);
    font-size: 12px;
    padding: 7px 42px;
    position: relative;
}
.announcement .spark {
    color: var(--secondary-foreground);
}
.announcement b {
    color: var(--primary);
}
.announcement a {
    color: var(--secondary-foreground);
    font-weight: 700;
    margin-left: 7px;
}
.announcement-close {
    position: absolute;
    right: max(20px, calc((100% - 1160px) / 2));
    border: 0;
    background: transparent;
    color: var(--secondary-foreground);
    font-size: 21px;
    line-height: 1;
}
</style>

<?php if (!empty($website['announcement'])): ?>
	<div class="announcement">
		<span class="spark">✦</span> <?= $website['announcement'];?>
		<button class="announcement-close" aria-label="Tutup pengumuman">×</button>
	</div>
<?php else: ?>
<?php endif; ?>

    <header class="site-header">
        <div class="header-inner">
            <a class="brand" href="<?= base_url(); ?>" aria-label="<?= html_escape($website['name']); ?> beranda">
                <?php if (!empty($website_logo_url)): ?>
                    <img class="brand-logo" src="<?= html_escape($website_logo_url); ?>" alt="<?= html_escape($website['name']); ?>" loading="eager">
                <?php else: ?>
                    <span class="brand-mark"><?= html_escape(!empty($website_initial) ? $website_initial : 'N'); ?></span>
                <?php endif; ?>
                <span><?= html_escape($website['name']); ?></span>
            </a>
    
            <nav class="desktop-nav" aria-label="Navigasi utama">
                <a href="<?= base_url(); ?>">Beranda</a>
                <a href="<?= site_url('store/'); ?>">Produk</a>
                <a href="<?= site_url('blog/'); ?>">Berita</a>
                <a href="<?= site_url('tools/'); ?>">Tools</a>
            </nav>
    
            <div class="header-actions">
                <button class="mobile-menu-button" type="button" aria-label="Buka menu" aria-expanded="false" aria-controls="mobileNav">
                    <span></span><span></span><span></span>
                </button>
            </div>
        </div>
    
        <nav class="mobile-nav" id="mobileNav" aria-label="Navigasi mobile" hidden>
            <a href="<?= base_url(); ?>">Beranda</a>
            <a href="<?= site_url('store/'); ?>">Produk</a>
            <a href="<?= site_url('blog/'); ?>">Berita</a>
            <a href="<?= site_url('tools/'); ?>">Tools</a>
        </nav>
    </header>
